
function updateForm(updatedField) {
	var pageForm = getFormObj();	
	pageForm.action = "newChargebackSearch?update=" + updatedField;		
	pageForm.submit();		
}


function cancel() {
	location = "home";
}

function openVendorSelector() {
	var url = "vendorSelector?action=open";
	var width  = 820;
	var height = 350;
	var leftPos = (screen.width-width)/2;
	var topPos  = (screen.height-height)/2;
	var aspects = 'toolbar=no,status=no,scrollbars=no,resizable=no,width='+width+',height='+height+',left='+leftPos+',top='+topPos;

	gS = window.open(url, 'VendorSelector', aspects);
	gS.focus();
}

function openChargebackLocationSelector() {
	var url = "chargebackLocationSelector?action=open";
	var width  = 820;
	var height = 350;
	var leftPos = (screen.width-width)/2;
	var topPos  = (screen.height-height)/2;
	var aspects = 'toolbar=no,status=no,scrollbars=no,resizable=no,width='+width+',height='+height+',left='+leftPos+',top='+topPos;

	gS = window.open(url, 'VendorSelector', aspects);
	gS.focus();
}

function openUserIDSelector() {
	var url = "userIDSelector?action=open";
	var width  = 820;
	var height = 350;
	var leftPos = (screen.width-width)/2;
	var topPos  = (screen.height-height)/2;
	var aspects = 'toolbar=no,status=no,scrollbars=no,resizable=no,width='+width+',height='+height+',left='+leftPos+',top='+topPos;
	gS = window.open(url, 'UserIDSelector', aspects);
	gS.focus();
}

function openOriginatorSelector(){
		var url = "originatorSelector?action=open";
			var width  = 820;
			var height = 350;
			var leftPos = (screen.width-width)/2;
			var topPos  = (screen.height-height)/2;
			var aspects = 'toolbar=no,status=no,scrollbars=no,resizable=no,width='+width+',height='+height+',left='+leftPos+',top='+topPos;

			gS = window.open(url, 'OriginatorSelector', aspects);
			gS.focus();
		}
		
function openApproverSelector(){
		var url = "approverSelector?action=open";
			var width  = 820;
			var height = 350;
			var leftPos = (screen.width-width)/2;
			var topPos  = (screen.height-height)/2;
			var aspects = 'toolbar=no,status=no,scrollbars=no,resizable=no,width='+width+',height='+height+',left='+leftPos+',top='+topPos;

			gS = window.open(url, 'ApproverSelector', aspects);
			gS.focus();
		}
		







function updateVendor(vendorId) {
	document.getElementById("vendor").value = vendorId;
}

function getChargeback(invoiceNumber){
	var doc = document.forms[1];
	doc.action="getChargeback";
	doc.submit();
}

function createChargeback() {
		var doc = document.forms[1];
		
		if(document.getElementsByName("locationNumber")[0].value == "") {
			alert("Please enter a location number.");
			document.getElementsByName("locationNumber")[0].focus();
			return;
		}
			else if (document.getElementsByName("vendorId")[0].value == "") {
			alert("Please enter vendorId.");
			document.getElementsByName("vendorId")[0].focus();
			return;
		}
			else{
			doc.action = "createChargeback?action=create";
			doc.submit();	
		}
		
	}
	





