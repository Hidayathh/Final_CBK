/**
 * main.js
 */

function confirmLogout() {
       if (confirm("Are you sure you want to logout ?")) {
              location = "/logout.html";
       }
}

function MM_openBrWindow(theURL,winName,features) { //v2.0
window.open(theURL,winName,features);
}

function newChargebackSearch() {
       location="newChargebackSearch?isformreset=true";
}


function userMaintenance()	{
	 location = "userMaintenance?action=userMaint&isformreset=true";
	
}


function massApprovalSearch() {
           location="massApprovalsSearch?isformreset=true";
           
     }
     
function getMassApprovalsResults() {
           location="getMassApproveResults?action=massApproveResults";
     }
	

