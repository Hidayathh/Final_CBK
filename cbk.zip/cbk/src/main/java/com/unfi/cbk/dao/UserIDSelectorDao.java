package com.unfi.cbk.dao;

import java.util.List;

import com.unfi.cbk.exceptions.CbkServiceException;

public interface UserIDSelectorDao {

	public List doUserIDSearch(String userID, String userName) throws CbkServiceException;

}
