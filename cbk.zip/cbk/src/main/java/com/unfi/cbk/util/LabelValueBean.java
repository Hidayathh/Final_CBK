package com.unfi.cbk.util;

import java.io.Serializable;

public class LabelValueBean implements Serializable {

	private String label;
	private String value;

	public LabelValueBean(String l, String v) {
		this.label = l;
		this.value = v;
	}

	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

}
