package com.unfi.cbk.bo;

import java.util.Date;

import com.unfi.cbk.util.DateFunctions;

public class PlAccrualsBO {
	private String invoiceNumber;
	private Date invoiceDate;
	private String vendorNumber;
	private String companyCode;
	private String locationNumber;
	private String rName;
	private String creatorId;
	private String typeDescription;
	private String legerType;
	private String loc;
	private String account;
	private String distAccount;
	private String amount;

	public String getInvoiceNumber() {
		return invoiceNumber;
	}

	public void setInvoiceNumber(String invoiceNumber) {
		this.invoiceNumber = invoiceNumber;
	}

	

	public Date getInvoiceDate() {
		return invoiceDate;
	}

	public void setInvoiceDate(Date invoiceDate) {
		this.invoiceDate = invoiceDate;
	}

	public String getVendorNumber() {
		return vendorNumber;
	}

	public void setVendorNumber(String vendorNumber) {
		this.vendorNumber = vendorNumber;
	}

	public String getCompanyCode() {
		return companyCode;
	}

	public void setCompanyCode(String companyCode) {
		this.companyCode = companyCode;
	}

	public String getLocationNumber() {
		return locationNumber;
	}

	public void setLocationNumber(String locationNumber) {
		this.locationNumber = locationNumber;
	}

	public String getrName() {
		return rName;
	}

	public void setrName(String rName) {
		this.rName = rName;
	}

	public String getCreatorId() {
		return creatorId;
	}

	public void setCreatorId(String creatorId) {
		this.creatorId = creatorId;
	}

	public String getTypeDescription() {
		return typeDescription;
	}

	public void setTypeDescription(String typeDescription) {
		this.typeDescription = typeDescription;
	}

	public String getLegerType() {
		return legerType;
	}

	public void setLegerType(String legerType) {
		this.legerType = legerType;
	}

	public String getLoc() {
		return loc;
	}

	public void setLoc(String loc) {
		this.loc = loc;
	}

	public String getAccount() {
		return account;
	}

	public void setAccount(String account) {
		this.account = account;
	}

	public String getDistAccount() {
		return distAccount;
	}

	public void setDistAccount(String distAccount) {
		this.distAccount = distAccount;
	}

	public String getAmount() {
		return amount;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}
	
	public String getInvoiceDateString() {
		String s = null;
		if (invoiceDate != null) {
			s = DateFunctions.formatDate(invoiceDate);
		}
		return s;
	}

	public void setInvoiceDateString(String s) {
		if (s != null && s.trim().length() > 0) {
			invoiceDate = DateFunctions.stringToDate(s);
		}
	}

}
