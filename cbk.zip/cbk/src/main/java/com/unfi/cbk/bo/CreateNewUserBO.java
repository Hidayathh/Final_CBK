package com.unfi.cbk.bo;

public class CreateNewUserBO {

	private String userId;
	private String userName;
	private String useremailId;
	private String locations;
	private String roles;

	private String roleId;
	private String role;
	private String locationNumber;

	private String distRoles;
	private String distLocNumber;

	private String status;

	private String defForm;

	public String getDefForm() {
		return defForm;
	}

	public void setDefForm(String defForm) {
		this.defForm = defForm;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getDistRoles() {
		return distRoles;
	}

	public void setDistRoles(String distRoles) {
		this.distRoles = distRoles;
	}

	public String getDistLocNumber() {
		return distLocNumber;
	}

	public void setDistLocNumber(String distLocNumber) {
		this.distLocNumber = distLocNumber;
	}

	public String getLocationNumber() {
		return locationNumber;
	}

	public void setLocationNumber(String locationNumber) {
		this.locationNumber = locationNumber;
	}

	public String getUseremailId() {
		return useremailId;
	}

	public void setUseremailId(String useremailId) {
		this.useremailId = useremailId;
	}

	public String getRoleId() {
		return roleId;
	}

	public void setRoleId(String roleId) {
		this.roleId = roleId;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getLocations() {
		return locations;
	}

	public void setLocations(String locations) {
		this.locations = locations;
	}

	public String getRoles() {
		return roles;
	}

	public void setRoles(String roles) {
		this.roles = roles;
	}

	private boolean isNew;

	public boolean isNew() {
		return isNew;
	}

	public void setNew(boolean isNew) {
		this.isNew = isNew;
	}

	@Override
	public String toString() {
		return "CreateNewUserBO [userId=" + userId + ", userName=" + userName + ", useremailId=" + useremailId
				+ ", locations=" + locations + ", roles=" + roles + ", roleId=" + roleId + ", role=" + role
				+ ", locationNumber=" + locationNumber + ", isNew=" + isNew + "]";
	}

	public void populateFormFromObject(CreateNewUserBO cbk) {
		this.isNew = false;
		this.setUserId(cbk.getUserId());
		this.setUserName(cbk.getUserName());
		this.setUseremailId(cbk.getUseremailId());
		this.setRoles(cbk.getRoles());
		this.setLocations(cbk.getLocations());
		this.setRole(cbk.getRole());
		this.setRoleId(cbk.getRoleId());
		this.setLocationNumber(cbk.getLocationNumber());
		this.setStatus(cbk.getStatus());
	}

}
