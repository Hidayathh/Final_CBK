package com.unfi.cbk.controller;

import static java.nio.charset.StandardCharsets.UTF_8;

import java.net.URLDecoder;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.WebApplicationContext;

import com.unfi.cbk.bo.OAuthResponseBO;
import com.unfi.cbk.bo.OAuthValidateBO;
import com.unfi.cbk.delegates.OpenIdConnectDelegate;

@RestController
@Scope(value = WebApplicationContext.SCOPE_REQUEST, proxyMode = ScopedProxyMode.TARGET_CLASS)
/**
 * 
 * @author q4gwckb OpenIdController.java receives CODE response using Embedded
 *         redirect_uri after Site minder successful Login
 */
public class OpenIdController {

	public static String USER_ID = null;
	static Logger log = Logger.getLogger(OpenIdController.class);
	@Autowired
	OpenIdConnectDelegate openIdConnect;

	@RequestMapping(value = "/token", method = { RequestMethod.GET, RequestMethod.POST })
	public void siteMinderUrlResponse(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ResponseEntity<OAuthResponseBO> accessToken = null;
		ResponseEntity<OAuthValidateBO> tokenValidation = null;
		String active = null, smUserIdDetails = null, smUserId = null;

		HttpSession session = request.getSession();
		try {
			String qStr = request.getQueryString().substring(5);
			String code = (String) URLDecoder.decode(qStr, UTF_8.toString());
			accessToken = openIdConnect.fetchAccessToken(code);

		} catch (Exception e) {
			log.error("Error at Access Tokean ResponseEntity :" + e.getMessage());
		}
		try {
			if (accessToken != null) {
				tokenValidation = openIdConnect.validateAccessToken(accessToken.getBody().getAccess_token());
			}

			String[] arrSmUserId = null;
			if (tokenValidation != null) {
				active = tokenValidation.getBody().getActive();
				smUserIdDetails = tokenValidation.getBody().getSub();
				arrSmUserId = smUserIdDetails.split(",");
				smUserId = arrSmUserId[0].substring(4);
				smUserId = smUserId.toUpperCase();
			}

			if (smUserId != null) {
				USER_ID = smUserId;
				session.setAttribute("active", active);
				session.setAttribute("SmUserId", smUserId);
			}

		} catch (Exception e) {
			log.error("Error at Access Tokean ResponseEntity :" + e.getMessage());

		}
		if (active != null && smUserId != null && active.equalsIgnoreCase("true") && !smUserId.isEmpty()) {
			response.sendRedirect(openIdConnect.cbkHomeUrl());
		} else if (active != null && active.equalsIgnoreCase("false")) {
			response.sendRedirect(openIdConnect.redirectUrl());
		}
	}

}
