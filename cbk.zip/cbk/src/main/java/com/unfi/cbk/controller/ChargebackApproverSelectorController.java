package com.unfi.cbk.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.unfi.cbk.bo.ChargebackBO;
import com.unfi.cbk.dao.ChargebackSearchDao;
import com.unfi.cbk.forms.ChargebackApproverSelectorForm;
import com.unfi.cbk.util.ActionMessages;
import com.unfi.cbk.util.ActionUrlMapping;
import com.unfi.cbk.util.Constants;

/**
 * The action method that will be called is automatically determined based upon
 * the value of the parameter that is passed in.
 * <p>
 * The action method will then sets the user data in the request, sets any
 * values needed, and forwards to the appropriate action mapping.
 *
 * @author vpil001
 * @version 1.0
 */
@Controller
public class ChargebackApproverSelectorController {
	static Logger log = Logger.getLogger(ChargebackApproverSelectorController.class);
	private ChargebackSearchDao chargebackSearchDao;

	public ChargebackApproverSelectorController(@Autowired ChargebackSearchDao dao) {
		this.chargebackSearchDao = dao;
	}

	@Autowired
	ActionMessages errors;

	/**
	 * The search() method get the values from the database.
	 * 
	 * @param mapping  The ActionMapping used to select this instance
	 * @param form     The ActionForm bean for this request
	 * @param request  The HTTP request we are processing
	 * @param response The HTTP response we are creating
	 * @return an ActionForward instance describing where and how control should be
	 *         forwarded, or null if the response has already been completed.
	 * @throws Exception if an exception occurs
	 */
	@RequestMapping(value = "/cbkApproverSelector", method = { RequestMethod.GET, RequestMethod.POST }, params = {
			"action=search" })
	public ModelAndView search(@ModelAttribute ChargebackApproverSelectorForm chargebackApproverSelectorForm,
			HttpServletRequest request, HttpServletResponse response) throws Exception {
		ModelAndView mav = new ModelAndView();
		ActionMessages errors = new ActionMessages();
		HttpSession session = request.getSession();
		String SmUserId = (String) session.getAttribute("SmUserId");

		boolean exceptionOccurred = false;
		try {

			String invoiceNumber = null;
			String locationNumberFiveDigit = null;
			String locationNumberTwoDigit = null;
			String actionType = null;
			String typeId = null;
			String locationNumber = null;

			String stepNumber = null;
			String minStepNumber = null;

			/*
			 * if (request.getParameter("avlblStepNumber") != null) { stepNumber =
			 * request.getParameter("avlblStepNumber"); minStepNumber = stepNumber; }
			 */

			if (request.getParameter("stepNumber") != null) {
				stepNumber = request.getParameter("stepNumber");
			}

			if (request.getParameter("typeId") != null) {
				typeId = request.getParameter("typeId");
			}

			if (request.getParameter("locNo") != null) {
				locationNumberFiveDigit = request.getParameter("locNo");
				locationNumberTwoDigit = locationNumberFiveDigit.substring(0, 2);
				locationNumber = locationNumberFiveDigit;
			}
			if (request.getParameter("actionType") != null) {
				actionType = request.getParameter("actionType");
			}

			if (request.getParameter("invoiceNumber") != null) {
				invoiceNumber = request.getParameter("invoiceNumber");
			}

			String maxStepNumber = null;
			List searchResults = null;
			String roleId = null;
			maxStepNumber = chargebackSearchDao.getMaxStepNumberWithInvoiceAmount(invoiceNumber, locationNumber,
					typeId);
			chargebackApproverSelectorForm.setLastStepNumber(maxStepNumber);

			if (minStepNumber == null) {
				minStepNumber = chargebackSearchDao.getMinStepNumberWithInvoiceAmount(invoiceNumber, locationNumber,
						typeId);
				chargebackApproverSelectorForm.setFirstStepNumber((minStepNumber));

			}

			if (minStepNumber != null) {
				roleId = chargebackSearchDao.getRoleIdByStepAndType(typeId, minStepNumber);
			}

			if (actionType != null && actionType.equalsIgnoreCase("Up") && typeId != null) {
				minStepNumber = chargebackSearchDao.getApproverStepsUpWithInvoiceAmount(invoiceNumber, locationNumber,
						typeId, stepNumber);
				roleId = chargebackSearchDao.getRoleIdByStepAndType(typeId, minStepNumber);
				if (roleId != null) {
					searchResults = chargebackSearchDao.doChargebackApproverSearch(SmUserId, locationNumberTwoDigit,
							roleId, typeId);
					chargebackApproverSelectorForm.setStepNumber(minStepNumber);
				}
				if (searchResults != null && searchResults.size() <= 0) {
					minStepNumber = chargebackSearchDao.getApproverStepsUpWithInvoiceAmount(invoiceNumber,
							locationNumber, typeId, stepNumber);
					chargebackApproverSelectorForm.setLastStepNumber(minStepNumber);
					chargebackApproverSelectorForm.setStepNumber(minStepNumber);
				}

			} else if (actionType != null && actionType.equalsIgnoreCase("Down") && typeId != null) {
				maxStepNumber = chargebackSearchDao.getApproverStepsDownWithInvoiceAmount(invoiceNumber, locationNumber,
						typeId, stepNumber);
				roleId = chargebackSearchDao.getRoleIdByStepAndType(typeId, maxStepNumber);
				if (roleId != null) {
					searchResults = chargebackSearchDao.doChargebackApproverSearch(SmUserId, locationNumberTwoDigit,
							roleId, typeId);
					// minStepNumber =
					// chargebackSearchDao.getMinStepNumberWithInvoiceAmount(invoiceNumber,locationNumber,typeId);
					chargebackApproverSelectorForm.setStepNumber(maxStepNumber);
				}
			} else if (roleId != null) {
				searchResults = chargebackSearchDao.doChargebackApproverSearch(SmUserId, locationNumberTwoDigit, roleId,
						typeId);
				if (searchResults.size() > 0) {
					ChargebackBO cbkApp = (ChargebackBO) searchResults.get(0);
					chargebackApproverSelectorForm.setStepNumber(cbkApp.getStepNumber());

				}
			}

			chargebackApproverSelectorForm.setLocationNumber(locationNumberFiveDigit);
			chargebackApproverSelectorForm.setTypeId(typeId);
			chargebackApproverSelectorForm.setInvoiceNumber(invoiceNumber);

			chargebackApproverSelectorForm.setSearchResults(searchResults);
		} catch (Exception e) {
			exceptionOccurred = true;
			e.printStackTrace();
			mav.setViewName(ActionUrlMapping.GLOBAL.get(Constants.ACTION_FAILURE));
			log.error("Exception in execute:" + e);
			if (errors.isEmpty()) {
				errors.add("error", "errors.general");
			}
		}

		if (!exceptionOccurred) {
			mav.setViewName(ActionUrlMapping.CBKAPPROVERSELECTORACTIONS.get("open"));
		}

		// If a message is required, save the specified key(s) into the request.
		if (!errors.isEmpty()) {
			log.debug("FAILED");
			mav.setViewName(ActionUrlMapping.GLOBAL.get(Constants.ACTION_FAILURE));
		}

		request.setAttribute("actionMessages", errors);
		request.setAttribute("chargebackApproverSelectorForm", chargebackApproverSelectorForm);
		return mav;
	}

	// APPROVER SELECTOR LOGIC FOR CREATE UPDATE DETAIL AND AVAILABLE Chargeback
	// Screens

	@RequestMapping(value = "/cbkCreateApproverSelector", method = { RequestMethod.GET, RequestMethod.POST }, params = {
			"action=createApprSelector" })
	public ModelAndView createApprSelector(
			@ModelAttribute ChargebackApproverSelectorForm chargebackApproverSelectorForm, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		ModelAndView mav = new ModelAndView();
		ActionMessages errors = new ActionMessages();
		HttpSession session = request.getSession();
		String SmUserId = (String) session.getAttribute("SmUserId");

		boolean exceptionOccurred = false;
		try {

			String locationNumberFiveDigit = null;
			String locationNumberTwoDigit = null;
			String actionType = null;
			String typeId = null;
			String locationNumber = null;
			String chargebackTotal = null;
			String stepNumber = null;
			String minStepNumber = null;

			if (request.getParameter("stepNumber") != null) {
				stepNumber = request.getParameter("stepNumber");
			}

			if (request.getParameter("typeId") != null) {
				typeId = request.getParameter("typeId");
			}

			if (request.getParameter("locNo") != null) {
				locationNumberFiveDigit = request.getParameter("locNo");
				locationNumberTwoDigit = locationNumberFiveDigit.substring(0, 2);
				locationNumber = locationNumberFiveDigit;
			}
			if (request.getParameter("actionType") != null) {
				actionType = request.getParameter("actionType");
			}

			if (request.getParameter("extTotal") != null) {
				chargebackTotal = request.getParameter("extTotal");
			}

			String maxStepNumber = null;
			List searchResults = null;
			String roleId = null;
			maxStepNumber = chargebackSearchDao.getMaxStepNumberWithAmount(typeId, chargebackTotal);

			chargebackApproverSelectorForm.setLastStepNumber(maxStepNumber);

			if (minStepNumber == null) {
				minStepNumber = chargebackSearchDao.getMinStepNumberWithAmount(typeId, chargebackTotal);
				chargebackApproverSelectorForm.setFirstStepNumber((minStepNumber));

			}

			if (minStepNumber != null) {
				// roleId= roleid getting method using step number and type id
				roleId = chargebackSearchDao.getRoleIdByStepAndType(typeId, minStepNumber);
			}

			if (actionType != null && actionType.equalsIgnoreCase("Up") && typeId != null) {
				minStepNumber = chargebackSearchDao.getApproverStepsUpWithmount(typeId, chargebackTotal, stepNumber);
				roleId = chargebackSearchDao.getRoleIdByStepAndType(typeId, minStepNumber);
				if (roleId != null) {
					searchResults = chargebackSearchDao.doChargebackApproverSearch(SmUserId, locationNumberTwoDigit,
							roleId, typeId);
					chargebackApproverSelectorForm.setStepNumber(minStepNumber);
				}

				if (searchResults != null && searchResults.size() <= 0) {
					minStepNumber = chargebackSearchDao.getApproverStepsUpWithmount(typeId, chargebackTotal,
							stepNumber);
					chargebackApproverSelectorForm.setLastStepNumber(minStepNumber);
					chargebackApproverSelectorForm.setStepNumber(minStepNumber);
				}

			} else if (actionType != null && actionType.equalsIgnoreCase("Down") && typeId != null) {
				maxStepNumber = chargebackSearchDao.getApproverStepsDownWithmount(typeId, chargebackTotal, stepNumber);
				roleId = chargebackSearchDao.getRoleIdByStepAndType(typeId, maxStepNumber);
				if (roleId != null) {
					searchResults = chargebackSearchDao.doChargebackApproverSearch(SmUserId, locationNumberTwoDigit,
							roleId, typeId);
					minStepNumber = chargebackSearchDao.getMinStepNumberWithAmount(typeId, chargebackTotal);
					chargebackApproverSelectorForm.setStepNumber(maxStepNumber);

				}

				if (searchResults != null && searchResults.size() <= 0) {
					maxStepNumber = chargebackSearchDao.getApproverStepsDownWithmount(typeId, chargebackTotal,
							stepNumber);
					chargebackApproverSelectorForm.setLastStepNumber(maxStepNumber);
					chargebackApproverSelectorForm.setStepNumber(maxStepNumber);
				}

			} else if (roleId != null) {
				searchResults = chargebackSearchDao.doChargebackApproverSearch(SmUserId, locationNumberTwoDigit, roleId,
						typeId);
				if (searchResults.size() > 0) {
					ChargebackBO cbkApp = (ChargebackBO) searchResults.get(0);
					chargebackApproverSelectorForm.setStepNumber(cbkApp.getStepNumber());

				}

			}

			chargebackApproverSelectorForm.setLocationNumber(locationNumberFiveDigit);
			chargebackApproverSelectorForm.setTypeId(typeId);
			chargebackApproverSelectorForm.setChargbackTotal(chargebackTotal);

			chargebackApproverSelectorForm.setSearchResults(searchResults);
		} catch (Exception e) {
			exceptionOccurred = true;
			e.printStackTrace();
			mav.setViewName(ActionUrlMapping.GLOBAL.get(Constants.ACTION_FAILURE));
			log.error("Exception in execute:" + e);
			if (errors.isEmpty()) {
				errors.add("error", "errors.general");
			}
		}

		if (!exceptionOccurred) {
			// forward = mapping.findForward("open");
			mav.setViewName(ActionUrlMapping.CBKCREATEAPPROVERSELECTORACTIONS.get("open"));
		}

		// If a message is required, save the specified key(s) into the request.
		if (!errors.isEmpty()) {
			log.debug("FAILED");
			// saveMessages(request, errors);
			// forward = mapping.findForward("failure");
			mav.setViewName(ActionUrlMapping.GLOBAL.get(Constants.ACTION_FAILURE));
		}

		request.setAttribute("actionMessages", errors);
		request.setAttribute("chargebackApproverSelectorForm", chargebackApproverSelectorForm);
		return mav;
	}

	// APPROVER SELECTOR LOGIC FOR MASS APPPROVALS Screens

	@RequestMapping(value = "/cbkMassApproverSelector", method = { RequestMethod.GET, RequestMethod.POST }, params = {
			"action=massApp" })
	public ModelAndView massApp(@ModelAttribute ChargebackApproverSelectorForm chargebackApproverSelectorForm,
			HttpServletRequest request, HttpServletResponse response) throws Exception {
		ModelAndView mav = new ModelAndView();
		ActionMessages errors = new ActionMessages();
		HttpSession session = request.getSession();
		String SmUserId = (String) session.getAttribute("SmUserId");
		boolean exceptionOccurred = false;
		try {

			String locationNumberFiveDigit = null;
			String actionType = null;
			String typeId = null;
			String locationNumber = null;

			String stepNumber = null;

			if (request.getParameter("avlblStepNumber") != null) {
				stepNumber = request.getParameter("avlblStepNumber");
			}

			if (request.getParameter("stepNumber") != null) {
				stepNumber = request.getParameter("stepNumber");
			}

			if (request.getParameter("typeId") != null) {
				typeId = request.getParameter("typeId");
			}

			if (request.getParameter("locNo") != null) {
				locationNumberFiveDigit = request.getParameter("locNo");
				locationNumber = locationNumberFiveDigit.substring(0, 2);
			}
			if (request.getParameter("actionType") != null) {
				actionType = request.getParameter("actionType");
			}
			String minStepNumber = null;
			String maxStepNumber = null;
			List searchResults = null;
			String roleId = null;
			maxStepNumber = chargebackSearchDao.getMaxStepNumber(typeId);
			chargebackApproverSelectorForm.setLastStepNumber(maxStepNumber);
			
			if (minStepNumber == null) {
				// minimum step
				//minStepNumber = chargebackSearchDao.getMinStepNumber(typeId);
				minStepNumber = chargebackSearchDao.getStepNumberForApproverByRoleid(SmUserId);
				if(request.getParameter("massApp")!= null && request.getParameter("massApp").equals("Y"))
				{
					minStepNumber = chargebackSearchDao.getApproverStepsUp(typeId, minStepNumber);
				}
				chargebackApproverSelectorForm.setFirstStepNumber((minStepNumber));
			}
			if (minStepNumber != null) {
				// roleId= roleid getting method using step number and type id
				roleId = chargebackSearchDao.getRoleIdByStepAndType(typeId, minStepNumber);
			}
			
			if (actionType != null && actionType.equalsIgnoreCase("Up") && typeId != null) {
				minStepNumber = chargebackSearchDao.getApproverStepsUp(typeId, stepNumber);
				roleId = chargebackSearchDao.getRoleIdByStepAndType(typeId, minStepNumber);
				if (roleId != null) {
					searchResults = chargebackSearchDao.doChargebackApproverSearch(SmUserId, locationNumber, roleId,
							typeId);
					chargebackApproverSelectorForm.setStepNumber(minStepNumber);
				}
				if (searchResults != null && searchResults.size() <= 0) {
					minStepNumber = chargebackSearchDao.getApproverStepsUp(typeId, stepNumber);
					chargebackApproverSelectorForm.setLastStepNumber(minStepNumber);
					chargebackApproverSelectorForm.setStepNumber(minStepNumber);
				}

			} else if (actionType != null && actionType.equalsIgnoreCase("Down") && typeId != null) {
				maxStepNumber = chargebackSearchDao.getApproverStepsDown(typeId, stepNumber);
				roleId = chargebackSearchDao.getRoleIdByStepAndType(typeId, maxStepNumber);
				if (roleId != null) {
					searchResults = chargebackSearchDao.doChargebackApproverSearch(SmUserId, locationNumber, roleId,
							typeId);
					chargebackApproverSelectorForm.setStepNumber(maxStepNumber);
				}

				if (searchResults != null && searchResults.size() <= 0) {
					maxStepNumber = chargebackSearchDao.getApproverStepsDown(typeId, stepNumber);
					chargebackApproverSelectorForm.setLastStepNumber(maxStepNumber);
					chargebackApproverSelectorForm.setStepNumber(maxStepNumber);
				}

			} else if (roleId != null) {
				searchResults = chargebackSearchDao.doChargebackApproverSearch(SmUserId, locationNumber, roleId,
						typeId);
				if (searchResults.size() > 0) {
					ChargebackBO cbkApp = (ChargebackBO) searchResults.get(0);
					chargebackApproverSelectorForm.setStepNumber(cbkApp.getStepNumber());

				}

			}

	
			chargebackApproverSelectorForm.setLocationNumber(locationNumberFiveDigit);
			chargebackApproverSelectorForm.setTypeId(typeId);
			chargebackApproverSelectorForm.setSearchResults(searchResults);
		} catch (Exception e) {
			exceptionOccurred = true;
			e.printStackTrace();
			mav.setViewName(ActionUrlMapping.GLOBAL.get(Constants.ACTION_FAILURE));
			log.error("Exception in execute:" + e);
			if (errors.isEmpty()) {
				errors.add("error", "errors.general");
			}
		}

		if (!exceptionOccurred) {
			mav.setViewName(ActionUrlMapping.CBKIMPORTMASSAPPROVERSELECTORACTIONS.get("open"));
		}

		// If a message is required, save the specified key(s) into the request.
		if (!errors.isEmpty()) {
			log.debug("FAILED");
			mav.setViewName(ActionUrlMapping.GLOBAL.get(Constants.ACTION_FAILURE));
		}

		request.setAttribute("actionMessages", errors);
		request.setAttribute("chargebackApproverSelectorForm", chargebackApproverSelectorForm);
		return mav;
	}

}
