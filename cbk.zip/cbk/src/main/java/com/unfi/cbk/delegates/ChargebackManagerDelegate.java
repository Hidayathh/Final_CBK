package com.unfi.cbk.delegates;

import java.util.List;
import java.util.Map;

import com.unfi.cbk.beans.ResultList;
import com.unfi.cbk.bo.ChargebackBO;
import com.unfi.cbk.bo.ChargebackManagerBO;
import com.unfi.cbk.dao.ChargebackManagerDao;
import com.unfi.cbk.exceptions.DataAccessException;
import com.unfi.cbk.util.DateFunctions;

/**
 * @author yhp6y2l
 * @version 3.3
 */

public class ChargebackManagerDelegate {

	private ChargebackManagerDao chargebackManagerDao;

	public ChargebackManagerDelegate(ChargebackManagerDao chargebackManagerDao) {
		this.chargebackManagerDao = chargebackManagerDao;
	}


	public ResultList getChargebacks(Map params) throws DataAccessException {

		// Set up the date range of the search
		this.calculateSearchDates(params);
		ResultList rL = chargebackManagerDao.getChargebacks(params);

		// Only keep the fromDate and toDate parameters in the map if the user
		// entered a manual date selection.
		String dateCriteria = (String) params.get("dateCriteria");
		if (dateCriteria != null && !dateCriteria.equals("manual")) {
			params.remove("fromDate");
			params.remove("toDate");
		}

		return rL;
	}

	public List<ChargebackManagerBO> getChargebackTypes() throws DataAccessException {
		List<ChargebackManagerBO> l = chargebackManagerDao.getChargebackTypes();

		return l;
	}

	public ResultList locationNumberValidator(Map params) throws DataAccessException {
		ResultList rL = chargebackManagerDao.locationNumberValidator(params);
		return rL;
	}

	public ResultList vendorNumberValidator(Map params) throws DataAccessException {
		ResultList rL = chargebackManagerDao.vendorNumberValidator(params);
		return rL;
	}

	public ResultList originatorValidator(Map params) throws DataAccessException {
		ResultList rL = chargebackManagerDao.originatorValidator(params);
		return rL;
	}

	public ResultList approverValidator(Map params) throws DataAccessException {
		ResultList rL = chargebackManagerDao.approverValidator(params);
		return rL;
	}

	public ResultList invoiceNumberValidator(Map params) throws DataAccessException {
		ResultList rL = chargebackManagerDao.invoiceNumberValidator(params);
		return rL;
	}

	public void updateChargebackApprover(ChargebackBO chargeBack) throws DataAccessException {
		chargebackManagerDao.updateChargebackApprover(chargeBack);
	}

	public void approveChargebacks(ChargebackBO cbkBo) throws DataAccessException {
		chargebackManagerDao.approveChargebacks(cbkBo);
	}

	public String getMaxStepNumber(String typeId, String chargebackTotal) throws DataAccessException {
		String maxStepNumber = chargebackManagerDao.getMaxStepNumber(typeId, chargebackTotal);
		return maxStepNumber;
	}

	public ResultList getChargeAccrual(Map map) throws DataAccessException {
		ResultList rL = chargebackManagerDao.getChargeAccrual(map);
		return rL;
	}

	public ResultList getChargebackRoles(Map map) throws DataAccessException {
		ResultList rL = chargebackManagerDao.getChargebackRoles(map);
		return rL;
	}

	private void calculateSearchDates(Map params) {
		// Determine the dates to use
		String dateCriteria = (String) params.get("dateCriteria");
		String fromDate = (String) params.get("fromDate");
		String toDate = (String) params.get("toDate");
		String from = "";
		String to = "";

		if ((dateCriteria != null) && (!dateCriteria.equals(""))) {
			if (dateCriteria.equals("3")) {
				// Use the dates provided
				from = DateFunctions.formatYear(fromDate);
				params.put("fromDate", from);
				params.put("searchFromDate", DateFunctions.formatDate(from));
				to = DateFunctions.formatYear(toDate);
				params.put("toDate", to);
				params.put("searchToDate", DateFunctions.formatDate(to));
			} else {
				String dateCriteriaDays = null;

				if (dateCriteria.equalsIgnoreCase("1")) {
					dateCriteriaDays = "30";
				} else if (dateCriteria.equalsIgnoreCase("2")) {
					dateCriteriaDays = "60";
				}

				from = DateFunctions.adjustCurrentDate(-(Integer.parseInt(dateCriteriaDays)));
				to = DateFunctions.getToday();

				params.put("fromDate", from);
				params.put("searchFromDate", DateFunctions.formatDate(from));
				params.put("toDate", to);
				params.put("searchToDate", DateFunctions.formatDate(to));
			}
		}
	}



	// Product Code
	public ResultList getProductGroup(Map map) throws DataAccessException {
		ResultList rL = chargebackManagerDao.getProductGroup(map);
		return rL;
	}

	public void InsertProductCode(Map formSearchValuesMap) throws DataAccessException {
		chargebackManagerDao.InsertProductCode(formSearchValuesMap);
	}

	public ChargebackManagerBO getProductDetails(String productCode) throws DataAccessException {
		return chargebackManagerDao.getProductDetails(productCode);

	}

	public void deleteProductDetails(String productCode) throws DataAccessException {
		chargebackManagerDao.deleteProductDetails(productCode);
	}

	public void updateProductCode(Map formSearchValuesMap) throws DataAccessException {
		chargebackManagerDao.updateProductCode(formSearchValuesMap);
	}

	// Excluded Vendor

	public ResultList getExcludedVendor(Map map) throws DataAccessException {
		ResultList rL = chargebackManagerDao.getExcludedVendor(map);
		return rL;
	}

	public void InsertExcludedVendor(Map formSearchValuesMap) throws DataAccessException {
		chargebackManagerDao.InsertExcludedVendor(formSearchValuesMap);
	}

	public ChargebackManagerBO getVendorDetails(String vendor) throws DataAccessException {
		return chargebackManagerDao.getVendorDetails(vendor);
	}

	public void updateVendor(Map formSearchValuesMap) throws DataAccessException {
		chargebackManagerDao.updateVendor(formSearchValuesMap);
	}

	public void deleteExcludedVend(String vendor) throws DataAccessException {
		chargebackManagerDao.deleteExcludedVend(vendor);
	}

	// Route Name Maintanance
	public ResultList getRouteName(Map map) throws DataAccessException {
		ResultList rL = chargebackManagerDao.getRouteName(map);
		return rL;
	}

	public ChargebackManagerBO getRouteId(Map map) throws DataAccessException {
		return chargebackManagerDao.getRouteId(map);
	}

	public void InsertRouteName(Map formSearchValuesMap) throws DataAccessException {
		chargebackManagerDao.InsertRouteName(formSearchValuesMap);
	}

	public ChargebackManagerBO getRouteDetails(String routeId) throws DataAccessException {
		return chargebackManagerDao.getRouteDetails(routeId);
	}

	public void updateRouteName(Map formSearchValuesMap) throws DataAccessException {
		chargebackManagerDao.updateRouteName(formSearchValuesMap);
	}

	public void deleteRouteDetails(String routeId) throws DataAccessException {
		chargebackManagerDao.deleteRouteDetails(routeId);
	}
	
	public ResultList getAuditResults(Map searchParametersFrom) throws DataAccessException {
		ResultList rL = chargebackManagerDao.getAuditResults(searchParametersFrom);
		return rL;
	}

	public ResultList getCbkLocDetails(Map searchParametersFrom) throws DataAccessException {
		ResultList rL = chargebackManagerDao.getCbkLocDetails(searchParametersFrom);
		return rL;
	}

	public void saveCreateLocation(Map searchParametersFrom) throws DataAccessException {
		chargebackManagerDao.saveCreateLocation(searchParametersFrom);

	}

	public ResultList getReasonResults() throws DataAccessException {
		ResultList rL = chargebackManagerDao.getReasonResults();
		return rL;
	}

	public ChargebackManagerBO getEditLocDetails(String locationNumber) throws DataAccessException {
		return chargebackManagerDao.getEditLocDetails(locationNumber);
	}

	public void saveCreateReason(Map searchParametersFromForm) throws DataAccessException {
		chargebackManagerDao.saveCreateReason(searchParametersFromForm);

	}

	public ChargebackManagerBO getReasonDetails(String chargebackReason) throws DataAccessException {
		return chargebackManagerDao.getReasonDetails(chargebackReason);
	}

	public void deleteLocDetails(String locationNumber) throws DataAccessException {
		chargebackManagerDao.deleteLocDetails(locationNumber);
	}

	public void updateLocation(Map map) throws DataAccessException {
		chargebackManagerDao.updateLocation(map);
	}

	public void updateReason(Map map)  throws DataAccessException{
		chargebackManagerDao.updateReason(map);
		
	}

	public void deleteReasonDetails(String chargebackReason) throws DataAccessException{
		// TODO Auto-generated method stub
		chargebackManagerDao.deleteReasonDetails(chargebackReason);
		
	}

	public List getAllTypes() throws DataAccessException {
		List rL = chargebackManagerDao.getAllTypes();
		return rL;
	}

	
	//Chargeback Manager Definition
	
	public ResultList getChargeDefinition(Map map) throws DataAccessException {
		ResultList rL = chargebackManagerDao.getChargeDefinition(map);
		return rL;
	}

	public void updateChargeDefinition(List selectedDef) throws DataAccessException {
		chargebackManagerDao.updateChargeDefinition(selectedDef);
	}
	
	public String deleteProductGroupCodeReference(String productCode) throws DataAccessException {
		String productCodeReference = chargebackManagerDao.deleteProductGroupCodeReference(productCode);
		return productCodeReference;
	}
	
	public String deleteRouteReference(String routeId) throws DataAccessException {
		String routeIdReference = chargebackManagerDao.deleteRouteReference(routeId);
		return routeIdReference;
	}
	public ResultList getTypeDetails(Map map)  throws DataAccessException{
		ResultList rL = chargebackManagerDao.getTypeDetails(map);
		return rL;
	}
	public ChargebackManagerBO getEditType(Map map) throws DataAccessException {
		return chargebackManagerDao.getEditType(map);
	}
	public List getAllRoles() throws DataAccessException {
		List l = chargebackManagerDao.getAllRoles();
		return l;
	}
	// AuthorizationAmountByType
		public void saveAmountByType(Map map) throws DataAccessException {
			chargebackManagerDao.saveAmountByType(map);
		}

		public void updateAmountByType(Map map) throws DataAccessException {
			chargebackManagerDao.updateAmountByType(map);
		}

		public void deleteAmountByType(String roleId) throws DataAccessException {
			chargebackManagerDao.deleteAmountByType(roleId);
		}

	// For Authorization By Roles
	public List getRoles() throws DataAccessException {
		List l = chargebackManagerDao.getRoles();

		return l;
	}

	public ResultList getAuthAmount(Map map) throws DataAccessException {
		ResultList rL = chargebackManagerDao.getAuthAmount(map);
		return rL;
	}

	public List getChargeTypes() throws DataAccessException {
		List l = chargebackManagerDao.getChargeTypes();

		return l;
	}

	public void InsertCbkByRole(Map formSearchValuesMap) throws DataAccessException {
		chargebackManagerDao.InsertCbkByRole(formSearchValuesMap);
	}

	public ChargebackManagerBO getAuthRoleDetails(Map searchParametersFrom) throws DataAccessException {
		return chargebackManagerDao.getAuthRoleDetails(searchParametersFrom);
	}

	public void updateAuthByRole(Map formSearchValuesMap) throws DataAccessException {
		chargebackManagerDao.updateAuthByRole(formSearchValuesMap);
	}

	public void deleteAuthRoleDetails(Map searchParametersFromForm) throws DataAccessException {
		chargebackManagerDao.deleteAuthRoleDetails(searchParametersFromForm);
	}
	
	public void saveCreateRouting(Map searchParametersForm) throws DataAccessException {
		chargebackManagerDao.saveCreateRouting(searchParametersForm);
	}

	public ChargebackManagerBO getEditRoutingAppr(Map map) throws DataAccessException {

		return chargebackManagerDao.getEditRoutingAppr(map);
	}

	public ResultList getRoutingDetails(Map map) throws DataAccessException {
		ResultList rL = chargebackManagerDao.getRoutingDetails(map);
		return rL;
	}

	public void updateRouting(Map map) throws DataAccessException {
		chargebackManagerDao.updateRouting(map);
	}

	public void deleteRouting(Map map) throws DataAccessException {
		chargebackManagerDao.deleteRouting(map);
	}

	
	//Regional Administrator

	public ResultList allUsers(Map map) throws DataAccessException {
		ResultList rL = chargebackManagerDao.allUsers(map);
		return rL;
	}
	
	public ResultList specificUserResults(Map map) throws DataAccessException {
		ResultList rL = chargebackManagerDao.specificUserResults(map);
		return rL;
	}
	
	public ResultList specificUserSearch(Map map) throws DataAccessException {
		ResultList rL = chargebackManagerDao.specificUserSearch(map);
		return rL;
	}
	
	public ResultList specificRoleIdSearch(Map map) throws DataAccessException {
		ResultList rL = chargebackManagerDao.specificRoleIdSearch(map);
		return rL;
	}
	
	public List getLocationsForCreateUser() throws DataAccessException {
		List<ChargebackBO>  l= chargebackManagerDao.getLocationsForCreateUser();
		return l;
		
	}

	public List getRolesForUser() throws DataAccessException {
		List l = chargebackManagerDao.getRolesForUser();

		return l;
	}
	
	public ChargebackManagerBO getUserDetails(String userId) throws DataAccessException {
		return chargebackManagerDao.getUserDetails(userId);

	}

	public ResultList getUserRolesLocations(String userId) throws DataAccessException {
		return chargebackManagerDao.getUserRolesLocations(userId);

	}
	
	public List<ChargebackManagerBO> getRolesByUserForMenu() throws DataAccessException {
		List<ChargebackManagerBO> l = chargebackManagerDao.getRolesByUserForMenu();
		return l;
	}
	
	public List getLocations() throws DataAccessException {

		return chargebackManagerDao.getLocations();
	}
	
	public void getCancelChargeback(String invoiceNumber) throws DataAccessException {
		 chargebackManagerDao.getCancelChargeback(invoiceNumber);
	}
	
	
	
	
	// Work with Chargeback  
	
	public String getMaxStepNumberForInvoice(String invoiceNumber) throws DataAccessException {
		String maxStepNumber = chargebackManagerDao.getMaxStepNumberForInvoice(invoiceNumber);
		return maxStepNumber;
	}
	
	/*
	 * public List<ChargebackBO> getChargebackTypes() throws DataAccessException {
	 * List<ChargebackBO> l = chargebackSearchDao.getChargebackTypes();
	 * 
	 * return l; }
	 */
	public List<ChargebackManagerBO> getReasons() throws DataAccessException {
		List<ChargebackManagerBO> l = chargebackManagerDao.getReasons();

		return l;
	}
	
	public List<ChargebackManagerBO> getProductGroup() throws DataAccessException {
		List<ChargebackManagerBO> l = chargebackManagerDao.getProductGroup();

		return l;
	}
	
	public ChargebackManagerBO getChargebackVendor(Map params) throws DataAccessException {
		return chargebackManagerDao.getChargebackVendor(params);
	}

	public ChargebackManagerBO getChargebackDetailInfo(Map params) throws DataAccessException {
		return chargebackManagerDao.getChargebackDetailInfo(params);
	}
	
	public ResultList getCbkDetTable(Map params) throws DataAccessException {
		ResultList rL = chargebackManagerDao.getCbkDetTable(params);
		return rL;
	}
	
	public ResultList getChargebackDistribution(Map params) throws DataAccessException {
		ResultList rL = chargebackManagerDao.getChargebackDistribution(params);
		return rL;
	}
	
	public String getMinStepNumberWithInvoiceAmount(String invoiceNumber,String locationNumber,String typeId) throws DataAccessException{
		String minStepNumber = chargebackManagerDao.getMinStepNumberWithInvoiceAmount(invoiceNumber,locationNumber,typeId);
		return minStepNumber;
	}
	
	public ResultList getApprovalHistory(String invoice) throws DataAccessException {
		ResultList rL = chargebackManagerDao.getApprovalHistory(invoice);
		return rL;
	}
	
	public List<ChargebackManagerBO> getAttachmentName(String invoiceNumber) throws DataAccessException {
		return chargebackManagerDao.getAttachmentName(invoiceNumber);
	}
	
	public String getRoleIdForNextApprover(String invoiceNumber,String typeId,String locationNumber,String userId) throws DataAccessException{
		String maxStepNumber = chargebackManagerDao.getRoleIdForNextApprover(invoiceNumber,typeId,locationNumber,userId);
		return maxStepNumber;
	}
	
	public String getAdminUser(String userId, String roleId) throws DataAccessException {
		String maxStepNumber = chargebackManagerDao.getAdminUser(userId, roleId);
		return maxStepNumber;
	}
	
	public ResultList getChargebackApprovalStatus(String invoiceNumber, String approverId) throws DataAccessException {
		ResultList rL = chargebackManagerDao.getChargebackApprovalStatus(invoiceNumber, approverId);
		return rL;
	}
	
	public String getInvoiceEditableStatus(String invoiceNumber) throws DataAccessException {
		String editableInvoice = chargebackManagerDao.getInvoiceEditableStatus(invoiceNumber);
		return editableInvoice;
	}
	
	
}
