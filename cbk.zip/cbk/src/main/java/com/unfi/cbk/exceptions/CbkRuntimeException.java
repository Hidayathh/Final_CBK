/*
 * Created on Oct 24, 2005
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.unfi.cbk.exceptions;

/**
 * 
 * @author yhp6y2l
 *
 */

public class CbkRuntimeException extends RuntimeException {

	/**
	 * 
	 */
	public CbkRuntimeException() {
		super();
	}

	/**
	 * @param message
	 */
	public CbkRuntimeException(String message) {
		super(message);
	}

	/**
	 * @param message
	 * @param cause
	 */
	public CbkRuntimeException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * @param cause
	 */
	public CbkRuntimeException(Throwable cause) {
		super(cause);
	}
}
