package com.unfi.cbk.utilcore;

import java.sql.Connection;

import javax.sql.DataSource;

//import org.apache.log4j.Logger;

/**
 * 
 * @author yhp6y2l The JNDIDBPool class is used to manage DataSource
 *         connections.
 *
 */

public class JNDIDBPool {
	// static Logger log = Logger.getLogger(JNDIDBPool.class);
	private static DataSource ds = null;

	static {
		try {
			javax.naming.Context context = new javax.naming.InitialContext();
			ds = (javax.sql.DataSource) context.lookup("java:/comp/env/jdbc/epass");

			if (ds == null) {
				// log.error("Null datasource");
			}

		} catch (Exception e) {
			// log.error("Context issues! " + e);
			// e.printStackTrace();
		}

	}

	/**
	 * Gets a connection from the pool. This method returns a
	 * <code>Connection</code> from the connection pool.
	 * 
	 * @return the <code>Connection</code>
	 * @since 1.0
	 */
	public static Connection getConnection() {
		Connection connection = null;
		try {
			connection = ds.getConnection();

		} catch (Exception e) {
			// log.error("Error getting the connection: " + e.getMessage());

		} finally {
			return connection;

		}

	}

	/**
	 * Releases the connection back into the database pool.
	 * 
	 * @param connection the <code>Connection</code> to release
	 * @since 1.0
	 */
	public static void returnConnectionToPool(Connection connection) {
		try {
			// Give the connection back to pool regardless of any exceptions or errors
			if (connection != null) {
				// log.debug("Connection returned to pool.");
				connection.close();
			}

		} catch (Exception e) {
			// Ignore

		}

	}

}