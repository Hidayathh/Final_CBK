package com.unfi.cbk.dao.ibImpl;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.orm.ibatis.SqlMapClientTemplate;
import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;

import com.unfi.cbk.beans.ResultList;
import com.unfi.cbk.bo.ChargebackBO;
import com.unfi.cbk.bo.ChargebackManagerBO;
import com.unfi.cbk.dao.ChargebackManagerDao;
import com.unfi.cbk.exceptions.DataAccessException;

/**
 * The ChargebackManagerDaoImpl class handles the call to the database to get
 * the results of the chargebacks search based on the form values.
 *
 * @author vpil001
 * @since 1.0
 */

public class ChargebackManagerDaoImpl extends SqlMapClientDaoSupport implements ChargebackManagerDao {

	private static Logger log = Logger.getLogger(ChargebackManagerDaoImpl.class);
	protected static Date BAD_DATE = null;

	public ChargebackManagerDaoImpl(SqlMapClientTemplate sqlMapTemplate) {
		this.setSqlMapClientTemplate(sqlMapTemplate);
	}

	/**
	 * 
	 */

	public List<ChargebackManagerBO> getChargebackTypes() throws DataAccessException {

		List<ChargebackManagerBO> l = null;
		try {
			System.out.println("------in Impl---getChargebackTypes()-------");
			l = (List) getSqlMapClientTemplate().queryForList("ChargebackManager.getChargebackTypes");
			System.out
					.println("------------ChargebackManagerDaoImpl.java-getChargebackTypes---List size----" + l.size());

		} catch (Exception e) {
			e.printStackTrace();
			log.error(e);
			throw new DataAccessException(e);
		}

		return l;

	}

	public ResultList getChargebacks(Map formSearchValuesMap) throws DataAccessException {
		ResultList rL = new ResultList();

		try {

			System.out.println("------ChargebackManagerDaoImpl.java-------getChargebacks()------");
			System.out.println("---status::" + formSearchValuesMap.get("status"));
			System.out.println("---apStatus::" + formSearchValuesMap.get("apStatus"));

			rL.setList((List<Integer>) getSqlMapClientTemplate().queryForList("ChargebackManager.getChargebacks",
					formSearchValuesMap));
			System.out.println("------------ChargebackManagerDaoImpl.java--ResultList size----" + rL.getList().size());
			if (rL.getList().size() == 0) {
				rL.setTotalCount(new Integer(0));
			} else if (formSearchValuesMap.get("showAll") != null
					&& ((String) formSearchValuesMap.get("showAll")).equals("true")) {
				rL.setTotalCount(new Integer(rL.getList().size()));
			} else {
				rL.setTotalCount((Integer) getSqlMapClientTemplate()
						.queryForObject("ChargebackManager.getChargebacksCount", formSearchValuesMap));
			}

		} catch (Exception e) {
			e.printStackTrace();
			log.error("Error in getChargebacks() " + e);
			throw new DataAccessException(e);
		}

		return rL;
	}

	public ResultList locationNumberValidator(Map formSearchValuesMap) throws DataAccessException {
		ResultList rL = new ResultList();
		try {
			// HashMap map = new HashMap();
			System.out.println("------in Impl---LocationNumberValidator-------");
			rL.setList((List) getSqlMapClientTemplate().queryForList("ChargebackManager.locationNumberValidator",
					formSearchValuesMap));
			System.out.println("------------ChargebackManagerDaoImpl.java-locationNumberValidator---ResultList size----"
					+ rL.getList().size());

		} catch (Exception e) {
			e.printStackTrace();
			log.error(e);
			throw new DataAccessException(e);
		}
		// checkIfNull(s);
		return rL;
	}

	public ResultList invoiceNumberValidator(Map formSearchValuesMap) throws DataAccessException {
		ResultList rL = new ResultList();
		try {
			// HashMap map = new HashMap();
			System.out.println("------in Impl---invoiceNumberValidator-------");
			rL.setList((List) getSqlMapClientTemplate().queryForList("ChargebackManager.invoiceNumberValidator",
					formSearchValuesMap));
			System.out.println("------------ChargebackManagerDaoImpl.java-locationNumberValidator---ResultList size----"
					+ rL.getList().size());

		} catch (Exception e) {
			e.printStackTrace();
			log.error(e);
			throw new DataAccessException(e);
		}
		// checkIfNull(s);
		return rL;
	}

	public ResultList vendorNumberValidator(Map formSearchValuesMap) throws DataAccessException {
		ResultList rL = new ResultList();
		try {
			// HashMap map = new HashMap();
			System.out.println("------in Impl---vendorNumberValidator-------");
			rL.setList((List) getSqlMapClientTemplate().queryForList("ChargebackManager.vendorNumberValidator",
					formSearchValuesMap));
			System.out.println("------------ChargebackManagerDaoImpl.java-vendorNumberValidator---ResultList size----"
					+ rL.getList().size());

		} catch (Exception e) {
			e.printStackTrace();
			log.error(e);
			throw new DataAccessException(e);
		}
		return rL;
	}

	public ResultList originatorValidator(Map formSearchValuesMap) throws DataAccessException {
		ResultList rL = new ResultList();
		try {
			System.out.println("------in Impl---originatorValidator-------");
			rL.setList((List) getSqlMapClientTemplate().queryForList("ChargebackManager.originatorValidator",
					formSearchValuesMap));
			System.out.println("------------ChargebackManagerDaoImpl.java--originatorValidator---ResultList size----"
					+ rL.getList().size());

		} catch (Exception e) {
			e.printStackTrace();
			log.error(e);
			throw new DataAccessException(e);
		}
		// checkIfNull(s);
		return rL;
	}

	public ResultList approverValidator(Map formSearchValuesMap) throws DataAccessException {
		ResultList rL = new ResultList();
		try {
			System.out.println("------in Impl---approverValidator-------");
			rL.setList((List) getSqlMapClientTemplate().queryForList("ChargebackManager.approverValidator",
					formSearchValuesMap));
			System.out.println("------------ChargebackManagerDaoImpl.java--approverValidator---ResultList size----"
					+ rL.getList().size());

		} catch (Exception e) {
			e.printStackTrace();
			log.error(e);
			throw new DataAccessException(e);
		}
		// checkIfNull(s);
		return rL;
	}

	/**
	 * 
	 */

	public void approveChargebacks(ChargebackBO cbkBo) throws DataAccessException {

		try {
			getSqlMapClientTemplate().insert("ChargebackManager.insertApprovals", cbkBo);
		} catch (Exception e) {
			log.error(e);
			throw new DataAccessException(e);
		}
	}

	@Override
	public String getMaxStepNumber(String typeId, String chargebackTotal) throws DataAccessException {

		String maxStep = null;
		try {

			HashMap<String, String> map = new HashMap<String, String>();
			map.put("typeId", typeId);
			map.put("chargebackTotal", chargebackTotal);
			maxStep = (String) getSqlMapClientTemplate().queryForObject("ChargebackManager.getMaxStepNumber", map);

		} catch (Exception e) {
			e.printStackTrace();
			log.error(e);
			throw new DataAccessException(e);
		}

		return maxStep;
	}

	public void updateChargebackApprover(ChargebackBO chargeBack) throws DataAccessException {
		try {
			System.out.println("-----in DAOIMPL---updateChargeback()---");
			getSqlMapClientTemplate().update("ChargebackManager.updateChargebackApprover", chargeBack);

		} catch (Exception e) {
			log.error(e);
			throw new DataAccessException(e);
		}
	}

	public List<Integer> doChargebackApproverSearch(String typeId, String chargebackTotal, String stepNumber)
			throws DataAccessException {
		List<Integer> l = null;

		try {
			System.out.println("--------ChargebackManagerDaoImpl.java-------doCbkApproverSearch()---" + typeId + ":::"
					+ stepNumber);
			HashMap<String, String> map = new HashMap<String, String>();
			map.put("typeId", typeId);
			map.put("stepNumber", stepNumber);
			map.put("chargebackTotal", chargebackTotal);

			l = getSqlMapClientTemplate().queryForList("ChargebackManager.doCbkApproverSearch", map);
		} catch (Exception e) {
			throw new DataAccessException(e);
		}

		return l;
	}

	@Override
	public ResultList getChargeAccrual(Map map) throws DataAccessException {
		// TODO Auto-generated method stub
		ResultList rL = new ResultList();

		try {

			System.out.println("------ChargebackManagerDaoImpl.java-------getChargeAccrual()------");
			rL.setList((List) getSqlMapClientTemplate().queryForList("ChargebackManager.getChargeAccrual", map));
			System.out.println("------------ChargebackManagerDaoImpl.java--ResultList size----" + rL.getList().size());
			if (rL.getList().size() == 0) {
				rL.setTotalCount(new Integer(0));
			}

		} catch (Exception e) {
			e.printStackTrace();
			log.error("Error in getChargeAccrual() " + e);
			e.printStackTrace();
			throw new DataAccessException(e);
		}

		return rL;
	}

	@Override
	public ResultList getChargebackRoles(Map map) throws DataAccessException {
		// TODO Auto-generated method stub
		ResultList rL = new ResultList();

		try {

			System.out.println("------ChargebackManagerDaoImpl.java-------getChargebackRoles()------");
			rL.setList((List) getSqlMapClientTemplate().queryForList("ChargebackManager.getChargebackRoles", map));
			System.out.println("------------ChargebackManagerDaoImpl.java--ResultList size----" + rL.getList().size());
			if (rL.getList().size() == 0) {
				rL.setTotalCount(new Integer(0));
			}

		} catch (Exception e) {
			e.printStackTrace();
			log.error("Error in getChargebackRoles() " + e);
			e.printStackTrace();
			throw new DataAccessException(e);
		}

		return rL;
	}

	// Product GRoup

	@Override
	public ResultList getProductGroup(Map map) throws DataAccessException {
		// TODO Auto-generated method stub
		ResultList rL = new ResultList();

		try {

			System.out.println("------ChargebackManagerDaoImpl.java-------getProductGroup()------");
			rL.setList((List) getSqlMapClientTemplate().queryForList("ChargebackManager.getProductGroup", map));
			System.out.println("------------ChargebackManagerDaoImpl.java--ResultList size----" + rL.getList().size());
			if (rL.getList().size() == 0) {
				rL.setTotalCount(new Integer(0));
			}

		} catch (Exception e) {
			e.printStackTrace();
			log.error("Error in getProductGroup() " + e);
			e.printStackTrace();
			throw new DataAccessException(e);
		}

		return rL;
	}

	@Override
	public void InsertProductCode(Map formSearchValuesMap) throws DataAccessException {

		try {

			System.out.println("---BEFORE ADD--in ChargebackSearchDaoImpl.java----InsertProductCode()-----");
			getSqlMapClientTemplate().insert("ChargebackManager.createNewProduct", formSearchValuesMap);

		} catch (Exception e) {
			e.printStackTrace();
			log.error(e);
			throw new DataAccessException(e);
		}

	}

	@Override
	public ChargebackManagerBO getProductDetails(String productCode) throws DataAccessException {
		ChargebackManagerBO c = null;

		try {

			HashMap map = new HashMap();
			System.out.println("------in Impl---getProductDetails()-------");
			map.put("productCode", productCode);
			c = (ChargebackManagerBO) getSqlMapClientTemplate().queryForObject("ChargebackManager.getProductDetails",
					map);

		} catch (Exception e) {
			log.error(e);
			throw new DataAccessException(e);
		}

		// checkIfNull(c);
		return c;

	}

	@Override
	public void deleteProductDetails(String productCode) throws DataAccessException {
		// TODO Auto-generated method stub
		try {
			System.out.println("---userid to delete---" + productCode);
			Map map = new HashMap();
			map.put("productCode", productCode);
			System.out.println("----userId from map ---" + map.get("productCode"));

			getSqlMapClientTemplate().delete("ChargebackManager.deleteProductDetails", map);

			System.out.println("----AFTER DELETE----");

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void updateProductCode(Map formSearchValuesMap) throws DataAccessException {
		try {
			System.out.println("---BEFORE update--in ChargebackManagerDaoImpl.java----updateProductCode()-----");
			getSqlMapClientTemplate().update("ChargebackManager.updateProductCode", formSearchValuesMap);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// Excluded Vendor
	@Override
	public ResultList getExcludedVendor(Map map) throws DataAccessException {
		// TODO Auto-generated method stub
		ResultList rL = new ResultList();

		try {

			System.out.println("------ChargebackManagerDaoImpl.java-------getProductGroup()------");
			rL.setList((List) getSqlMapClientTemplate().queryForList("ChargebackManager.getExcludedVendor", map));
			System.out.println("------------ChargebackManagerDaoImpl.java--ResultList size----" + rL.getList().size());
			if (rL.getList().size() == 0) {
				rL.setTotalCount(new Integer(0));
			}

		} catch (Exception e) {
			e.printStackTrace();
			log.error("Error in getExcludedVendor() " + e);
			e.printStackTrace();
			throw new DataAccessException(e);
		}

		return rL;
	}

	@Override
	public void InsertExcludedVendor(Map formSearchValuesMap) throws DataAccessException {

		try {

			System.out.println("---BEFORE ADD--in ChargebackSearchDaoImpl.java----InsertExcludedVendor()-----");
			getSqlMapClientTemplate().insert("ChargebackManager.InsertExcludedVendor", formSearchValuesMap);

		} catch (Exception e) {
			e.printStackTrace();
			log.error(e);
			throw new DataAccessException(e);
		}

	}

	@Override
	public ChargebackManagerBO getVendorDetails(String vendor) throws DataAccessException {
		ChargebackManagerBO c = null;

		try {

			HashMap map = new HashMap();
			System.out.println("------in Impl---getVendorDetails()-------");
			map.put("vendor", vendor);
			c = (ChargebackManagerBO) getSqlMapClientTemplate().queryForObject("ChargebackManager.getVendorDetails",
					map);

		} catch (Exception e) {
			log.error(e);
			throw new DataAccessException(e);
		}
		return c;

	}

	public void updateVendor(Map formSearchValuesMap) throws DataAccessException {
		try {
			System.out.println("---BEFORE update--in ChargebackManagerDaoImpl.java----updateVendor()-----");
			getSqlMapClientTemplate().update("ChargebackManager.updateVendor", formSearchValuesMap);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public void deleteExcludedVend(String vendor) throws DataAccessException {
		// TODO Auto-generated method stub
		try {
			System.out.println("---userid to delete---" + vendor);
			Map map = new HashMap();
			map.put("vendor", vendor);
			System.out.println("----userId from map ---" + map.get("vendor"));
			getSqlMapClientTemplate().delete("ChargebackManager.deleteExcludedVend", map);
			System.out.println("----AFTER DELETE----");
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	// Route Name

	@Override
	public ResultList getRouteName(Map map) throws DataAccessException {
		// TODO Auto-generated method stub
		ResultList rL = new ResultList();

		try {

			System.out.println("------ChargebackManagerDaoImpl.java-------getRouteName()------");
			rL.setList((List) getSqlMapClientTemplate().queryForList("ChargebackManager.getRouteName", map));
			System.out.println("------------ChargebackManagerDaoImpl.java--ResultList size----" + rL.getList().size());
			if (rL.getList().size() == 0) {
				rL.setTotalCount(new Integer(0));
			}

		} catch (Exception e) {
			e.printStackTrace();
			log.error("Error in getRouteName() " + e);
			e.printStackTrace();
			throw new DataAccessException(e);
		}

		return rL;
	}

	@Override
	public void InsertRouteName(Map formSearchValuesMap) throws DataAccessException {

		try {

			System.out.println("---BEFORE ADD--in ChargebackSearchDaoImpl.java----InsertRouteName()-----");
			getSqlMapClientTemplate().insert("ChargebackManager.InsertRouteName", formSearchValuesMap);

		} catch (Exception e) {
			e.printStackTrace();
			log.error(e);
			throw new DataAccessException(e);
		}

	}

	@Override
	public ChargebackManagerBO getRouteDetails(String routeId) throws DataAccessException {
		ChargebackManagerBO c = null;

		try {

			HashMap map = new HashMap();
			System.out.println("------in Impl---getRouteDetails()-------");
			map.put("routeId", routeId);
			c = (ChargebackManagerBO) getSqlMapClientTemplate().queryForObject("ChargebackManager.getRouteDetails",
					map);

		} catch (Exception e) {
			log.error(e);
			throw new DataAccessException(e);
		}

		// checkIfNull(c);
		return c;
	}

	public void updateRouteName(Map formSearchValuesMap) throws DataAccessException {
		try {
			System.out.println("---BEFORE update--in ChargebackManagerDaoImpl.java----updateRouteName()-----");
			getSqlMapClientTemplate().update("ChargebackManager.updateRouteName", formSearchValuesMap);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public void deleteRouteDetails(String routeId) throws DataAccessException {
		// TODO Auto-generated method stub
		try {
			System.out.println("---userid to delete---" + routeId);
			Map map = new HashMap();
			map.put("routeId", routeId);
			System.out.println("----userId from map ---" + map.get("routeId"));
			getSqlMapClientTemplate().delete("ChargebackManager.deleteRouteDetails", map);
			System.out.println("----AFTER DELETE----");

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Override
	public ChargebackManagerBO getRouteId(Map map) throws DataAccessException {
		ChargebackManagerBO c = null;

		try {
			System.out.println("------in Impl---getRouteDetails()-------");

			c = (ChargebackManagerBO) getSqlMapClientTemplate().queryForObject("ChargebackManager.getRouteId", map);

		} catch (Exception e) {
			log.error(e);
			throw new DataAccessException(e);
		}

		// checkIfNull(c);
		return c;
	}

	@Override
	public ResultList getAuditResults(Map map) throws DataAccessException {
		ResultList rL = new ResultList();

		try {

			System.out.println("------ChargebackManagerDaoImpl.java-------getAuditResults()------");
			rL.setList((List) getSqlMapClientTemplate().queryForList("ChargebackManager.getAuditResults", map));
			System.out.println("------------ChargebackManagerDaoImpl.java--ResultList size----" + rL.getList().size());
			if (rL.getList().size() == 0) {
				rL.setTotalCount(new Integer(0));
			}

		} catch (Exception e) {
			e.printStackTrace();
			log.error("Error in getAuditResults() " + e);
			e.printStackTrace();
			throw new DataAccessException(e);
		}
		return rL;

	}

	public ResultList getCbkLocDetails(Map map) throws DataAccessException {
		ResultList rL = new ResultList();

		try {

			System.out.println("------ChargebackManagerDaoImpl.java-------getCbkLocDetails()------");
			rL.setList((List) getSqlMapClientTemplate().queryForList("AdminData.getCbkLocations", map));
			System.out
					.println("------------ChargebackManagerDaoImpl.java--getCbkLocDetails()----" + rL.getList().size());

			if (rL.getList().size() == 0) {
				rL.setTotalCount(new Integer(0));
			}

		} catch (Exception e) {
			e.printStackTrace();
			log.error("Error in getCbkLocDetails() " + e);
			e.printStackTrace();
			throw new DataAccessException(e);
		}
		return rL;

	}

	@Override
	public void saveCreateLocation(Map searchParametersFrom) throws DataAccessException {

		try {

			System.out.println("---BeforeQuery---ChargebackManagerDaoImpl.java-------saveCreateLocation()------");
			getSqlMapClientTemplate().insert("AdminData.saveCreateLocation", searchParametersFrom);
			System.out.println("---------AfterQuery---ChargebackManagerDaoImpl.java--saveCreateLocation---");

		} catch (Exception e) {
			e.printStackTrace();
			log.error("Error in saveCreateLocation() " + e);
			e.printStackTrace();
			throw new DataAccessException(e);
		}

	}

	@Override
	public ResultList getReasonResults() throws DataAccessException {
		ResultList rL = new ResultList();

		try {

			System.out.println("------ChargebackManagerDaoImpl.java-------getReasonResults()------");
			rL.setList((List) getSqlMapClientTemplate().queryForList("AdminData.getReasonCodes"));
			System.out
					.println("------------ChargebackManagerDaoImpl.java--getReasonResults()----" + rL.getList().size());
			if (rL.getList().size() == 0) {
				rL.setTotalCount(new Integer(0));
			}

		} catch (Exception e) {
			e.printStackTrace();
			log.error("Error in getCbkLocDetails() " + e);
			e.printStackTrace();
			throw new DataAccessException(e);
		}
		System.out.println(rL.getList().get(0));
		System.out.println(rL);
		return rL;

	}

	/**
	 * Check if an object is null and throw a DataAccessException if it is.
	 * 
	 * @param o the object to test
	 * @throws DataAccessException whenever the object is null
	 */
	private void checkIfNull(Object o) throws DataAccessException {
		if (o == null) {
			throw new DataAccessException("Object not found.");
		}
	}

	@Override
	public ChargebackManagerBO getEditLocDetails(String locationNumber) throws DataAccessException {
		ChargebackManagerBO c = null;

		try {

			HashMap map = new HashMap();
			System.out.println("------in Impl---getUserDetails()-------");
			map.put("locationNumber", locationNumber);
			c = (ChargebackManagerBO) getSqlMapClientTemplate().queryForObject("AdminData.getLocationDetails", map);

		} catch (Exception e) {
			log.error(e);
			throw new DataAccessException(e);
		}

		checkIfNull(c);
		return c;
	}

	@Override
	public void saveCreateReason(Map searchParametersFromForm) throws DataAccessException {
		try {

			System.out.println("---BeforeQuery---ChargebackManagerDaoImpl.java-------saveCreateLocation()------");
			getSqlMapClientTemplate().insert("AdminData.saveCreateReason", searchParametersFromForm);
			System.out.println("---------AfterQuery---ChargebackManagerDaoImpl.java--saveCreateLocation---");

		} catch (Exception e) {
			e.printStackTrace();
			log.error("Error in saveCreateLocation() " + e);
			e.printStackTrace();
			throw new DataAccessException(e);
		}

	}

	@Override
	public ChargebackManagerBO getReasonDetails(String chargebackReason) throws DataAccessException {
		ChargebackManagerBO c = null;

		try {

			HashMap map = new HashMap();
			System.out.println("------in Impl---getReasonDetails()-------");
			map.put("chargebackReason", chargebackReason);
			c = (ChargebackManagerBO) getSqlMapClientTemplate().queryForObject("AdminData.getReasonDetails", map);

		} catch (Exception e) {
			log.error(e);
			throw new DataAccessException(e);
		}

		checkIfNull(c);
		return c;

	}

	@Override
	public void deleteLocDetails(String locationNumber) throws DataAccessException {
		// TODO Auto-generated method stub
		try {

			HashMap map = new HashMap();
			System.out.println("------in Impl---deleteLocDetails()-------");
			map.put("locationNumber", locationNumber);
			getSqlMapClientTemplate().delete("AdminData.deleteLocDetails", map);

		} catch (Exception e) {
			log.error(e);
			throw new DataAccessException(e);
		}

	}

	@Override
	public void updateLocation(Map map) throws DataAccessException {
		try {

			System.out.println("------in Impl---updateLocation()-------");
			getSqlMapClientTemplate().update("AdminData.updateLocation", map);
			System.out.println("---after query---in Impl---updateLocation()-------");
		} catch (Exception e) {
			log.error(e);
			throw new DataAccessException(e);
		}

	}

	@Override
	public void updateReason(Map map) throws DataAccessException {
		try {

			System.out.println("------in Impl---updateReason()-------");
			getSqlMapClientTemplate().update("AdminData.updateReason", map);
			System.out.println("---after query---in Impl---updateReason()-------");
		} catch (Exception e) {
			log.error(e);
			throw new DataAccessException(e);
		}

	}

	@Override
	public void deleteReasonDetails(String chargebackReason) throws DataAccessException {
		try {
			HashMap map = new HashMap();
			System.out.println("------in Impl---deleteReasonDetails()-------");
			map.put("chargebackReason", chargebackReason);
			getSqlMapClientTemplate().delete("AdminData.deleteReasonDetails", map);
			System.out.println("---after query---in Impl---deleteReasonDetails()-------");

		} catch (Exception e) {
			log.error(e);
			throw new DataAccessException(e);
		}

	}

	@Override
	public List getAllTypes() throws DataAccessException {

		List l = null;
		try {
			// HashMap map = new HashMap();
			System.out.println("------in Impl---getAllTypes()-------");
			l = (List) getSqlMapClientTemplate().queryForList("AdminData.getAllTypes");
			System.out.println("------------ChargebackManagerDaoImpl.java-getAllTypes---List size----" + l.size());

		} catch (Exception e) {
			e.printStackTrace();
			log.error(e);
			throw new DataAccessException(e);
		}
		System.out.println(l);
		return l;

	}

	@Override
	public ResultList getChargeDefinition(Map map) throws DataAccessException {
		// TODO Auto-generated method stub
		ResultList rL = new ResultList();

		try {

			System.out.println("------ChargebackManagerDaoImpl.java-------getChargeDefinition()------");
			rL.setList((List) getSqlMapClientTemplate().queryForList("ChargebackManager.getChargeDefinition", map));
			System.out.println("------------ChargebackManagerDaoImpl.java--ResultList size----" + rL.getList().size());

		} catch (Exception e) {
			e.printStackTrace();
			log.error("Error in getChargeDefinition() " + e);
			e.printStackTrace();
			throw new DataAccessException(e);
		}

		return rL;
	}

	public void updateChargeDefinition(List selectedDef) throws DataAccessException {
		try {
			if (selectedDef.size() > 0) {
				
				
				for (int i = 0; i < selectedDef.size(); i++) {
					HashMap<String, String> map = new HashMap<String, String>();
					System.out.println("Selected----"+selectedDef.get(i));
			System.out.println("---BEFORE update--in ChargebackManagerDaoImpl.java----updateChargeDefinition()-----");
			map = (HashMap<String, String>) selectedDef.get(i);
			getSqlMapClientTemplate().update("ChargebackManager.updateChargeDefinition", map);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
		

	
	
	// authorizationAmountByType and role

	@Override
	public void saveAmountByType(Map map) throws DataAccessException {
		// TODO Auto-generated method stub
		try {

			System.out.println("---BeforeQuery---ChargebackManagerDaoImpl.java-------saveCreateByType()------" + map);
			getSqlMapClientTemplate().insert("AdminData.InsertAmountType", map);
			System.out.println("---------AfterQuery---ChargebackManagerDaoImpl.java--saveCreateByType---");

		} catch (Exception e) {
			e.printStackTrace();
			log.error("Error in saveCreateByType() " + e);
			e.printStackTrace();
			throw new DataAccessException(e);
		}

	}

	@Override
	public void updateAmountByType(Map map) throws DataAccessException {
		// TODO Auto-generated method stub
		try {

			System.out.println("------in Impl---updateReason()-------");
			getSqlMapClientTemplate().update("AdminData.updateAmountType", map);
			System.out.println("---after query---in Impl---updateReason()-------");
		} catch (Exception e) {
			log.error(e);
			throw new DataAccessException(e);
		}

	}

	@Override
	public void deleteAmountByType(String roleId) throws DataAccessException {
		// TODO Auto-generated method stub
		try {
			HashMap map = new HashMap();
			System.out.println("------in Impl---deleteByTypeDetails()-------");
			map.put("roleId", roleId);
			getSqlMapClientTemplate().delete("AdminData.deleteByTypeDetails", map);
			System.out.println("---after query---in Impl---deleteByTypeDetails()-------");

		} catch (Exception e) {
			log.error(e);
			throw new DataAccessException(e);
		}
	}

	@Override
	public List getAllRoles() throws DataAccessException {
		List l = null;
		try {
			// HashMap map = new HashMap();
			l = (List) getSqlMapClientTemplate().queryForList("AdminData.getAllRoles");
			System.out.println("------------ChargebackManagerDaoImpl.java-getRoles---List size----" + l.size());

		} catch (Exception e) {
			e.printStackTrace();
			log.error(e);
			throw new DataAccessException(e);
		}
		System.out.println(l);
		return l;
	}

	@Override
	public String deleteProductGroupCodeReference(String productCode) throws DataAccessException {

		String productCodeReference = null;
		try {

			HashMap<String, String> map = new HashMap<String, String>();
			map.put("productCode", productCode);

			productCodeReference = (String) getSqlMapClientTemplate()
					.queryForObject("ChargebackManager.deleteProductGroupCodeReference", map);

		} catch (Exception e) {
			e.printStackTrace();
			log.error(e);
			throw new DataAccessException(e);
		}

		return productCodeReference;
	}

	@Override
	public String deleteRouteReference(String routeId) throws DataAccessException {

		String routeIdReference = null;
		try {

			HashMap<String, String> map = new HashMap<String, String>();
			map.put("routeId", routeId);

			routeIdReference = (String) getSqlMapClientTemplate()
					.queryForObject("ChargebackManager.deleteRouteReference", map);

		} catch (Exception e) {
			e.printStackTrace();
			log.error(e);
			throw new DataAccessException(e);
		}

		return routeIdReference;
	}

	@Override
	public ResultList getTypeDetails(Map map) throws DataAccessException {
		ResultList rL = new ResultList();

		try {

			System.out.println("------ChargebackManagerDaoImpl.java-------getTypeDetails()------");
			rL.setList((List) getSqlMapClientTemplate().queryForList("AdminData.getAuthTypeDetails", map));
			System.out.println("------------ChargebackManagerDaoImpl.java--ResultList size----" + rL.getList().size());
			if (rL.getList().size() == 0) {
				rL.setTotalCount(new Integer(0));
			}

		} catch (Exception e) {
			e.printStackTrace();
			log.error("Error in getTypeDetails() " + e);
			e.printStackTrace();
			throw new DataAccessException(e);
		}

		return rL;
	}

	@Override
	public ChargebackManagerBO getEditType(Map map) throws DataAccessException {
		ChargebackManagerBO c = null;

		try {

			System.out.println("------in Impl---getEditType()-------");
			c = (ChargebackManagerBO) getSqlMapClientTemplate().queryForObject("AdminData.getEditType", map);
		} catch (Exception e) {
			log.error(e);
			throw new DataAccessException(e);
		}

		// checkIfNull(c);
		return c;
	}
	// Authorization By Role

	@Override
	public List getRoles() throws DataAccessException {
		// TODO Auto-generated method stub

		List l = null;
		try {
			// HashMap map = new HashMap();
			System.out.println("------in Impl---getRoles()-------");
			l = (List) getSqlMapClientTemplate().queryForList("ChargebackManager.getRoles");
			System.out.println("------------ChargebackManagerDaoImpl.java-getRoles---List size----" + l.size());

		} catch (Exception e) {
			e.printStackTrace();
			log.error(e);
			throw new DataAccessException(e);
		}

		return l;
	}

	@Override
	public ResultList getAuthAmount(Map map) throws DataAccessException {
		// TODO Auto-generated method stub
		ResultList rL = new ResultList();

		try {

			System.out.println("------ChargebackManagerDaoImpl.java-------getAuthAmount()------");
			rL.setList((List) getSqlMapClientTemplate().queryForList("ChargebackManager.getAuthAmount", map));
			System.out.println("------------ChargebackManagerDaoImpl.java--ResultList size----" + rL.getList().size());

		} catch (Exception e) {
			e.printStackTrace();
			log.error("Error in getAuthAmount() " + e);
			e.printStackTrace();
			throw new DataAccessException(e);
		}

		return rL;
	}

	@Override
	public List getChargeTypes() throws DataAccessException {
		// TODO Auto-generated method stub

		List l = null;
		try {
			// HashMap map = new HashMap();
			System.out.println("------in Impl---getChargeTypes()-------");
			l = (List) getSqlMapClientTemplate().queryForList("ChargebackManager.getChargeTypes");
			System.out.println("------------AdminDaoImpl.java-getChargeTypes---List size----" + l.size());

		} catch (Exception e) {
			e.printStackTrace();
			log.error(e);
			throw new DataAccessException(e);
		}

		return l;
	}

	@Override
	public void InsertCbkByRole(Map formSearchValuesMap) throws DataAccessException {

		try {

			System.out.println("---BEFORE ADD--in ChargebackManagerDaoImpl.java----InsertCbkByRole()-----");
			getSqlMapClientTemplate().insert("ChargebackManager.InsertCbkByRole", formSearchValuesMap);

		} catch (Exception e) {
			e.printStackTrace();
			log.error(e);
			throw new DataAccessException(e);
		}

	}

	@Override
	public ChargebackManagerBO getAuthRoleDetails(Map searchParametersFrom) throws DataAccessException {
		ChargebackManagerBO c = null;

		try {

			System.out.println("------in Impl---getAuthRoleDetails()-------");

			c = (ChargebackManagerBO) getSqlMapClientTemplate().queryForObject("ChargebackManager.getAuthRoleDetails",
					searchParametersFrom);

		} catch (Exception e) {
			log.error(e);
			throw new DataAccessException(e);
		}

		// checkIfNull(c);
		return c;
	}

	public void updateAuthByRole(Map formSearchValuesMap) throws DataAccessException {
		try {
			System.out.println("---BEFORE update--in ChargebackManagerDaoImpl.java----updateAuthByRole()-----");
			getSqlMapClientTemplate().update("ChargebackManager.updateAuthByRole", formSearchValuesMap);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public void deleteAuthRoleDetails(Map searchParametersFromForm) throws DataAccessException {
		// TODO Auto-generated method stub
		try {
			
			getSqlMapClientTemplate().delete("ChargebackManager.deleteAuthRoleDetails", searchParametersFromForm);
			System.out.println("----AFTER DELETE----");

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	@Override
	public ResultList getRoutingDetails(Map map) throws DataAccessException {
		ResultList rL = new ResultList();

		try {

			System.out.println("------ChargebackManagerDaoImpl.java-------getRoutingDetails()------");
			rL.setList((List) getSqlMapClientTemplate().queryForList("ChargebackManager.getRoutingDetails", map));
			System.out.println("------------ChargebackManagerDaoImpl.java--ResultList size----" + rL.getList().size());

		} catch (Exception e) {
			e.printStackTrace();
			log.error("Error in getRoutingDetails() " + e);
			e.printStackTrace();
			throw new DataAccessException(e);
		}

		return rL;
	}

	@Override
	public void saveCreateRouting(Map map) throws DataAccessException {
		try {

			System.out.println("---BEFORE ADD--in ChargebackManagerDaoImpl.java----saveCreateRouting()-----");
			getSqlMapClientTemplate().insert("ChargebackManager.InsertRouting", map);

		} catch (Exception e) {
			e.printStackTrace();
			log.error(e);
			throw new DataAccessException(e);
		}

	}

	@Override
	public ChargebackManagerBO getEditRoutingAppr(Map map) throws DataAccessException {
		ChargebackManagerBO c = null;

		try {

			System.out.println("------in Impl---getEditRoutingAppr()-------");

			c = (ChargebackManagerBO) getSqlMapClientTemplate().queryForObject("ChargebackManager.getEditRouting", map);

		} catch (Exception e) {
			log.error(e);
			throw new DataAccessException(e);
		}

		
		return c;
	}

	@Override
	public void updateRouting(Map map) throws DataAccessException {
		try {
			System.out.println("---BEFORE update--in ChargebackManagerDaoImpl.java----updateRouting()-----");
			getSqlMapClientTemplate().update("ChargebackManager.updateRouting", map);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Override
	public void deleteRouting(Map map) throws DataAccessException {
		try {
			System.out.println("----BEFORE DELETE--in ManagerDAOImpl--");
			getSqlMapClientTemplate().delete("ChargebackManager.deleteRouting", map);
			System.out.println("----AFTER DELETE----");

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	// Regional Administrators

	@Override
	public ResultList allUsers(Map map) throws DataAccessException {
		// TODO Auto-generated method stub
		ResultList rL = new ResultList();

		try {
			System.out.println("------ChargebackManagerDaoImpl.java-------allUsers()------");
			rL.setList((List) getSqlMapClientTemplate().queryForList("ChargebackManager.allUsers", map));
			System.out.println("------------ChargebackManagerDaoImpl.java--ResultList size----" + rL.getList().size());
			if (rL.getList().size() == 0) {
				rL.setTotalCount(new Integer(0));
			} else if (map.get("showAll") != null && ((String) map.get("showAll")).equals("true")) {
				rL.setTotalCount(new Integer(rL.getList().size()));
			} else {
				rL.setTotalCount(
						(Integer) getSqlMapClientTemplate().queryForObject("ChargebackManager.allUsersCount", map));
			}

		} catch (Exception e) {
			e.printStackTrace();
			log.error("Error in allUsers() " + e);
			e.printStackTrace();
			throw new DataAccessException(e);
		}

		return rL;
	}

	@Override
	public ResultList specificUserResults(Map map) throws DataAccessException {
		// TODO Auto-generated method stub
		ResultList rL = new ResultList();

		try {

			System.out.println("------ChargebackManagerDaoImpl.java-------specificUserResults()------");
			rL.setList((List) getSqlMapClientTemplate().queryForList("ChargebackManager.specificUserResults", map));
			System.out.println("------------ChargebackManagerDaoImpl.java--specificUserResults()--ResultList size----"
					+ rL.getList().size());
			if (rL.getList().size() == 0) {
				rL.setTotalCount(new Integer(0));
			} else if (map.get("showAll") != null && ((String) map.get("showAll")).equals("true")) {
				rL.setTotalCount(new Integer(rL.getList().size()));
			} else {
				rL.setTotalCount((Integer) getSqlMapClientTemplate()
						.queryForObject("ChargebackManager.specificUserResultsCount", map));
			}

		} catch (Exception e) {
			e.printStackTrace();
			log.error("Error in specificUserResults() " + e);
			e.printStackTrace();
			throw new DataAccessException(e);
		}

		return rL;
	}

	@Override
	public ResultList specificUserSearch(Map map) throws DataAccessException {
		// TODO Auto-generated method stub
		ResultList rL = new ResultList();

		try {

			System.out.println("------ChargebackManagerDaoImpl.java-------specificUserSearch()------");
			rL.setList((List) getSqlMapClientTemplate().queryForList("ChargebackManager.specificUserSearch", map));
			System.out.println("------------ChargebackManagerDaoImpl.java--specificUserSearch()--ResultList size----"
					+ rL.getList().size());
			if (rL.getList().size() == 0) {
				rL.setTotalCount(new Integer(0));
			} else {
				rL.setTotalCount(new Integer(rL.getList().size()));
			}

		} catch (Exception e) {
			e.printStackTrace();
			log.error("Error in specificUserSearch() " + e);
			e.printStackTrace();
			throw new DataAccessException(e);
		}

		return rL;
	}

	@Override
	public ResultList specificRoleIdSearch(Map map) throws DataAccessException {
		// TODO Auto-generated method stub
		ResultList rL = new ResultList();

		try {

			System.out.println("------ChargebackManagerDaoImpl.java-------specificRoleIdSearch()------");
			rL.setList((List) getSqlMapClientTemplate().queryForList("ChargebackManager.specificRoleIdSearch", map));
			System.out.println("------------ChargebackManagerDaoImpl.java--specificRoleIdSearch()--ResultList size----"
					+ rL.getList().size());
			if (rL.getList().size() == 0) {
				rL.setTotalCount(new Integer(0));
			} else if (map.get("showAll") != null && ((String) map.get("showAll")).equals("true")) {
				rL.setTotalCount(new Integer(rL.getList().size()));
			} else {
				rL.setTotalCount((Integer) getSqlMapClientTemplate()
						.queryForObject("ChargebackManager.specificRoleIdSearchCount", map));
			}

		} catch (Exception e) {
			e.printStackTrace();
			log.error("Error in specificRoleIdSearch() " + e);
			e.printStackTrace();
			throw new DataAccessException(e);
		}

		return rL;
	}

	@Override
	public List getLocationsForCreateUser() throws DataAccessException {
		List l = null;
		try {
			// HashMap map = new HashMap();
			System.out.println("------in ChargebackManagerDaoImpl---getLocationsForCreateUser()-------");
			l = (List) getSqlMapClientTemplate().queryForList("ChargebackManager.getLocationsForCreateUser");
			System.out.println(
					"------------ChargebackManagerDaoImpl.java-getLocationsForCreateUser---List size----" + l.size());

		} catch (Exception e) {
			e.printStackTrace();
			log.error(e);
			throw new DataAccessException(e);
		}

		return l;
	}

	@Override
	public List getRolesForUser() throws DataAccessException {
		// TODO Auto-generated method stub

		List l = null;
		try {
			// HashMap map = new HashMap();
			System.out.println("------in Impl---getRoles()-------");
			l = (List) getSqlMapClientTemplate().queryForList("ChargebackManager.getRolesForUser");
			System.out.println("------------ChargebackManagerDaoImpl.java-getRolesForUser---List size----" + l.size());

		} catch (Exception e) {
			e.printStackTrace();
			log.error(e);
			throw new DataAccessException(e);
		}

		return l;
	}

	@Override
	public ResultList getUserRolesLocations(String userId) throws DataAccessException {
		ResultList rL = new ResultList();
		try {

			HashMap map = new HashMap();
			System.out.println("------in Impl---getUserRolesLocations()-------");
			map.put("userId", userId);
			rL.setList((List) getSqlMapClientTemplate().queryForList("ChargebackManager.getUserRolesLocations", map));

		} catch (Exception e) {
			log.error(e);
			throw new DataAccessException(e);
		}
		// checkIfNull(l);
		return rL;
	}

	@Override
	public ChargebackManagerBO getUserDetails(String userId) throws DataAccessException {
		ChargebackManagerBO c = null;

		try {

			HashMap map = new HashMap();
			System.out.println("------in Impl---getUserDetails()-------");
			map.put("userId", userId);
			c = (ChargebackManagerBO) getSqlMapClientTemplate().queryForObject("ChargebackManager.getUserDetails", map);

		} catch (Exception e) {
			log.error(e);
			throw new DataAccessException(e);
		}

		checkIfNull(c);
		return c;

	}

	@Override
	public List<ChargebackManagerBO> getRolesByUserForMenu() throws DataAccessException {
		// TODO Auto-generated method stub
		List<ChargebackManagerBO> l = null;
		try {
			// HashMap map = new HashMap();
			System.out.println("------in Impl---getRolesByUserForMenu()-------");
			l = (List) getSqlMapClientTemplate().queryForList("ChargebackManager.getRolesByUserForMenuAccess");
			System.out.println("------------ChargebackManagerDaoImpl.java-getRolesByUserForMenu---List size----" + l.size());

		} catch (Exception e) {
			e.printStackTrace();
			log.error(e);
			throw new DataAccessException(e);
		}

		return l;
	}
	@Override
	public List getLocations() throws DataAccessException {
		List l = null;
		
		try {
			System.out.println("------in Impl---getLocations()-------");
			l = (List) getSqlMapClientTemplate().queryForList("ChargebackManager.getAllLocations");
			System.out.println("------------ChargebackManagerDaoImpl.java-getLocations---List size----" + l.size());

		} catch (Exception e) {
			e.printStackTrace();
			log.error(e);
			throw new DataAccessException(e);
		}

		return l;
	}
	
	//Work with chargebcks
	public void getCancelChargeback(String  invoiceNumber) throws DataAccessException{
		String status =  null;
		try {
			System.out.println("--- update--in ChargebackManagerDaoImpl.java----getCancelChargeback()-----");
			getSqlMapClientTemplate().update("ChargebackManager.getCancelChargeback", invoiceNumber);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Override
	public String getMaxStepNumberForInvoice(String invoiceNumber) throws DataAccessException {

		String maxStepNumber = null;
		try {

			maxStepNumber = (String) getSqlMapClientTemplate()
					.queryForObject("ChargebackManager.getMaxStepNumberForInvoice", invoiceNumber);

		} catch (Exception e) {
			e.printStackTrace();
			log.error(e);
			throw new DataAccessException(e);
		}

		return maxStepNumber;
	}
	
	public List getReasons() throws DataAccessException {

		List l = null;
		try {
			l = (List) getSqlMapClientTemplate().queryForList("ChargebackManager.getReasons");
		} catch (Exception e) {
			e.printStackTrace();
			log.error(e);
			throw new DataAccessException(e);
		}
		return l;
	}
	
	public List getProductGroup() throws DataAccessException {

		List l = null;
		try {
			// HashMap map = new HashMap();
			l = (List) getSqlMapClientTemplate().queryForList("ChargebackManager.getProductGroups");

		} catch (Exception e) {
			e.printStackTrace();
			log.error(e);
			throw new DataAccessException(e);
		}
		return l;
	}
	
	public ChargebackManagerBO getChargebackVendor(Map formSearchValuesMap) throws DataAccessException {
		ChargebackManagerBO c = null;

		try {
			c = (ChargebackManagerBO) getSqlMapClientTemplate().queryForObject("ChargebackManager.getVendorInfo",
					formSearchValuesMap);

		} catch (Exception e) {
			log.error(e);
			throw new DataAccessException(e);
		}

		// checkIfNull(c);
		return c;
	}
	
	public ChargebackManagerBO getChargebackDetailInfo(Map formSearchValuesMap) throws DataAccessException {
		ChargebackManagerBO c = null;

		try {
			// HashMap map = new HashMap();
			// map.put("authCode", authCode);

			c = (ChargebackManagerBO) getSqlMapClientTemplate().queryForObject("ChargebackManager.getChargebackDetailInfo",
					formSearchValuesMap);

		} catch (Exception e) {
			log.error(e);
			throw new DataAccessException(e);
		}

		checkIfNull(c);
		return c;
	}
	
	public ResultList getCbkDetTable(Map formSearchValuesMap) throws DataAccessException {
		ResultList rL = new ResultList();

		try {

			rL.setList((List<Integer>) getSqlMapClientTemplate().queryForList("ChargebackManager.getCbkDetTable",
					formSearchValuesMap));
			System.out.println("------------ChargebackManagerDaoImpl.java--ResultList size----" + rL.getList().size());
			if (rL.getList().size() == 0) {
				rL.setTotalCount(new Integer(0));
			}
		} catch (Exception e) {
			log.error("Error in getCbkDetTable() " + e);
			e.printStackTrace();
			throw new DataAccessException(e);
		}
		return rL;
	}
	
	public ResultList getChargebackDistribution(Map formSearchValuesMap) throws DataAccessException {
		ResultList rL = new ResultList();

		try {

			rL.setList((List<Integer>) getSqlMapClientTemplate()
					.queryForList("ChargebackManager.getChargebackDistribution", formSearchValuesMap));
			System.out.println("------------ChargebackManagerDaoImpl.java--ResultList size----" + rL.getList().size());
			if (rL.getList().size() == 0) {
				rL.setTotalCount(new Integer(0));
			}
		} catch (Exception e) {
			log.error("Error in getChargebackDistribution() " + e);
			e.printStackTrace();
			throw new DataAccessException(e);
		}
		return rL;
	}
	
	@Override
	public String getMinStepNumberWithInvoiceAmount(String invoiceNumber, String locationNumber, String typeId)
			throws DataAccessException {

		String minStep = null;
		try {

			HashMap<String, String> map = new HashMap<String, String>();
			map.put("invoiceNumber", invoiceNumber);
			map.put("locationNumber", locationNumber);
			map.put("typeId", typeId);

			minStep = (String) getSqlMapClientTemplate()
					.queryForObject("ChargebackManager.getMinStepNumberWithInvoiceAmount", map);

		} catch (Exception e) {
			e.printStackTrace();
			log.error(e);
			throw new DataAccessException(e);
		}

		return minStep;
	}
	
	public ResultList getApprovalHistory(String invoice) throws DataAccessException {

		ResultList rL = new ResultList();
		try {

			rL.setList((List) getSqlMapClientTemplate().queryForList("ChargebackManager.getApprovalHistory", invoice));

		} catch (Exception e) {
			e.printStackTrace();
			log.error(e);
			throw new DataAccessException(e);
		}
		// checkIfNull(s);
		return rL;
	}
	
	@Override
	public List<ChargebackManagerBO> getAttachmentName(String invoiceNumber) throws DataAccessException {
		System.out.println("invoiceNumber @@@@:" + invoiceNumber);
		List<ChargebackManagerBO> l = null;
		try {

			l = getSqlMapClientTemplate().queryForList("ChargebackManager.getAttachmentName", invoiceNumber);

		} catch (Exception e) {
			log.error(e);
			throw new DataAccessException(e);
		}
		return l;
	}
	
	@Override
	public String getRoleIdForNextApprover(String invoiceNumber, String typeId, String locationNumber, String userId)
			throws DataAccessException {

		String maxStep = null;
		try {

			HashMap<String, String> map = new HashMap<String, String>();
			map.put("invoiceNumber", invoiceNumber);
			map.put("userId", userId);
			map.put("locationNumber", locationNumber);
			map.put("typeId", typeId);

			maxStep = (String) getSqlMapClientTemplate().queryForObject("ChargebackManager.getRoleIdForNextApprover",
					map);

		} catch (Exception e) {
			e.printStackTrace();
			log.error(e);
			throw new DataAccessException(e);
		}

		return maxStep;
	}
	
	@Override
	public String getAdminUser(String userId, String roleId) throws DataAccessException {

		String maxStep = null;
		try {

			HashMap<String, String> map = new HashMap<String, String>();
			map.put("userId", userId);
			map.put("roleId", roleId);

			maxStep = (String) getSqlMapClientTemplate().queryForObject("ChargebackManager.getAdminUser", map);

		} catch (Exception e) {
			e.printStackTrace();
			log.error(e);
			throw new DataAccessException(e);
		}

		return maxStep;
	}
	
	@Override
	public ResultList getChargebackApprovalStatus(String invoiceNumber, String approverId) throws DataAccessException {
		ResultList rL = new ResultList();
		try {

			HashMap map = new HashMap();
			map.put("invoiceNumber", invoiceNumber);
			map.put("approverId", approverId);
			rL.setList(
					(List) getSqlMapClientTemplate().queryForList("ChargebackManager.getChargebackApprovalStatus", map));

		} catch (Exception e) {
			log.error(e);
			throw new DataAccessException(e);
		}
		// checkIfNull(l);
		return rL;
	}
	
	@Override
	public String getInvoiceEditableStatus(String invoiceNumber) throws DataAccessException {

		String editableInvoice = null;
		try {
			editableInvoice = (String) getSqlMapClientTemplate()
					.queryForObject("ChargebackManager.getInvoiceEditableStatus", invoiceNumber);

		} catch (Exception e) {
			e.printStackTrace();
			log.error(e);
			throw new DataAccessException(e);
		}

		return editableInvoice;
	}

}