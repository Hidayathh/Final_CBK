/*
 * Created on Feb 8, 2006
 * 
 */
package com.unfi.cbk.controller;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;

import com.unfi.cbk.beans.UserDataBean;
import com.unfi.cbk.utilcore.ApplicationProperties;

/**
 * 
 * @author yhp6y2l
 *
 */
public class PageAccessResolver {

	private static Logger log = Logger.getLogger(PageAccessResolver.class);

	private HttpServletRequest request;

	public PageAccessResolver(HttpServletRequest request) {
		this.request = request;
	}

	public boolean hasAccess() {
		boolean ret = false;

		UserDataBean user = new UserDataBean(request);
		
			String control = ApplicationProperties.getPageControlFlag();
			if (control != null && "yes".equalsIgnoreCase(control.trim())) {
				String action = request.getServletPath();
				log.debug("Action for control: " + action);
				// String entityValue = user.getEntityValue();
				String entityValue = "true";
				if (entityValue != null && entityValue.trim().length() > 0) {
					// if the entityValue is numeric, strip off the leading 0s
					int temp = 0;
					try {
						temp = Integer.parseInt(entityValue);
					} catch (Exception e) {

					}
					if (temp != 0) {

						entityValue = String.valueOf(temp);
					}
				}
			} else {
				// we are not limiting access to the pass creation
				ret = true;
			}
		
		return ret;
	}

}
