/*
 * Created on Oct 20, 2005
 * 
 */
package com.unfi.cbk.tiles.controller;

import javax.servlet.http.HttpServletRequest;

/**
 * @author yhp6y2l
 * @version 1.0 Oct 20, 2005
 */
public interface ListInserter {
	public void insertList(HttpServletRequest request, String dbSchema);
}
