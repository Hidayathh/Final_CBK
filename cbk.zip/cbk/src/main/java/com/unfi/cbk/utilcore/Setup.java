package com.unfi.cbk.utilcore;

import java.util.Calendar;
import java.util.Properties;

import javax.naming.Context;
import javax.naming.NamingException;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.springframework.context.ApplicationContext;
import org.springframework.core.env.Environment;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.unfi.cbk.dao.DaoFactory;
import com.unfi.cbk.filter.WrapperConstants;
import com.unfi.cbk.ui.MenuLinks;

/**
 * The Setup servlet is loaded at startup and can be called at anytime to reload
 * values from properties files.
 *
 * @author yhp6y2l
 * @since 1.0
 */

public class Setup extends HttpServlet {
	static Logger log = Logger.getLogger(Setup.class);
	private ServletContext context;

	// @Autowired
	Environment resources;

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.servlet.GenericServlet#init()
	 */
	public void init() throws ServletException {
		ApplicationContext ctx = WebApplicationContextUtils.getWebApplicationContext(getServletContext());
		// System.out.println("beans : "+Arrays.asList(ctx.getBeanDefinitionNames()));
		resources = (Environment) ctx.getBean("environment");
		setupApplication();
	}

	private void initializeAppProperies() {
		ApplicationProperties.checkProperties();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * javax.servlet.http.HttpServlet#service(javax.servlet.http.HttpServletRequest,
	 * javax.servlet.http.HttpServletResponse)
	 */
	public void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, java.io.IOException {

		ApplicationContext ctx = WebApplicationContextUtils
				.getWebApplicationContext(request.getSession().getServletContext());
		// System.out.println("beans : "+Arrays.asList(ctx.getBeanDefinitionNames()));
		resources = (Environment) ctx.getBean("environment");
		setupApplication();

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see javax.servlet.Servlet#destroy()
	 */
	public void destroy() {
		getServletContext().removeAttribute("aBean");
		// PropertiesBodyWriter.destroy();
	}

	/**
	 * Loads the various properties files in This method loads the XML properties
	 * files used for the Menu framework as well as the LDAP secure properties file.
	 * 
	 * @since 1.0
	 */
	private void setupApplication() {
		String rulesFileName = "";
		String fileName = "";
		String propertiesFileName = "";
		String propertiesRulesName = "";
		try {
			context = getServletContext();

			// ***** Load the environment resources property file*****
			initializeAppProperies();

			// ***** Load up the xml properties *****
			// ***** Load up the menu xml *****
			// get the files
			// InputSource file = loadFile(context.getInitParameter("appMenu"));
			fileName = context.getInitParameter("appMenu");

			// InputSource rules = loadFile(context.getInitParameter("appMenuRules"));
			rulesFileName = context.getInitParameter("appMenuRules");

			System.out.println("*********Init Param appMenu=" + context.getInitParameter("appMenu"));
			// run the XML through digester
			DigestXML dig = new DigestXML();

			// this digester can take any set of files and return an object
			// MenuLinks menuLinks = (MenuLinks) dig.createObject(file, rules);
			MenuLinks menuLinks = (MenuLinks) dig.createObject(rulesFileName, fileName);

			// log.debug(menuLinks.toString());
			context.setAttribute("menu", menuLinks);

			// ***** Load up the properties xml *****
			// get the files
			// InputSource propertiesFile =
			// loadFile(context.getInitParameter("appProperties"));
			propertiesFileName = context.getInitParameter("appProperties");
			System.out.println("propertiesFileName = " + propertiesFileName);
			// InputSource propertiesRules =
			// loadFile(context.getInitParameter("appPropertiesRules"));
			propertiesRulesName = context.getInitParameter("appPropertiesRules");
			System.out.println("propertiesRulesName =" + propertiesRulesName);

			
			// this digester can take any set of files and return an object
//			ApplicationDataBean appDataBean = (ApplicationDataBean) dig.createObject(propertiesFile, propertiesRules);
			ApplicationDataBean appDataBean = (ApplicationDataBean) dig.createObject(propertiesRulesName,
					propertiesFileName);

			// Load the common LDAP properties file
			fileName = context.getInitParameter("ldapPropertiesFile");
/*			Properties config = loadPropertiesFile(fileName);

			// Initialize ldap properties
			Enumeration propertyNames = config.propertyNames();
			while (propertyNames.hasMoreElements()) {
				String propertyName = (String) propertyNames.nextElement();
				// context.setAttribute(propertyName, config.getProperty(propertyName));
				appDataBean.addProperty(propertyName, config.getProperty(propertyName));

			} */

			// put the properties into the context
			context.setAttribute("aBean", appDataBean);

			// Setup the dao factory
			DaoFactory.init(appDataBean);

			// Set the copyright year
			String cYear = "";
			Calendar now = Calendar.getInstance();
			cYear = String.valueOf(now.get(Calendar.YEAR));
			appDataBean.addProperty("year", cYear);

			// Populate the WrapperConstants for use by the filter
			// MessageResources resources = (MessageResources)
			// context.getAttribute("environmentResources");
			Properties props = convertResourceToProperties(
					new String[] { WrapperConstants.WRAPPER_CLASS, WrapperConstants.DEFAULT_USER_ID,
							WrapperConstants.DEFAULT_USER_NAME, WrapperConstants.DEFAULT_USER_ROLES });
			WrapperConstants.setConstants(props);

		} catch (Exception e) {
			log.error("Exception in setupApplication() (init):" + e);
			e.printStackTrace();
		}
	}

	/*
	 * private InputSource loadFile(String fileName) { InputSource is = null; try {
	 * java.io.InputStream xmlRulesFileStream =
	 * getClass().getClassLoader().getResourceAsStream(fileName); is = new
	 * InputSource(xmlRulesFileStream); log.debug("XML file read into memory: " +
	 * fileName + ".");
	 * 
	 * } catch (Exception e) { log.error("Unable to load the file "
	 * +fileName+" - please make sure the location is correct");
	 * 
	 * } finally { return is;
	 * 
	 * }
	 * 
	 * }
	 */

/*	private Properties loadPropertiesFile(String fileName) {
		// Create a Properties instance
		Properties constants = new Properties();

		try {
			if (fileName == null || fileName.length() == 0) {

				log.error(
						"ERROR: Cannot read the configuration file. Please check the path of the config init param in web.xml.");
				throw new Exception();
			}

			java.io.InputStream propertiesFileStream = getClass().getClassLoader().getResourceAsStream(fileName);
			// lets check if the file is in the /work/nfs/config/ path
			if (propertiesFileStream == null) {
				propertiesFileStream = new FileInputStream(
						System.getProperty("work.nfs.config.path", "/work/nfs/config/") + fileName);
			}
			if (propertiesFileStream != null) {
				log.debug("Properties file read into memory: " + fileName + ".");
				constants.load(propertiesFileStream);

				propertiesFileStream.close();

			}
		
		} catch (Exception e) {
			log.error("Exception in loadPropertiesFile():" + e.getMessage(), e);
		} finally {

		}
		return constants;

	} */

	/**
	 * Loads the DataSource for this application.
	 * 
	 * @return the <code>DataSource</code> object
	 * @param context the <code>ServletContext</code> for this application
	 * @since 1.0
	 */
	public static DataSource getDataSource11(ServletContext context) {
		DataSource ds = (DataSource) context.getAttribute("epassDataSource");

		try {
			if (ds == null) {
				Properties parms = System.getProperties();
				parms.setProperty(Context.INITIAL_CONTEXT_FACTORY, "com.ibm.websphere.naming.WsnInitialContextFactory");
				Context ctx = new javax.naming.InitialContext(parms);
				ds = (DataSource) ctx.lookup("jdbc/udt");

				context.setAttribute("epassDataSource", ds);
				log.debug("Datasource initialized:" + ds);
			}

		} catch (NamingException e) {
			log.error("JNDI Naming Exception in getDataSource(): " + e);

		} catch (Exception e) {
			log.error("Exception in getDataSource(): " + e);

		} finally {

		}
		return ds;
	}

	private Properties convertResourceToProperties(String[] keys) {
		Properties props = new Properties();
		System.out.println("Setup httpServlet ... Resources=" + resources);
		if (resources != null) {
			for (int i = 0; i < keys.length; i++) {
				String s = resources.getProperty(keys[i]);
				if (s != null) {
					props.put(keys[i], s);
				}
			}
		}
		return props;
	}

}