package com.unfi.cbk.bo;

/**
 * The Chargeback class is a means for representing a single result when
 * searching for Chargebacks.
 * <p>
 * Each property represents a column in the display table.
 *
 * @author vpil001
 * @since 1.0
 */

public class ChargebackReportBO {

	/*
	 * CBK
	 */

	public ChargebackReportBO() {

	}
	private String documentNumber;
	private String locationNumber;
	private String documentDate;
	private String vendorNumber;
	private String vendorName;
	private String typeDescription;
	private String creator;
	private String briefDecription;
	//private String reasonCode;
	private String productGroupCode;
	private String amount;
	private String distLocNumber;
	private String state;
	private String accNumber;
	private String distributionAmount;
	private String dueDate;
	private String reasonCode;
	
	
	public String getReasonCode() {
		return reasonCode;
	}
	public void setReasonCode(String reasonCode) {
		this.reasonCode = reasonCode;
	}
	public String getDocumentNumber() {
		return documentNumber;
	}
	public void setDocumentNumber(String documentNumber) {
		this.documentNumber = documentNumber;
	}
	public String getLocationNumber() {
		return locationNumber;
	}
	public void setLocationNumber(String locationNumber) {
		this.locationNumber = locationNumber;
	}
	public String getDocumentDate() {
		return documentDate;
	}
	public void setDocumentDate(String documentDate) {
		this.documentDate = documentDate;
	}
	public String getVendorNumber() {
		return vendorNumber;
	}
	public void setVendorNumber(String vendorNumber) {
		this.vendorNumber = vendorNumber;
	}
	public String getVendorName() {
		return vendorName;
	}
	public void setVendorName(String vendorName) {
		this.vendorName = vendorName;
	}
	public String getTypeDescription() {
		return typeDescription;
	}
	public void setTypeDescription(String typeDescription) {
		this.typeDescription = typeDescription;
	}
	public String getCreator() {
		return creator;
	}
	public void setCreator(String creator) {
		this.creator = creator;
	}
	public String getBriefDecription() {
		return briefDecription;
	}
	public void setBriefDecription(String briefDecription) {
		this.briefDecription = briefDecription;
	}
	public String getProductGroupCode() {
		return productGroupCode;
	}
	public void setProductGroupCode(String productGroupCode) {
		this.productGroupCode = productGroupCode;
	}
	public String getAmount() {
		return amount;
	}
	public void setAmount(String amount) {
		this.amount = amount;
	}
	public String getDistLocNumber() {
		return distLocNumber;
	}
	public void setDistLocNumber(String distLocNumber) {
		this.distLocNumber = distLocNumber;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getAccNumber() {
		return accNumber;
	}
	public void setAccNumber(String accNumber) {
		this.accNumber = accNumber;
	}
	public String getDistributionAmount() {
		return distributionAmount;
	}
	public void setDistributionAmount(String distributionAmount) {
		this.distributionAmount = distributionAmount;
	}
	public String getDueDate() {
		return dueDate;
	}
	public void setDueDate(String dueDate) {
		this.dueDate = dueDate;
	}
	
	
	
}


	