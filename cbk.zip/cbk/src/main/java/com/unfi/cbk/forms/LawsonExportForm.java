package com.unfi.cbk.forms;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;

import com.unfi.cbk.bo.ChargebackBO;
import com.unfi.cbk.bo.ChargebackExportBO;
import com.unfi.cbk.util.ActionMessages;
import com.unfi.cbk.util.Constants;
import com.unfi.cbk.util.Validations;

/**
 * The MassApprovalsForm class is the struts action form used to search for
 * documents.
 *
 * @author vpil001
 * @since 1.0
 * 
 */
@Component
public class LawsonExportForm extends SortablePageableActionForm {
	static Logger log = Logger.getLogger(LawsonExportForm.class);

	// Page-specific properties not part of Map
	private List chargebacks;
	private String[] chargebackSelections = new String[] {};
	private List searchResults;
	private Integer maxMonths;
	private String originator;
	private String approver;
	private String vendorId;
	private String locationNumber;
	private String fromDate;
	private String toDate;
	private String invoiceFrom;
	private String invoiceTo;
	private String amountFrom;
	private String amountTo;
	private String APStatus;
	private String Status;
	private String date_a;
	public String getDate_a() {
		return date_a;
	}

	public void setDate_a(String date_a) {
		this.date_a = date_a;
	}

	public String getDate_b() {
		return date_b;
	}

	public void setDate_b(String date_b) {
		this.date_b = date_b;
	}

	private String date_b;

	private Date dueDate;
	public Date getDueDate() {
		return dueDate;
	}

	public void setDueDate(Date dueDate) {
		this.dueDate = dueDate;
	}

	public Date getLastApprovalDate() {
		return lastApprovalDate;
	}

	public void setLastApprovalDate(Date lastApprovalDate) {
		this.lastApprovalDate = lastApprovalDate;
	}

	public String getUpdateDetailValue() {
		return updateDetailValue;
	}

	public void setUpdateDetailValue(String updateDetailValue) {
		this.updateDetailValue = updateDetailValue;
	}

	private Date lastApprovalDate;
	private String updateDetailValue;
	
	

	private String chargebackReason;
	private String maxAmount;

	public String getMaxAmount() {
		return maxAmount;
	}

	public void setMaxAmount(String maxAmount) {
		this.maxAmount = maxAmount;
	}

	public String getChargebackReason() {
		return chargebackReason;
	}

	public void setChargebackReason(String chargebackReason) {
		this.chargebackReason = chargebackReason;
	}

	public String geteDICode() {
		return eDICode;
	}

	public void seteDICode(String eDICode) {
		this.eDICode = eDICode;
	}

	public String getBalanceSheet() {
		return balanceSheet;
	}

	public void setBalanceSheet(String balanceSheet) {
		this.balanceSheet = balanceSheet;
	}

	public String getActive() {
		return active;
	}

	public void setActive(String active) {
		this.active = active;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getRoleId() {
		return roleId;
	}

	public void setRoleId(String roleId) {
		this.roleId = roleId;
	}

	public String getTypeId() {
		return typeId;
	}

	public void setTypeId(String typeId) {
		this.typeId = typeId;
	}

	public String getAuthorizationAmount() {
		return authorizationAmount;
	}

	public void setAuthorizationAmount(String authorizationAmount) {
		this.authorizationAmount = authorizationAmount;
	}

	public String getByType() {
		return byType;
	}

	public void setByType(String byType) {
		this.byType = byType;
	}

	private Integer uploadAp;
	private Integer accountReq;
	private Integer vendorReq;
	private Integer credit;
	private Integer uploadFood;
	private Integer selectable;

	private String chargebackType;
	private String approvalRouting;

	public String getApprovalRouting() {
		return approvalRouting;
	}

	public void setApprovalRouting(String approvalRouting) {
		this.approvalRouting = approvalRouting;
	}

	public String getChargebackType() {
		return chargebackType;
	}

	public void setChargebackType(String chargebackType) {
		this.chargebackType = chargebackType;
	}

	public Integer getUploadAp() {
		return uploadAp;
	}

	public void setUploadAp(Integer uploadAp) {
		this.uploadAp = uploadAp;
	}

	public Integer getAccountReq() {
		return accountReq;
	}

	public void setAccountReq(Integer accountReq) {
		this.accountReq = accountReq;
	}

	public Integer getVendorReq() {
		return vendorReq;
	}

	public void setVendorReq(Integer vendorReq) {
		this.vendorReq = vendorReq;
	}

	public Integer getCredit() {
		return credit;
	}

	public void setCredit(Integer credit) {
		this.credit = credit;
	}

	public Integer getUploadFood() {
		return uploadFood;
	}

	public void setUploadFood(Integer uploadFood) {
		this.uploadFood = uploadFood;
	}

	public Integer getSelectable() {
		return selectable;
	}

	public void setSelectable(Integer selectable) {
		this.selectable = selectable;
	}

	private String accountNumber;
	private String eDICode;
	private String balanceSheet;
	private String active;

	private String role;
	private String roleId;
	private String typeId;
	private String authorizationAmount;
	private String byType;
	private List typeResults = null;

	public List getTypeResults() {
		return typeResults;
	}

	public void setTypeResults(List typeResults) {
		this.typeResults = typeResults;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	private String maxStepNumber;

	private String approved;
	private String originalApprover;

	private String reasonForDeny;

	private String resultCount;

	private String description;

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getProductCode() {
		return productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	public boolean isNew() {
		return isNew;
	}

	public void setNew(boolean isNew) {
		this.isNew = isNew;
	}

	public String getVendor() {
		return vendor;
	}

	public void setVendor(String vendor) {
		this.vendor = vendor;
	}

	public String getRouteId() {
		return routeId;
	}

	public void setRouteId(String routeId) {
		this.routeId = routeId;
	}

	public String getRouteName() {
		return routeName;
	}

	public void setRouteName(String routeName) {
		this.routeName = routeName;
	}

	private String productCode;
	private boolean isNew;
	private String vendor;
	private String routeId;
	private String routeName;

	public static Logger getLog() {
		return log;
	}

	public static void setLog(Logger log) {
		LawsonExportForm.log = log;
	}

	public String getInvoiceNumber() {
		return invoiceNumber;
	}

	public void setInvoiceNumber(String invoiceNumber) {
		this.invoiceNumber = invoiceNumber;
	}

	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}

	public String getExportedDate() {
		return exportedDate;
	}

	public void setExportedDate(String exportedDate) {
		this.exportedDate = exportedDate;
	}

	public String getExportedId() {
		return exportedId;
	}

	public void setExportedId(String exportedId) {
		this.exportedId = exportedId;
	}

	public String getExportedAmount() {
		return exportedAmount;
	}

	public void setExportedAmount(String exportedAmount) {
		this.exportedAmount = exportedAmount;
	}

	public String getNotFound() {
		return notFound;
	}

	public void setNotFound(String notFound) {
		this.notFound = notFound;
	}

	public String getTotalExportedAmount() {
		return totalExportedAmount;
	}

	public void setTotalExportedAmount(String totalExportedAmount) {
		this.totalExportedAmount = totalExportedAmount;
	}

	public String getParentName() {
		return parentName;
	}

	public void setParentName(String parentName) {
		this.parentName = parentName;
	}

	public String getStateCode() {
		return stateCode;
	}

	public void setStateCode(String stateCode) {
		this.stateCode = stateCode;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getExporterName() {
		return exporterName;
	}

	public void setExporterName(String exporterName) {
		this.exporterName = exporterName;
	}

	public int getAutoGrowCollectionLimit() {
		return autoGrowCollectionLimit;
	}

	public void setAutoGrowCollectionLimit(int autoGrowCollectionLimit) {
		this.autoGrowCollectionLimit = autoGrowCollectionLimit;
	}

	public String getDateCriteria() {
		return dateCriteria;
	}

	public void setDateCriteria(String dateCriteria) {
		this.dateCriteria = dateCriteria;
	}

	public String getSearchBy() {
		return searchBy;
	}

	public void setSearchBy(String searchBy) {
		this.searchBy = searchBy;
	}

	private String TotalAccruals;
	private String invoiceNumber;
	private String time;
	private String exportedDate;
	private String exportedId;
	private String exportedAmount;
	private String notFound;
	private String totalExportedAmount;
	private String invoiceDate;

	public String getInvoiceDate() {
		return invoiceDate;
	}

	public void setInvoiceDate(String invoiceDate) {
		this.invoiceDate = invoiceDate;
	}

	private String parentName;
	private String stateCode;
	private String date;
	private String exporterName;

	public String getTotalAccruals() {
		return TotalAccruals;
	}

	public void setTotalAccruals(String totalAccruals) {
		TotalAccruals = totalAccruals;
	}

	public String getResultCount() {
		return resultCount;
	}

	public void setResultCount(String resultCount) {
		this.resultCount = resultCount;
	}

	public String getReasonForDeny() {
		return reasonForDeny;
	}

	public void setReasonForDeny(String reasonForDeny) {
		this.reasonForDeny = reasonForDeny;
	}

	public String getOriginalApprover() {
		return originalApprover;
	}

	public void setOriginalApprover(String originalApprover) {
		this.originalApprover = originalApprover;
	}

	public String getApproved() {
		return approved;
	}

	public void setApproved(String approved) {
		this.approved = approved;
	}

	private List chargebackTypes;

	private String[] selectedItems = null;

	public String[] getSelectedItems() {
		return selectedItems;
	}

	public String getMaxStepNumber() {
		return maxStepNumber;
	}

	public void setMaxStepNumber(String maxStepNumber) {
		this.maxStepNumber = maxStepNumber;
	}

	public void setSelectedItems(String[] selectedItems) {
		this.selectedItems = selectedItems;
	}

	public List getChargebackTypes() {
		return chargebackTypes;
	}

	public void setChargebackTypes(List chargebackTypes) {
		System.out.println("--------chargebackTypes----List---" + chargebackTypes);
		this.chargebackTypes = chargebackTypes;
	}

	public void setLocationNumber(String locationNumber) {
		this.locationNumber = locationNumber;
	}

	public String getLocationNumber() {
		return locationNumber;
	}

	public void setAmountFrom(String amountFrom) {
		this.amountFrom = amountFrom;
	}

	public String getAmountFrom() {
		return amountFrom;
	}

	public void setAmountTo(String amountTo) {
		this.amountTo = amountTo;
	}

	public String getAmountTo() {
		return amountTo;
	}

	public void setInvoiceFrom(String invoiceFrom) {
		this.invoiceFrom = invoiceFrom;
	}

	public String getInvoiceFrom() {
		return invoiceFrom;
	}

	public void setInvoiceTo(String invoiceTo) {
		this.invoiceTo = invoiceTo;
	}

	public String getInvoiceTo() {
		return invoiceTo;
	}

	public String getOriginator() {
		return originator;
	}

	public void setOriginator(String originator) {
		this.originator = originator;
	}

	public String getApprover() {
		return approver;
	}

	public void setApprover(String approver) {
		this.approver = approver;
	}

	public String getVendorId() {
		return vendorId;
	}

	public void setVendorId(String vendorId) {
		this.vendorId = vendorId;
	}

	public String getFromDate() {
		return fromDate;
	}

	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}

	public String getToDate() {
		return toDate;
	}

	public void setToDate(String toDate) {
		this.toDate = toDate;
	}

	public String getAPStatus() {
		return APStatus;
	}

	public void setAPStatus(String aPStatus) {
		APStatus = aPStatus;
	}

	public String getStatus() {
		return Status;
	}

	public void setStatus(String status) {
		Status = status;
	}

	
	

	// Externalize this value
	@Value("${cbk.autoGrowCollectionLimit:100000}")
	private int autoGrowCollectionLimit;

	@InitBinder
	public void initBinder(WebDataBinder dataBinder) {
		dataBinder.setAutoGrowCollectionLimit(autoGrowCollectionLimit);
	}

	public List getSearchResults() {
		return this.searchResults;
	}

	public void setSearchResults(List list) {
		this.searchResults = list;
	}

	public ChargebackBO[] getChargeback() {
		if (chargebacks == null) {
			chargebacks = new ArrayList();
		}
		ChargebackBO[] r = new ChargebackBO[chargebacks.size()];
		for (int i = 0; i < chargebacks.size(); i++) {
			r[i] = (ChargebackBO) chargebacks.get(i);
		}
		return r;
	}

	public void setChargeback(ChargebackBO[] r) {
		chargebacks = Arrays.asList(r);
	}

	public ChargebackBO getChargeback(int i) {
		if (chargebacks == null) {
			chargebacks = new ArrayList();
		}
		for (int j = chargebacks.size(); j <= i; j++) {
			chargebacks.add(j, new ChargebackBO());
		}
		return (ChargebackBO) chargebacks.get(i);
	}

	public void setChargeback(int i, ChargebackBO doc) {
		if (chargebacks == null) {
			chargebacks = new ArrayList();
		}
		chargebacks.add(i, doc);
	}

	public List getChargebacks() {
		return chargebacks;
	}

	public void setChargebacks(List doc) {
		chargebacks = doc;
	}

	public String[] getChargebackSelections() {
		return chargebackSelections;
	}

	public void setChargebackSelections(String[] strings) {
		chargebackSelections = strings;
	}

	public List getSelectedResults() {
		List l = null;
		if (chargebackSelections != null) {
			l = new ArrayList();
			for (int i = 0; i < chargebackSelections.length; i++) {
				int j = Integer.parseInt(chargebackSelections[i]);
				l.add(chargebacks.get(j));
			}
		}
		return l;
	}

	private String dateCriteria = "1";
	private String searchBy = "invoiceNumber";
	// private String documentOutputType="pc1";

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.apache.struts.action.ActionForm#reset(org.apache.struts.action.
	 * ActionMapping, javax.servlet.http.HttpServletRequest)
	 */
	public void reset(HttpServletRequest request) {
		// Only Employees and Manufacturers can search by date
		if (request.isUserInRole(Constants.EMPLOYEE_ROLE) || request.isUserInRole(Constants.MANUFACTURER_ROLE)) {
			setValue("dateCriteria", "1");
		}

		// Brokers are the only ones that are required to select a searchBy property
		if (request.isUserInRole(Constants.BROKER_ROLE)) {
			setValue("searchBy", "docnum");
		}

		setValue("documentOutputType", "pdf");
		setSortBy("invoiceNumber");
		setSortOrder("asc");
		setShowAll(false);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.apache.struts.action.ActionForm#validate(org.apache.struts.action.
	 * ActionMapping, javax.servlet.http.HttpServletRequest)
	 */
	public ActionMessages validate(HttpServletRequest request,  ActionMessages errors) {
		// ActionMessages errors = new ActionMessages();
		String user = request.getRemoteUser();
		Validations validations = new Validations();

		try {
			

			if (!request.isUserInRole(Constants.BROKER_ROLE) && getString("dateCriteria") != null
					&& getString("dateCriteria").equals("manual")) {
				// Verify the entered dates meet the following criteria:
				// (1) The from date is less than the to date.
				// (2) Neither date goes back farther than the specified
				// number of years (as defined in the Resource Bundle
				// under label.dateCriteria.spanMaxYears
				// (3) Neither date is in the future

				// Verify condition (1)
				if (!validations.isValidDateRange(getString("fromDate"), getString("toDate"))) {
					// The from date is greater than the to date - invalid.
					errors.add("fromDate", "errors.dateRange", null);
				}


				if (!validations.isValidTimePeriodMonths(getString("fromDate"), getString("toDate"),
						maxMonths.intValue())) {
					// One of the dates is more than the max specified months ago - invalid
					errors.add("fromDate", "errors.datePriorMonths", new String[] { maxMonths.toString() });
				}

				if (!validations.isNot30PlusDaysInFuture(getString("fromDate"), getString("toDate"))) {
					errors.add("fromDate", "errors.dateFuture", null);
				}
			}

		} catch (Exception e) {
			log.error("Exception in MassApprovalsForm.validate()" + e);
		}

		return errors;
	}

	/**
	 * @return
	 */
	public Integer getMaxMonths() {
		return maxMonths;
	}

	/**
	 * @param integer
	 */
	public void setMaxMonths(Integer integer) {
		maxMonths = integer;
	}
	
	
	private String user;
	private String location;
	private String roleSelected;
	private String statusSelected;
	private String userId;
	private String userName;
	private Integer results = null;
	private String totalExports;

	
	public String getTotalExports() {
		return totalExports;
	}

	public void setTotalExports(String totalExports) {
		this.totalExports = totalExports;
	}

	public String getTypeName() {
		return typeName;
	}

	public void setTypeName(String typeName) {
		this.typeName = typeName;
	}

	
	private String roles;
	
	private String selectedResult = null;
	private String users;
	

	private String typeName;
	

	public String getStatusSelected() {
		return statusSelected;
	}

	public void setStatusSelected(String statusSelected) {
		this.statusSelected = statusSelected;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public String getRoleSelected() {
		return roleSelected;
	}

	public void setRoleSelected(String roleSelected) {
		this.roleSelected = roleSelected;
	}

	public String getRoles() {
		return roles;
	}

	public void setRoles(String roles) {
		this.roles = roles;
	}

	public String getUsers() {
		return users;
	}

	public void setUsers(String users) {
		this.users = users;
	}

	/**
	 * @return
	 */
	public Integer getResults() {
		return results;
	}

	public String getSelectedResult() {
		return selectedResult;
	}

	/**
	 * @return
	 */

	/**
	 * @param i
	 */
	public void setResults(Integer i) {
		results = i;
	}

	/**
	 * @param string
	 */
	public void setSelectedResult(String string) {
		selectedResult = string;
	}

	public String getUserName() {
		return userName;
	}

	/**
	 * @param string
	 */
	public void setUserName(String string) {
		userName = string;
	}

	/**
	 * @param string
	 */

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	


	public void populateFormFromObject(ChargebackExportBO cbk) {
		this.isNew = false;
		this.setProductCode(cbk.getProductCode());
		this.setDescription(cbk.getDescription());
		this.setVendor(cbk.getVendor());
		this.setRouteId(cbk.getRouteId());
		this.setRouteName(cbk.getRouteName());

		this.setLocationNumber(cbk.getLocationNumber());
		this.setParentName(cbk.getParentName());
		this.setStateCode(cbk.getStateCode());

		this.setChargebackReason(cbk.getChargebackReason());
		this.setAccountNumber(cbk.getAccountNumber());
		this.seteDICode(cbk.geteDICode());
		this.setBalanceSheet(cbk.getBalanceSheet());
		this.setActive(cbk.getActive());
	}
}