package com.unfi.cbk.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.unfi.cbk.forms.ChargebackApproverReasonForm;
import com.unfi.cbk.util.ActionMessages;
import com.unfi.cbk.util.ActionUrlMapping;
import com.unfi.cbk.util.Constants;

/**
 * The action method that will be called is automatically determined based upon
 * the value of the parameter that is passed in.
 * <p>
 * The action method will then sets the user data in the request, sets any
 * values needed, and forwards to the appropriate action mapping.
 *
 * @author vpil001
 * @version 1.0
 */
@Controller
public class ChargebackApproverReasonController {
	static Logger log = Logger.getLogger(ChargebackApproverReasonController.class);

	public ChargebackApproverReasonController() {
	}

	@Autowired
	ActionMessages errors;

	/**
	 * The search() method get the values from the database.
	 * 
	 * @param mapping  The ActionMapping used to select this instance
	 * @param form     The ActionForm bean for this request
	 * @param request  The HTTP request we are processing
	 * @param response The HTTP response we are creating
	 * @return an ActionForward instance describing where and how control should be
	 *         forwarded, or null if the response has already been completed.
	 * @throws Exception if an exception occurs
	 */
	@RequestMapping(value = "/cbkApproverReason", method = { RequestMethod.GET, RequestMethod.POST }, params = {
			"action=addReason" })
	public ModelAndView addReason(@ModelAttribute ChargebackApproverReasonForm chargebackApproverReasonForm,
			HttpServletRequest request, HttpServletResponse response) throws Exception {
		ModelAndView mav = new ModelAndView();
		ActionMessages errors = new ActionMessages();
		boolean exceptionOccurred = false;
		try {
			// List searchResults = chargebackSearchDao.doChargebackApproverSearch(typeId,
			// chargebackTotal,stepNumber);
			System.out.println("----DENY -REASON CONTROLLER--");
			// chargebackApproverReasonForm.setSearchResults(searchResults);
		} catch (Exception e) {
			exceptionOccurred = true;
			e.printStackTrace();
			mav.setViewName(ActionUrlMapping.GLOBAL.get(Constants.ACTION_FAILURE));
			log.error("Exception in execute:" + e);
			if (errors.isEmpty()) {
				errors.add("error", "errors.general");
			}
		}

		if (!exceptionOccurred) {
			// forward = mapping.findForward("open");
			System.out.println("------OPEN POPUP ----");
			mav.setViewName(ActionUrlMapping.CBKAPPROVERREASONACTIONS.get("open"));
		}

		// If a message is required, save the specified key(s) into the request.
		if (!errors.isEmpty()) {
			log.debug("FAILED");
			// saveMessages(request, errors);
			// forward = mapping.findForward("failure");
			mav.setViewName(ActionUrlMapping.GLOBAL.get(Constants.ACTION_FAILURE));
		}

		// Finish with
		// return (forward);
		System.out.println("-----URL mapping" + mav.getViewName());
		request.setAttribute("actionMessages", errors);
		request.setAttribute("chargebackApproverReasonForm", chargebackApproverReasonForm);
		return mav;
	}

}
