/*
 * Created on May 27, 2005
 * 
 */
package com.unfi.cbk.common.util.ui.taglib;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspTagException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.BodyContent;
import javax.servlet.jsp.tagext.BodyTagSupport;

import org.apache.log4j.Logger;

import com.unfi.cbk.common.util.ui.Sortable;

/**
 * @author yhp6y2l
 * @version 1.0 May 27, 2005
 */
public class SortingTagHandler extends BodyTagSupport {

	private static Logger log = Logger.getLogger(SortingTagHandler.class);

	private String name = null;
	private String property = null;
	private String value = null;
	private String action = null;

	private String direction = null;

	private static final String IMAGE_UP = "images/sorta.gif";
	private static final String IMAGE_DOWN = "images/sortd.gif";

	/**
	 * @param string
	 */
	public void setName(String string) {
		log.debug("Name: " + string);
		name = string;
	}

	public void setProperty(String string) {
		log.debug("Property: " + string);
		property = string;
	}

	public void setAction(String string) {
		log.debug("Action: " + string);
		action = string;
	}

	public void setAction(Object string) {
		log.debug("Action: " + string);
		action = (String) string;
	}

	public int doStartTag() throws JspException {
		if (name != null && property != null) {
			try {
				Object obj = pageContext.getAttribute(name);
				if (obj == null) {
					obj = pageContext.getRequest().getAttribute(name);
				}
				if (obj == null) {
					obj = pageContext.getServletContext().getAttribute(name);
				}

				if (obj == null) {
					log.info("Cannot find object in servlet context: " + name);
				}
				if (obj != null) {
					if (obj instanceof Sortable) {
						Sortable s = (Sortable) obj;
						if (s.getSortName() != null && s.getSortName().equalsIgnoreCase(property)) {
							direction = s.getSortDirection();
						}
					} else {
						throw new ClassCastException(name + " cannot be cast to Sortable");
					}
				}
			} catch (Exception e) {
				log.error("Exception in doStartTag() " + e);
			}
		}

		return EVAL_BODY_BUFFERED;
	}

	public int doAfterBody() throws JspTagException {
		BodyContent bc = getBodyContent();

		if (bc.getString() != null && value == null) {
			value = bc.getString();
		}

		bc.clearBody();
		return SKIP_BODY;
	}

	public int doEndTag() throws JspException {
		try {
			JspWriter out = pageContext.getOut();
			out.print(display());
		} catch (Exception e) {
			log.error("Exception in doEndTag() " + e);
		}

		name = null;
		property = null;
		value = null;
		direction = null;
		action = null;

		return EVAL_PAGE;
	}

	public void release() {
		super.release();

	}

	/**
	 * @param string
	 */
	public void setValue(String string) {
		log.debug("Value: " + value);
		value = string;
	}

	public String display() {
		StringBuffer buffer = new StringBuffer();
		buffer.append("<a href=\"javascript:updateSorting(");

		// Form Name
		buffer.append("'" + name + "',");

		// Form Action
		if (action != null) {
			buffer.append("'" + action + "',");
		} else {
			buffer.append("'',");
		}

		// sortName
		buffer.append("'" + property + "',");

		// sortDirection
		if (direction == null) {
			buffer.append("'asc'");
		} else if (direction.equalsIgnoreCase("asc")) {
			buffer.append("'desc'");
		} else if (direction.equalsIgnoreCase("desc")) {
			buffer.append("'asc'");
		} else {
			buffer.append("''");
		}

		buffer.append(");\">");

		buffer.append(value == null ? property : value);

		if (direction != null) {
			buffer.append("<img src=\"");
			if (direction.equalsIgnoreCase("asc")) {
				buffer.append(IMAGE_UP);
			} else {
				buffer.append(IMAGE_DOWN);
			}
			buffer.append("\" border=\"0\" style=\"padding-left: 5px; background: #009\">");
		}
		buffer.append("</a>");

		return buffer.toString();
	}

}
