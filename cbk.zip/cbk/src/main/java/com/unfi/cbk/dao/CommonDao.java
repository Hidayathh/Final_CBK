package com.unfi.cbk.dao;

import com.unfi.cbk.beans.ResultList;
import com.unfi.cbk.exceptions.DataAccessException;

/**
 * @author yhp6y2l
 * @version 3.0
 */
public interface CommonDao {

	public ResultList getAssigneesForGroupId(int groupID) throws DataAccessException;

}
