package com.unfi.cbk.dao.dbImpl;

import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.orm.ibatis.SqlMapClientTemplate;
import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;

import com.unfi.cbk.bo.ChargebackBO;
import com.unfi.cbk.dao.ChargebackCreateDao;
import com.unfi.cbk.exceptions.DataAccessException;

/**
 * The ChargebackCreateDaoImpl class implements the generic ChargebackCreateDao
 * interface.
 * 
 * @author yhp6y2l
 * @version 3.3
 */

public class ChargebackCreateDaoImpl extends SqlMapClientDaoSupport implements ChargebackCreateDao {
	static Logger log = Logger.getLogger(ChargebackCreateDaoImpl.class);

	public ChargebackCreateDaoImpl(SqlMapClientTemplate sqlMapTemplate) {
		this.setSqlMapClientTemplate(sqlMapTemplate);
	}

	public List<ChargebackBO> getSubFunds() throws DataAccessException {

		List<ChargebackBO> l = null;
		try {
			System.out.println("------in Impl---getSubFund()-------");
			l = (List<ChargebackBO>) getSqlMapClientTemplate().queryForList("ChargebackCreate.getSubFunds");
			System.out.println("------------ChargebackCreateDaoImpl.java-getSubFund---List size----" + l.size());

		} catch (Exception e) {
			e.printStackTrace();
			log.error(e);
			throw new DataAccessException(e);
		}
		return l;
	}
	
	@Override
	public List<ChargebackBO> getItemInfo(Map formSearchValuesMap) throws DataAccessException {
		List<ChargebackBO> l = null;
		
		try {

			System.out.println("------ChargebackCreateDaoImpl.java-------getItemInfo()------");

			l = (List<ChargebackBO>) getSqlMapClientTemplate().queryForList("ChargebackCreate.getItemInfo",	formSearchValuesMap);
			System.out.println("------------ChargebackCreateDaoImpl.java--getItemInfo size----" + l.size());

		} catch (Exception e) {
			e.printStackTrace();
			log.error("Error in getItemInfo() " + e);
			throw new DataAccessException(e);
		}

		return l;
	}
	
	 public List<ChargebackBO> validateRegionWithoutDivision(Map formSearchValuesMap) throws DataAccessException{
			List<ChargebackBO> l = null;
			
			try {

				System.out.println("------ChargebackCreateDaoImpl.java-------validateRegionWithoutDivision()------");

				l = (List<ChargebackBO>) getSqlMapClientTemplate().queryForList("ChargebackCreate.validateRegionWithoutDivision",	formSearchValuesMap);
				System.out.println("------------ChargebackCreateDaoImpl.java--validateRegionWithoutDivision size----" + l.size());

			} catch (Exception e) {
				e.printStackTrace();
				log.error("Error in validateRegionWithoutDivision() " + e);
				throw new DataAccessException(e);
			}

			return l;
		}
	    
	 public List<ChargebackBO> validateRegionWithDivision(Map formSearchValuesMap) throws DataAccessException{
			List<ChargebackBO> l = null;
			
			try {

				System.out.println("------ChargebackCreateDaoImpl.java-------validateRegionWithDivision()------");

				l = (List<ChargebackBO>) getSqlMapClientTemplate().queryForList("ChargebackCreate.validateRegionWithDivision",	formSearchValuesMap);
				System.out.println("------------ChargebackCreateDaoImpl.java--validateRegionWithDivision size----" + l.size());

			} catch (Exception e) {
				e.printStackTrace();
				log.error("Error in validateRegionWithDivision() " + e);
				throw new DataAccessException(e);
			}

			return l;
		}
	

}