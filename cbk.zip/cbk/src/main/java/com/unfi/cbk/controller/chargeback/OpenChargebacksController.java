package com.unfi.cbk.controller.chargeback;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.servlet.ModelAndView;

import com.unfi.cbk.beans.ResultList;
import com.unfi.cbk.delegates.AdminDelegate;
import com.unfi.cbk.forms.OpenChargebacksForm;
import com.unfi.cbk.util.ActionMessages;
import com.unfi.cbk.util.ActionUrlMapping;
import com.unfi.cbk.util.Constants;

/**
 * The NewSearchAction class is the struts action called for the search criteria
 * entry page. The action sets the user data in the request, sets any values
 * needed for the form, and forwards to the JSP specific to the userType.
 *
 * @author vpil001
 * @since 1.0
 */
@Controller("openChargebackAction_openChargeback")
@Scope(value = WebApplicationContext.SCOPE_REQUEST, proxyMode = ScopedProxyMode.TARGET_CLASS)
public class OpenChargebacksController {// extends Action {
	static Logger log = Logger.getLogger(OpenChargebacksController.class);
	@Autowired
	ActionMessages errors;
	@Autowired
	private AdminDelegate adminDelegate;

	// Externalize this value
	@Value("${cbk.autoGrowCollectionLimit:100000}")
	private int autoGrowCollectionLimit;

	@InitBinder
	public void initBinder(WebDataBinder dataBinder) {
		dataBinder.setAutoGrowCollectionLimit(autoGrowCollectionLimit);
	}

	/**
	 * 
	 * @param openChargebacksForm
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/openChargeback", method = { RequestMethod.GET, RequestMethod.POST }, params = {
			"action=openChargebacks" })
	public ModelAndView openChargebacks(@ModelAttribute("openChargebacksForm") OpenChargebacksForm openChargebacksForm,
			HttpServletRequest request, HttpServletResponse response) throws Exception {
		log.debug("***** CHARGEBACK SEARCH *****-NewSearchAction.java-- execute()---");
		ModelAndView mav = new ModelAndView();
		openChargebacksForm.setFormParameterMap(request);
		Map<String, Comparable> searchParametersFromForm = openChargebacksForm.getMap();
		HttpSession session = request.getSession();
		String SmUserId = (String) session.getAttribute("SmUserId");
		

		if (request.getParameter("isformreset") != null) {
			openChargebacksForm.reset();
		}
		log.debug("***** CHARGEBACK SEARCH *****");

		boolean Approver = true;

		// Define the display parameters
		int maxRows = 20;
		openChargebacksForm.setDisplayCount(maxRows);

		if (openChargebacksForm.isShowAll()) {
			searchParametersFromForm.put("showAll", "true");
		} else {
			searchParametersFromForm.put("rowStart", new Integer(openChargebacksForm.getCurrentRecord()));
			searchParametersFromForm.put("rowEnd", new Integer(openChargebacksForm.getCurrentRecord() + maxRows - 1));
		}

		String searchCBK = (String) request.getParameter("searchCBK");
		log.debug("-------searchCBK------" + searchCBK);

		searchParametersFromForm.put("userId", SmUserId);
		// Available Chargebacks List
		ResultList searchResults = adminDelegate.getAvailableChargebacks(searchParametersFromForm);
		log.debug("-------------getAvailableChargebacks()------searchResults--size----------"
				+ searchResults.getList().size());

		// Populate the 'searchResults' property in the ActionForm
		openChargebacksForm.setSearchResults(searchResults.getList());
		openChargebacksForm.setTotalRecords(searchResults.getTotalCount().intValue());

		mav.setViewName(ActionUrlMapping.OPENCHARGEBACKSACTION.get(Constants.ACTION_SUCCESS));
		request.setAttribute("actionMessages", errors);
		request.setAttribute("openChargebacksForm", openChargebacksForm);

		return mav;

	}

}