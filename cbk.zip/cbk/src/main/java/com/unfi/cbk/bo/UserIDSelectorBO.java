package com.unfi.cbk.bo;

/**
 * 
 * @author yhp6y2l
 *
 */

public class UserIDSelectorBO {

	@Override
	public String toString() {
		return "UserIDSelectorBO [userID=" + userID + ", userName=" + userName + "]";
	}

	private String userID = null;

	private String userName = null;

	public String getUserID() {
		return userID;
	}

	public void setUserID(String userID) {
		this.userID = userID;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

}