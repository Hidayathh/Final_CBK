
package com.unfi.cbk.common.util;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import com.unfi.cbk.common.util.ui.Securable;


/**
 * 
 * @author yhp6y2l
 *
 */
public class PermissionResolver {

	public static List processList(HttpServletRequest request, List objects) {
		List l = null;
		if (objects != null) {
			l = new ArrayList();
			for (int i = 0; i < objects.size(); i++) {
				Securable securable = (Securable) objects.get(i);
				if (processRoles(request, securable)) {
					l.add(objects.get(i));
				}
			}
		}
		return l;
	}

	public static boolean processRoles(HttpServletRequest request, Securable object) {

		// Is this action protected by role requirements?
		String roles[] = object.getRoleNames();
		System.out.println("--------PermissionResolver.java---processRoles()----" + roles);
		if ((roles == null) || (roles.length < 1)) {
			return (true);
		}
		// Check the current user against the list of required roles
		for (int i = 0; i < roles.length; i++) {
			if (request.isUserInRole(roles[i])) {
				return (true);
			}
		}
		return (false);
	}

}
