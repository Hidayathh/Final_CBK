/* Created on Jul 9, 2004 by tcmsr0 */
package com.unfi.cbk.ui;

public class Image {
	private String fileName;
	private String fileLocation;
	private String downLocation;
	private String alt;
	private String css;
	private int height;
	private int width;

	public String getAlt() {
		return alt;
	}

	public String getCss() {
		return css;
	}

	public int getHeight() {
		return height;
	}

	public String getUrl() {
		return fileName;
	}

	public int getWidth() {
		return width;
	}

	public void setAlt(String string) {
		alt = string;
	}

	public void setCss(String string) {
		css = string;
	}

	public void setHeight(int i) {
		height = i;
	}

	public void setUrl(String string) {
		fileName = string;
	}

	public void setWidth(int i) {
		width = i;
	}

	public String getFileLocation() {
		return fileLocation;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileLocation(String string) {
		fileLocation = string;
	}

	public void setFileName(String string) {
		fileName = string;
	}

	public String toString() {
		StringBuffer buf = new StringBuffer();
		buf.append("--- IMAGE ---\n");
		buf.append("Name: " + this.getFileName() + "\n");
		buf.append("Location: " + this.getFileLocation() + "\n");
		buf.append("ALT: " + this.getAlt() + "\n");
		return buf.toString();
	}

	public String getDownLocation() {
		return downLocation;
	}

	public void setDownLocation(String string) {
		downLocation = string;
	}

}