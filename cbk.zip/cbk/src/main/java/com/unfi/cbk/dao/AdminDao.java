package com.unfi.cbk.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.unfi.cbk.beans.ResultList;
import com.unfi.cbk.bo.ChargebackBO;
import com.unfi.cbk.bo.CreateNewUserBO;
import com.unfi.cbk.exceptions.DataAccessException;

/**
 * The ChargebackSearchDao interface creates the bridge between the caller and
 * the actual work in retrieving the data.
 *
 * @author yhp6y2l
 * @since 1.0
 */
public interface AdminDao {

	/**
	 * Gets the search results from the database. This method takes the search
	 * values provided on the form and creates a database query. The list of
	 * documents that match the criteria are the results that are returned to the
	 * caller.
	 * 
	 * @return the list of chargebacks from the index table
	 * @param formSearchValuesMap the Map for the search page
	 * @since 1.0
	 */
	public ResultList getChargebacks(Map formSearchValuesMap) throws DataAccessException;

	public ResultList getAvailableChargebacks(Map formSearchValuesMap) throws DataAccessException;

	public List getRolesByUserForMenu() throws DataAccessException;

	public void createCbkDistribution(List distributionList) throws DataAccessException;

	public ResultList adminResults(Map map) throws DataAccessException;

	public ResultList userDetails(Map map) throws DataAccessException;

	/* For AuditDetails */

	public ResultList getTypeAmount(Map map) throws DataAccessException;

	/* For AdminDetails */

	public CreateNewUserBO getUserDetails(String userId) throws DataAccessException;

	public HashMap getRolesByUserForMenu(Map formSearchValuesMap) throws DataAccessException;

	public List getLocations() throws DataAccessException;

	public List getRoles() throws DataAccessException;

	public ResultList getUserRolesLocations(String userId) throws DataAccessException;

	public void createCbkItem(ChargebackBO chargeBack) throws DataAccessException;

	public void createChargeback(ChargebackBO chargeBack) throws DataAccessException;

	public void updateInvoice(ChargebackBO newInvoiceBO) throws DataAccessException;

	public void createAttachment(ChargebackBO chargebackBO) throws DataAccessException;

	public List balanceAccrual(Map map) throws DataAccessException;

	public List getAccrualsList(Map map) throws DataAccessException;

	public List getExportId(String date)throws DataAccessException;
	
	
	
	

}