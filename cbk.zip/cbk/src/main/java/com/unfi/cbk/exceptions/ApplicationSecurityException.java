package com.unfi.cbk.exceptions;

/**
 * @author yhp6y2l
 * @version 1.0
 */
public class ApplicationSecurityException extends Exception {

	/**
	 * 
	 */
	public ApplicationSecurityException() {
		super();
	}

	/**
	 * @param message
	 */
	public ApplicationSecurityException(String message) {
		super(message);
	}

	/**
	 * @param message
	 * @param cause
	 */
	public ApplicationSecurityException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * @param cause
	 */
	public ApplicationSecurityException(Throwable cause) {
		super(cause);
	}

}
