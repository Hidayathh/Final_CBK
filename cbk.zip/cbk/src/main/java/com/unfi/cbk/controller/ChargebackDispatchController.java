package com.unfi.cbk.controller;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import com.unfi.cbk.dao.DaoFactory;
import com.unfi.cbk.util.ActionMessages;

/**
 * The InquiryDisptachAction class extends DispatchAction and is extended by the
 * StationConfigActions class. Rather than having the StationConfigActions
 * directly extend DispatchAction this class is implemented to provide common
 * convenience methods to all of the methods in StationConfigActions.
 * 
 */

public abstract class ChargebackDispatchController {// extends PASSAccessBaseAction {
	static Logger log = Logger.getLogger(ChargebackDispatchController.class);
	@Autowired
	ActionMessages errors;

	public void loadPage() throws Exception {
		// UserDataBean userBean = new UserDataBean(request);
		// request.setAttribute(Constants.ATTRIBUTE_USER_BEAN, userBean);
	}



	protected Object getDAO(String DaoName) {
		// Get the correct Dao from the factory to populate the Locations drop-down
		return DaoFactory.getDao(DaoName);
	}

}