package com.unfi.cbk.dao.ibImpl;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.orm.ibatis.SqlMapClientTemplate;
import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;

import com.unfi.cbk.beans.ResultList;
import com.unfi.cbk.bo.ChargebackBO;
import com.unfi.cbk.bo.CreateNewUserBO;
import com.unfi.cbk.dao.ChargebackSearchDao;
import com.unfi.cbk.exceptions.DataAccessException;

/**
 * The ChargebackSearchDaoImpl class handles the call to the database to get the
 * results of the chargebacks search based on the form values.
 *
 * @author vpil001
 * @since 1.0
 */

public class ChargebackSearchDaoImpl extends SqlMapClientDaoSupport implements ChargebackSearchDao {

	private static Logger log = Logger.getLogger(ChargebackSearchDaoImpl.class);
	protected static Date BAD_DATE = null;
	private ResultList rL;

	public ChargebackSearchDaoImpl(SqlMapClientTemplate sqlMapTemplate) {
		this.setSqlMapClientTemplate(sqlMapTemplate);
	}

	/**
	 * 
	 */

	public ResultList getChargebacks(Map formSearchValuesMap) throws DataAccessException {
		ResultList rL = new ResultList();

		try {

			rL.setList((List<Integer>) getSqlMapClientTemplate().queryForList("ChargebackSearch.getChargebacks",
					formSearchValuesMap));
			System.out.println("------------ChargebackSearchDaoImpl.java--ResultList size--getChargebacks()--" + rL.getList().size());
			if (rL.getList().size() == 0) {
				rL.setTotalCount(new Integer(0));
			} else if (formSearchValuesMap.get("showAll") != null
					&& ((String) formSearchValuesMap.get("showAll")).equals("true")) {
				rL.setTotalCount(new Integer(rL.getList().size()));
			} else {
				rL.setTotalCount((Integer) getSqlMapClientTemplate()
						.queryForObject("ChargebackSearch.getChargebacksCount", formSearchValuesMap));
			}

		} catch (Exception e) {
			e.printStackTrace();
			log.error("Error in getChargebacks() " + e);
			throw new DataAccessException(e);
		}

		return rL;
	}

	/**
	 * 
	 */
	public ResultList getAvailableChargebacks(Map formSearchValuesMap) throws DataAccessException {
		ResultList rL = new ResultList();

		try {

			rL.setList((List<Integer>) getSqlMapClientTemplate()
					.queryForList("ChargebackSearch.getAvailableChargebacks", formSearchValuesMap));
			System.out.println("------------ChargebackSearchDaoImpl.java--ResultList size----" + rL.getList().size());
			if (rL.getList().size() == 0) {
				rL.setTotalCount(new Integer(0));
			} else if (formSearchValuesMap.get("showAll") != null
					&& ((String) formSearchValuesMap.get("showAll")).equals("true")) {
				rL.setTotalCount(new Integer(rL.getList().size()));
			} else {
				rL.setTotalCount((Integer) getSqlMapClientTemplate()
						.queryForObject("ChargebackSearch.getAvailableChargebacksCount", formSearchValuesMap));
			}

		} catch (Exception e) {
			e.printStackTrace();
			log.error("Error in getAvailableChargebacks() " + e);
			throw new DataAccessException(e);
		}
		return rL;
	}

	/**
	 * 
	 */

	public void approveChargebacks(ChargebackBO cbkBo) throws DataAccessException {

		try {
			getSqlMapClientTemplate().insert("ChargebackSearch.insertApprovals", cbkBo);
		} catch (Exception e) {
			log.error(e);
			throw new DataAccessException(e);
		}
	}

	/**
	 * 
	 */
	public void denyChargebacks(ChargebackBO cbkBo) throws DataAccessException {
		try {
			getSqlMapClientTemplate().insert("ChargebackSearch.updateApprovals", cbkBo);
		} catch (Exception e) {
			log.error(e);
			throw new DataAccessException(e);
		}
	}

	/**
	 * 
	 */
	public ChargebackBO getChargebackDetail(Map formSearchValuesMap) throws DataAccessException {
		ChargebackBO c = null;

		try {
			// HashMap map = new HashMap();
			// map.put("authCode", authCode);

			c = (ChargebackBO) getSqlMapClientTemplate().queryForObject("ChargebackSearch.getChargebackDetail",
					formSearchValuesMap);

		} catch (Exception e) {
			log.error(e);
			throw new DataAccessException(e);
		}

		checkIfNull(c);
		return c;
	}

	/**
	 * 
	 */
	public ResultList getCbkDetTable(Map formSearchValuesMap) throws DataAccessException {
		ResultList rL = new ResultList();

		try {

			rL.setList((List<Integer>) getSqlMapClientTemplate().queryForList("ChargebackSearch.getCbkDetTable",
					formSearchValuesMap));
			System.out.println("----ChargebackSearchDaoImpl.java--getCbkDetTable()--ResultList size----" + rL.getList().size());
			if (rL.getList().size() == 0) {
				rL.setTotalCount(new Integer(0));
			}
		} catch (Exception e) {
			log.error("Error in getCbkDetTable() " + e);
			e.printStackTrace();
			throw new DataAccessException(e);
		}
		return rL;
	}
	
	public ResultList getCbkDetTableInfo(Map formSearchValuesMap) throws DataAccessException {
		ResultList rL = new ResultList();

		try {
			rL.setList((List<Integer>) getSqlMapClientTemplate().queryForList("ChargebackSearch.getCbkDetTableInfo", formSearchValuesMap));
			System.out.println("----ChargebackSearchDaoImpl.java--getCbkDetTableInfo()--ResultList size----" + rL.getList().size());
			if (rL.getList().size() == 0) {
				rL.setTotalCount(new Integer(0));
			}
		} catch (Exception e) {
			log.error("Error in getCbkDetTable() " + e);
			e.printStackTrace();
			throw new DataAccessException(e);
		}
		return rL;
	}
	

	/**
	 * 
	 */

	public ResultList getChargebackDistribution(Map formSearchValuesMap) throws DataAccessException {
		ResultList rL = new ResultList();

		try {

			rL.setList((List<Integer>) getSqlMapClientTemplate()
					.queryForList("ChargebackSearch.getChargebackDistribution", formSearchValuesMap));
			System.out.println("------------ChargebackSearchDaoImpl.java--ResultList size----" + rL.getList().size());
			if (rL.getList().size() == 0) {
				rL.setTotalCount(new Integer(0));
			}
		} catch (Exception e) {
			log.error("Error in getChargebackDistribution() " + e);
			e.printStackTrace();
			throw new DataAccessException(e);
		}
		return rL;
	}

	/**
	 * 
	 */
	public ChargebackBO getChargebackInfo(Map formSearchValuesMap) throws DataAccessException {
		ChargebackBO c = null;

		try {
			// HashMap map = new HashMap();
			// map.put("authCode", authCode);

			c = (ChargebackBO) getSqlMapClientTemplate().queryForObject("ChargebackSearch.getChargebackInfo",
					formSearchValuesMap);

		} catch (Exception e) {
			log.error(e);
			throw new DataAccessException(e);
		}

		checkIfNull(c);
		return c;
	}
	/*
	 * 
	 */

	public ResultList getApproverRoles(Map formSearchValuesMap) throws DataAccessException {

		rL = null;
		try {
			// HashMap map = new HashMap();
			System.out.println("------in Impl---------");
			rL.setList((List<Integer>) getSqlMapClientTemplate().queryForList("ChargebackSearch.getApprovalRoles",
					formSearchValuesMap));
			System.out.println("------------ChargebackSearchDaoImpl.java-getApprovalRoles---ResultList size----"
					+ rL.getList().size());

		} catch (Exception e) {
			e.printStackTrace();
			log.error(e);
			throw new DataAccessException(e);
		}
		// checkIfNull(s);
		return rL;
	}

	/*
	 * 
	 */
	public ChargebackBO getChargebackVendor(Map formSearchValuesMap) throws DataAccessException {
		ChargebackBO c = null;

		try {
			c = (ChargebackBO) getSqlMapClientTemplate().queryForObject("ChargebackSearch.getVendorInfo",
					formSearchValuesMap);

		} catch (Exception e) {
			log.error(e);
			throw new DataAccessException(e);
		}

		// checkIfNull(c);
		return c;
	}

	/*
	 * 
	 */
	public void createChargeback(ChargebackBO chargeBack) throws DataAccessException {
		try {
			getSqlMapClientTemplate().insert("ChargebackSearch.insertChargeback", chargeBack);
		} catch (Exception e) {
			log.error(e);
			throw new DataAccessException(e);
		}
	}

	/*
	 * 
	 */
	public void updateChargeback(ChargebackBO chargeBack) throws DataAccessException {
		try {
			System.out.println("-----in DAOIMPL---updateChargeback()---");
			getSqlMapClientTemplate().update("ChargebackSearch.updateChargeback", chargeBack);

		} catch (Exception e) {
			log.error(e);
			throw new DataAccessException(e);
		}
	}

	/*
	 * 
	 */
	public void createCbkDistribution(List list) throws DataAccessException {
		ChargebackBO chargeback = null;
		try {
			for (int i = 0; i < list.size(); i++) {

				ChargebackBO cbkBO = (ChargebackBO) list.get(i);
				getSqlMapClientTemplate().insert("ChargebackSearch.insertCbkDistribution", cbkBO);
				System.out.println("----INSERTED DISTRIBUTION ITEM ROW ----" + i);
			}
		} catch (Exception e) {
			log.error(e);
			throw new DataAccessException(e);
		}
	}

	/*
	 * 
	 */
	public void deleteCbkDistribution(Map formSearchValuesMap) throws DataAccessException {
		try {
			getSqlMapClientTemplate().insert("ChargebackSearch.deleteCbkDistribution", formSearchValuesMap);
		} catch (Exception e) {
			log.error(e);
			throw new DataAccessException(e);
		}
	}

	/*
	 * 
	 */
	public void deleteCbkItem(Map formSearchValuesMap) throws DataAccessException {
		try {
			getSqlMapClientTemplate().insert("ChargebackSearch.deleteCbkItem", formSearchValuesMap);
		} catch (Exception e) {
			log.error(e);
			throw new DataAccessException(e);
		}
	}

	/*
	 * 
	 */

	public void createCbkItem(List list) throws DataAccessException {

		try {
			for (int i = 0; i < list.size(); i++) {
				System.out.println("---ChargebackSearchDaoImpl.java---createCbkItem()--");

				ChargebackBO cbkBO = (ChargebackBO) list.get(i);
				getSqlMapClientTemplate().insert("ChargebackSearch.insertCbkItem", cbkBO);
				System.out.println("----INSERTED ITEM ROW ----" + i);
			}
		} catch (Exception e) {
			log.error(e);
			throw new DataAccessException(e);
		}
	}

	/*
	 * 
	 */

	public void createCbkItemSingleRecord(ChargebackBO chargeBack) throws DataAccessException {

		try {

			System.out.println("---ChargebackSearchDaoImpl.java---createCbkItem()--");

			getSqlMapClientTemplate().insert("ChargebackSearch.insertCbkItem", chargeBack);

		} catch (Exception e) {
			log.error(e);
			throw new DataAccessException(e);
		}
	}

	public void createCbkDistributionSingleRecord(ChargebackBO chargeBack) throws DataAccessException {

		try {

			System.out.println("---ChargebackSearchDaoImpl.java---createCbkDistributionSingleRecord()--");

			getSqlMapClientTemplate().insert("ChargebackSearch.insertCbkDistribution", chargeBack);

		} catch (Exception e) {
			log.error(e);
			throw new DataAccessException(e);
		}
	}

	/*
	 * 
	 */
	public void updateCbkItem(List list) throws DataAccessException {
		ChargebackBO chargeback = null;
		try {
			for (int i = 0; i < list.size(); i++) {
				Map map = new HashMap();
				map = (Map) list.get(i);

				getSqlMapClientTemplate().insert("ChargebackSearch.insertCbkItem", map);
				System.out.println("----INSERTED ITEM ROW ----" + i);
			}
		} catch (Exception e) {
			log.error(e);
			e.printStackTrace();
			throw new DataAccessException(e);
		}
	}

	/*
	 * 
	 */
	public ChargebackBO getChargeback(Map formSearchValuesMap) throws DataAccessException {
		ChargebackBO c = null;

		try {
			// HashMap map = new HashMap();
			// map.put("authCode", authCode);

			c = (ChargebackBO) getSqlMapClientTemplate().queryForObject("ChargebackSearch.getChargeback",
					formSearchValuesMap);

		} catch (Exception e) {
			log.error(e);
			throw new DataAccessException(e);
		}

		checkIfNull(c);
		return c;
	}

	/*
	 * 
	 */
	public List<ChargebackBO> getChargebackTypes() throws DataAccessException {

		List<ChargebackBO> l = null;
		try {
			l = (List) getSqlMapClientTemplate().queryForList("ChargebackSearch.getChargebackTypes");
		} catch (Exception e) {
			e.printStackTrace();
			log.error(e);
			throw new DataAccessException(e);
		}
		return l;
	}

	public List getReasons() throws DataAccessException {

		List l = null;
		try {
			l = (List) getSqlMapClientTemplate().queryForList("ChargebackSearch.getReasons");
		} catch (Exception e) {
			e.printStackTrace();
			log.error(e);
			throw new DataAccessException(e);
		}
		return l;
	}

	public List getProductGroup() throws DataAccessException {

		List l = null;
		try {
			// HashMap map = new HashMap();
			l = (List) getSqlMapClientTemplate().queryForList("ChargebackSearch.getProductGroup");

		} catch (Exception e) {
			e.printStackTrace();
			log.error(e);
			throw new DataAccessException(e);
		}
		return l;
	}

	public ResultList locationNumberValidator(Map formSearchValuesMap) throws DataAccessException {
		ResultList rL = new ResultList();
		try {
			// HashMap map = new HashMap();
			rL.setList((List) getSqlMapClientTemplate().queryForList("ChargebackSearch.locationNumberValidator",
					formSearchValuesMap));

		} catch (Exception e) {
			e.printStackTrace();
			log.error(e);
			throw new DataAccessException(e);
		}
		// checkIfNull(s);
		return rL;
	}

	public ResultList invoiceNumberValidator(Map formSearchValuesMap) throws DataAccessException {
		ResultList rL = new ResultList();
		try {
			rL.setList((List) getSqlMapClientTemplate().queryForList("ChargebackSearch.invoiceNumberValidator",
					formSearchValuesMap));

		} catch (Exception e) {
			e.printStackTrace();
			log.error(e);
			throw new DataAccessException(e);
		}
		// checkIfNull(s);
		return rL;
	}

	public ResultList vendorNumberValidator(String vendorId) throws DataAccessException {
		ResultList rL = new ResultList();
		try {
			HashMap map = new HashMap();
			 map.put("vendorId", vendorId);
			rL.setList((List) getSqlMapClientTemplate().queryForList("ChargebackSearch.vendorNumberValidator",	map));

		} catch (Exception e) {
			e.printStackTrace();
			log.error(e);
			throw new DataAccessException(e);
		}
		// checkIfNull(s);
		return rL;
	}

	public ResultList originatorValidator(Map formSearchValuesMap) throws DataAccessException {
		ResultList rL = new ResultList();
		try {
			rL.setList((List) getSqlMapClientTemplate().queryForList("ChargebackSearch.originatorValidator",
					formSearchValuesMap));

		} catch (Exception e) {
			e.printStackTrace();
			log.error(e);
			throw new DataAccessException(e);
		}
		// checkIfNull(s);
		return rL;
	}

	public ResultList nextApproverValidator(Map formSearchValuesMap) throws DataAccessException {
		ResultList rL = new ResultList();
		try {
			rL.setList((List) getSqlMapClientTemplate().queryForList("ChargebackSearch.nextApproverValidator",
					formSearchValuesMap));

		} catch (Exception e) {
			e.printStackTrace();
			log.error(e);
			throw new DataAccessException(e);
		}
		// checkIfNull(s);
		return rL;
	}

	/**
	 * Check if an object is null and throw a DataAccessException if it is.
	 * 
	 * @param o the object to test
	 * @throws DataAccessException whenever the object is null
	 */
	private void checkIfNull(Object o) throws DataAccessException {
		if (o == null) {
			throw new DataAccessException("Object not found.");
		}
	}

	@Override
	public void insertMenuAccessforUser(List selectedAccessList) throws DataAccessException {

		try {
			if (selectedAccessList.size() > 0) {
				for (int i = 0; i < selectedAccessList.size(); i++) {
					CreateNewUserBO createUserBO = (CreateNewUserBO) selectedAccessList.get(i);
					getSqlMapClientTemplate().insert("ChargebackSearch.addMenusToUser", createUserBO);
					System.out.println("----INSERTED MENU ROW ----" + i);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			log.error(e);
			throw new DataAccessException(e);
		}
	}

	@Override
	public void InsertUser(List selectedRoleLocationList, Map formSearchValuesMap) throws DataAccessException {

		try {
			// HashMap map = new HashMap();
			// map.put("authCode", authCode);
			getSqlMapClientTemplate().insert("ChargebackSearch.createNewUser", formSearchValuesMap);
			try {
				if (selectedRoleLocationList.size() > 0) {
					for (int i = 0; i < selectedRoleLocationList.size(); i++) {
						CreateNewUserBO createUserBO = (CreateNewUserBO) selectedRoleLocationList.get(i);
						if (createUserBO.getUserId() != "" && createUserBO.getDistRoles() != ""
								&& createUserBO.getDistLocNumber() != "") {
							getSqlMapClientTemplate().insert("ChargebackSearch.addRolesToUser", createUserBO);
						}

					}
				}
			} catch (Exception e) {
				log.error(e);
				throw new DataAccessException(e);
			}
		} catch (Exception e) {
			e.printStackTrace();
			log.error(e);
			throw new DataAccessException(e);
		}

	}

	/*
	 * 
	 */
	@Override
	public List getLocations() throws DataAccessException {
		List l = null;
		try {
			// HashMap map = new HashMap();
			l = (List) getSqlMapClientTemplate().queryForList("ChargebackSearch.getLocations");

		} catch (Exception e) {
			e.printStackTrace();
			log.error(e);
			throw new DataAccessException(e);
		}

		return l;
	}

	@Override
	public List getLocationsForCreateUser() throws DataAccessException {
		List l = null;
		try {
			// HashMap map = new HashMap();
			l = (List) getSqlMapClientTemplate().queryForList("ChargebackSearch.getLocationsForCreateUser");

		} catch (Exception e) {
			e.printStackTrace();
			log.error(e);
			throw new DataAccessException(e);
		}

		return l;
	}

	@Override
	public List getRoles() throws DataAccessException {
		// TODO Auto-generated method stub

		List l = null;
		try {
			// HashMap map = new HashMap();
			l = (List) getSqlMapClientTemplate().queryForList("ChargebackSearch.getRoles");

		} catch (Exception e) {
			e.printStackTrace();
			log.error(e);
			throw new DataAccessException(e);
		}

		return l;
	}

	@Override
	public List getAllRoles() throws DataAccessException {
		// TODO Auto-generated method stub

		List l = null;
		try {
			// HashMap map = new HashMap();
			l = (List) getSqlMapClientTemplate().queryForList("ChargebackSearch.getAllRoles");

		} catch (Exception e) {
			e.printStackTrace();
			log.error(e);
			throw new DataAccessException(e);
		}
		System.out.println(l);
		return l;
	}

	@Override
	public ResultList getUserRolesLocations(String userId) throws DataAccessException {
		ResultList rL = new ResultList();
		try {

			HashMap map = new HashMap();
			map.put("userId", userId);
			rL.setList((List) getSqlMapClientTemplate().queryForList("ChargebackSearch.getUserRolesLocations", map));

		} catch (Exception e) {
			log.error(e);
			throw new DataAccessException(e);
		}
		// checkIfNull(l);
		return rL;
	}

	@Override
	public ResultList getUserAssignedRoles(String userId) throws DataAccessException {
		ResultList rL = new ResultList();
		try {

			HashMap map = new HashMap();
			map.put("userId", userId);
			rL.setList((List) getSqlMapClientTemplate().queryForList("ChargebackSearch.getUserAssignedRoles", map));

		} catch (Exception e) {
			log.error(e);
			throw new DataAccessException(e);
		}
		// checkIfNull(l);
		return rL;
	}

	@Override
	public CreateNewUserBO getUserDetails(String userId) throws DataAccessException {
		CreateNewUserBO c = null;

		try {

			HashMap map = new HashMap();
			System.out.println("------in Impl---getUserDetails()-----userId--"+userId);
			map.put("userId", userId);
			c = (CreateNewUserBO) getSqlMapClientTemplate().queryForObject("ChargebackSearch.getUserDetails", map);

		} catch (Exception e) {
			log.error(e);
			throw new DataAccessException(e);
		}

		checkIfNull(c);
		return c;

	}

	@Override
	public void EditUser(Map formSearchValuesMap) throws DataAccessException {

		try {
			getSqlMapClientTemplate().update("ChargebackSearch.editUser", formSearchValuesMap);

			getSqlMapClientTemplate().update("ChargebackSearch.addRolesToUser", formSearchValuesMap);

		} catch (Exception e) {
			e.printStackTrace();
			log.error(e);
			throw new DataAccessException(e);
		}

	}

	public void updateUser(List selectedRoleLocationList, Map formSearchValuesMap) throws DataAccessException {

		getSqlMapClientTemplate().update("ChargebackSearch.updateUser", formSearchValuesMap);
		getSqlMapClientTemplate().insert("ChargebackSearch.deleteRolesLocations", formSearchValuesMap);

		try {
			if (selectedRoleLocationList.size() > 0) {
				for (int i = 0; i < selectedRoleLocationList.size(); i++) {
					CreateNewUserBO createUserBO = (CreateNewUserBO) selectedRoleLocationList.get(i);
					getSqlMapClientTemplate().insert("ChargebackSearch.addRolesToUser", createUserBO);

				}
			}
		} catch (Exception e) {
			log.error(e);
			throw new DataAccessException(e);

		}
	}

	/*
	 * 
	 */

	@Override
	public String getCompanyCode(String locationNumber) throws DataAccessException {

		String companyCode = null;
		try {
			companyCode = (String) getSqlMapClientTemplate().queryForObject("ChargebackSearch.getCompanyCode",
					locationNumber);

		} catch (Exception e) {
			e.printStackTrace();
			log.error(e);
			throw new DataAccessException(e);
		}

		return companyCode;
	}

	/*
	 * 
	 */
	@Override
	public String getStepNumberForMassApproval(String typeId, String roleId) throws DataAccessException
	{
		String maxStep = null;
		try {

			HashMap<String, String> map = new HashMap<String, String>();
			map.put("typeId", typeId);
			map.put("roleId", roleId);

			maxStep = (String) getSqlMapClientTemplate().queryForObject("ChargebackSearch.getStepNumberForMassApproval", map);

		} catch (Exception e) {
			e.printStackTrace();
			log.error(e);
			throw new DataAccessException(e);
		}

		return maxStep;
		
		
	}
	
	@Override
	public String getMaxStepNumber(String typeId) throws DataAccessException {

		String maxStep = null;
		try {

			HashMap<String, String> map = new HashMap<String, String>();
			map.put("typeId", typeId);

			maxStep = (String) getSqlMapClientTemplate().queryForObject("ChargebackSearch.getMaxStepNumber", map);

		} catch (Exception e) {
			e.printStackTrace();
			log.error(e);
			throw new DataAccessException(e);
		}

		return maxStep;
	}

	@Override
	public String getMinStepNumber(String typeId) throws DataAccessException {

		String maxStep = null;
		try {

			HashMap<String, String> map = new HashMap<String, String>();
			map.put("typeId", typeId);

			maxStep = (String) getSqlMapClientTemplate().queryForObject("ChargebackSearch.getMinStepNumber", map);

		} catch (Exception e) {
			e.printStackTrace();
			log.error(e);
			throw new DataAccessException(e);
		}

		return maxStep;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.unfi.cbk.dao.ChargebackCommonDao#doApproverSearch(java.lang.String,
	 * java.lang.String)
	 */
	public List<Integer> doChargebackApproverSearch(String SmUserId, String locationNumber, String roleId,
			String typeId) throws DataAccessException {
		List<Integer> l = null;

		try {
			HashMap<String, String> map = new HashMap<String, String>();
			map.put("SmUserId", SmUserId);
			map.put("locationNumber", locationNumber);
			map.put("roleId", roleId);
			map.put("typeId", typeId);

			l = getSqlMapClientTemplate().queryForList("ChargebackSearch.doCbkApproverSearch", map);
		} catch (Exception e) {
			throw new DataAccessException(e);
		}

		return l;
	}

	/**
	 * 
	 */
	public String getApproverStepsUp(String typeId, String stepNumber) throws DataAccessException {
		String nextStepNumber = null;

		try {

			HashMap<String, String> map = new HashMap<String, String>();
			map.put("typeId", typeId);
			map.put("stepNumber", stepNumber);

			nextStepNumber = (String) getSqlMapClientTemplate().queryForObject("ChargebackSearch.getApproverStepsUp",
					map);

		} catch (Exception e) {
			throw new DataAccessException(e);
		}

		return nextStepNumber;
	}

	/*
	 * 
	 */
	public String getApproverStepsDown(String typeId, String stepNumber) throws DataAccessException {

		String nextStepNumber = null;

		try {

			HashMap<String, String> map = new HashMap<String, String>();
			map.put("typeId", typeId);
			map.put("stepNumber", stepNumber);

			nextStepNumber = (String) getSqlMapClientTemplate().queryForObject("ChargebackSearch.getApproverStepsDown",
					map);

		} catch (Exception e) {
			throw new DataAccessException(e);
		}

		return nextStepNumber;
	}

	@Override
	public String getRoleIdByStepAndType(String typeId, String stepNumber) throws DataAccessException {

		String roleId = null;
		try {

			HashMap<String, String> map = new HashMap<String, String>();
			map.put("typeId", typeId);
			map.put("stepNumber", stepNumber);

			roleId = (String) getSqlMapClientTemplate().queryForObject("ChargebackSearch.getRoleIdByStepAndType", map);

		} catch (Exception e) {
			e.printStackTrace();
			log.error(e);
			throw new DataAccessException(e);
		}

		return roleId;
	}

	public HashMap getRolesByUserForMenu(Map formSearchValuesMap) throws DataAccessException {

		List menuLinkList = null;
		HashMap map = new HashMap();
		try {

			menuLinkList = getSqlMapClientTemplate().queryForList("ChargebackSearch.getRolesByUserForMenu",
					formSearchValuesMap);
			for (int i = 0; i < menuLinkList.size(); i++) {

				map.put(i, menuLinkList.get(i));
			}

		} catch (Exception e) {
			log.error(e);
			throw new DataAccessException(e);
		}
		// checkIfNull(s);
		return map;
	}

	@Override
	public void deleteUserDetails(String userId) throws DataAccessException {
		// TODO Auto-generated method stub
		try {
			Map map = new HashMap();
			map.put("userId", userId);

			getSqlMapClientTemplate().delete("ChargebackSearch.deleteRolesLocations", map);
			getSqlMapClientTemplate().update("ChargebackSearch.deleteUser", map);

		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public void insertInvoice(ChargebackBO cbkBo) throws DataAccessException {

		try {
			getSqlMapClientTemplate().insert("ChargebackSearch.insertInvoice", cbkBo);
		} catch (Exception e) {
			log.error(e);
			throw new DataAccessException(e);
		}
	}

	@Override
	public ChargebackBO getNextInvoceNumberOrBarcode(String locationNumber) throws DataAccessException {

		ChargebackBO c = null;
		try {

			HashMap<String, String> map = new HashMap<String, String>();
			map.put("locationNumber", locationNumber);
			c = (ChargebackBO) getSqlMapClientTemplate().queryForObject("ChargebackSearch.getNextInvoceNumberOrBarcode",
					map);

		} catch (Exception e) {
			e.printStackTrace();
			log.error(e);
			throw new DataAccessException(e);
		}

		return c;
	}

	/**
	 * 
	 */
	public void updateInvoice(ChargebackBO cbkBo) throws DataAccessException {
		try {
			getSqlMapClientTemplate().insert("ChargebackSearch.updateInvoice", cbkBo);
		} catch (Exception e) {
			log.error(e);
			throw new DataAccessException(e);
		}
	}

	public void updateChargebackApprover(ChargebackBO chargeBack) throws DataAccessException {
		try {
			getSqlMapClientTemplate().update("ChargebackSearch.updateChargebackApprover", chargeBack);

		} catch (Exception e) {
			log.error(e);
			throw new DataAccessException(e);
		}
	}

	public void updateAttachment(ChargebackBO chargebackBO) throws DataAccessException {

		try {

			getSqlMapClientTemplate().insert("ChargebackSearch.insertAttachment", chargebackBO);

		} catch (Exception e) {
			log.error("Error in updateAttachment() " + e);
			e.printStackTrace();
			throw new DataAccessException(e);
		}

	}

	public void createAttachment(ChargebackBO chargebackBO) throws DataAccessException {

		try {
			getSqlMapClientTemplate().insert("ChargebackSearch.crateAttachment", chargebackBO);

		} catch (Exception e) {
			log.error("Error in createAttachment() " + e);
			e.printStackTrace();
			throw new DataAccessException(e);
		}

	}

	public void updateChargebackDenyReason(ChargebackBO chargeBack) throws DataAccessException {
		try {
			getSqlMapClientTemplate().update("ChargebackSearch.updateChargebackDenyReason", chargeBack);

		} catch (Exception e) {
			log.error(e);
			throw new DataAccessException(e);
		}
	}

	@Override
	public List<ChargebackBO> getAttachmentName(String invoiceNumber) throws DataAccessException {
		System.out.println("invoiceNumber @@@@:" + invoiceNumber);
		List<ChargebackBO> l = null;
		try {

			l = getSqlMapClientTemplate().queryForList("ChargebackSearch.getAttachmentName", invoiceNumber);

		} catch (Exception e) {
			log.error(e);
			throw new DataAccessException(e);
		}
		return l;
	}

	@Override
	public ChargebackBO findByAttachmentName(ChargebackBO chargebackBO) throws DataAccessException {
		ChargebackBO cbkBo = new ChargebackBO();
		try {
			cbkBo = (ChargebackBO) getSqlMapClientTemplate().queryForObject("ChargebackSearch.findByAttachmentName",
					chargebackBO);

		} catch (Exception e) {
			log.error(e);
			throw new DataAccessException(e);
		}

		return cbkBo;
	}

	public void deleteAttachment(String invoiceNumber) throws DataAccessException {
		System.out.println("attachmentName @@@@:" + invoiceNumber);
		try {
			Map<String, String> map = new HashMap<String, String>();
			map.put("invoiceNumber", invoiceNumber);
			getSqlMapClientTemplate().delete("ChargebackSearch.deleteAttachment", map);

		} catch (Exception e) {
			log.error(e);
			throw new DataAccessException(e);
		}
	}

	public ResultList getAccountProductCodes(Map params) throws DataAccessException {

		ResultList rL = new ResultList();
		try {

			rL.setList(
					(List) getSqlMapClientTemplate().queryForList("ChargebackSearch.getAccountProductCodes", params));

		} catch (Exception e) {
			e.printStackTrace();
			log.error(e);
			throw new DataAccessException(e);
		}
		return rL;
	}

	@Override
	public List getLocationsByUser(String approverId) throws DataAccessException {
		List l = null;
		try {
			l = (List) getSqlMapClientTemplate().queryForList("ChargebackSearch.getLocationsByUser", approverId);

		} catch (Exception e) {
			e.printStackTrace();
			log.error(e);
			throw new DataAccessException(e);
		}

		return l;
	}

	public ResultList getAvailableInvoiceNumber(String invoice, String location) throws DataAccessException {

		ResultList rL = new ResultList();
		try {
			HashMap m = new HashMap();
			m.put("invoiceNumber", invoice);
			m.put("locationNumber", location);
			rL.setList((List) getSqlMapClientTemplate().queryForList("ChargebackSearch.getAvailableInvoiceNumber",m));

		} catch (Exception e) {
			e.printStackTrace();
			log.error(e);
			throw new DataAccessException(e);
		}
		// checkIfNull(s);
		return rL;
	}

	public ResultList getApprovalHistory(String invoice) throws DataAccessException {

		ResultList rL = new ResultList();
		try {

			rL.setList((List) getSqlMapClientTemplate().queryForList("ChargebackSearch.getApprovalHistory", invoice));

		} catch (Exception e) {
			e.printStackTrace();
			log.error(e);
			throw new DataAccessException(e);
		}
		// checkIfNull(s);
		return rL;
	}

	public void deleteApprovals(String invoiceNumber, String locationNumber) throws DataAccessException {
		try {
			Map<String, String> map = new HashMap<String, String>();
			map.put("invoiceNumber", invoiceNumber);
			map.put("locationNumber", locationNumber);
			getSqlMapClientTemplate().delete("ChargebackSearch.deleteApprovals", map);

		} catch (Exception e) {
			log.error(e);
			throw new DataAccessException(e);
		}
	}

	@Override
	public ResultList getChargebackApprovalStatus(String invoiceNumber, String approverId) throws DataAccessException {
		ResultList rL = new ResultList();
		try {

			HashMap map = new HashMap();
			map.put("invoiceNumber", invoiceNumber);
			map.put("approverId", approverId);
			rL.setList(
					(List) getSqlMapClientTemplate().queryForList("ChargebackSearch.getChargebackApprovalStatus", map));

		} catch (Exception e) {
			log.error(e);
			throw new DataAccessException(e);
		}
		// checkIfNull(l);
		return rL;
	}

	@Override
	public String getAdminUser(String userId, String roleId) throws DataAccessException {

		String maxStep = null;
		try {

			HashMap<String, String> map = new HashMap<String, String>();
			map.put("userId", userId);
			map.put("roleId", roleId);

			maxStep = (String) getSqlMapClientTemplate().queryForObject("ChargebackSearch.getAdminUser", map);

		} catch (Exception e) {
			e.printStackTrace();
			log.error(e);
			throw new DataAccessException(e);
		}

		return maxStep;
	}

	@Override
	public ResultList getMassApprovalsList(Map formSearchValuesMap) throws DataAccessException {
		ResultList rL = new ResultList();

		try {

			rL.setList((List) getSqlMapClientTemplate().queryForList("ChargebackSearch.getMassApprovalsList",	formSearchValuesMap));
			
		} catch (Exception e) {
			e.printStackTrace();
			log.error("Error in getChargebacks() " + e);
			throw new DataAccessException(e);
		}

		return rL;
	}

	@Override
	public String getValidVendorNumber(String vendorId) throws DataAccessException {

		String valiVendorId = null;
		try {

			HashMap<String, Integer> map = new HashMap<String, Integer>();
			map.put("vendorId", Integer.parseInt(vendorId));
			valiVendorId = (String) getSqlMapClientTemplate().queryForObject("ChargebackSearch.getValidVendorNumber",
					map);

		} catch (Exception e) {
			e.printStackTrace();
			log.error(e);
			throw new DataAccessException(e);
		}

		return valiVendorId;
	}
	
	
	@Override
	public ResultList getRoleIdRouteIdForUser(Map map) throws DataAccessException {
		ResultList rL = new ResultList();
		try {
			System.out.println("---------ChargebackSearchDaoImpl---getRoleIdRouteIdForUser()--");
			rL.setList((List) getSqlMapClientTemplate().queryForList("ChargebackSearch.getRoleIdRouteIdForUser", map));

		} catch (Exception e) {
			log.error(e);
			throw new DataAccessException(e);
		}
		// checkIfNull(l);
		return rL;
	}

	@Override
	public String getApprovalLimitForUser(Map map) throws DataAccessException {

		String floorAmount = null;
		try {

			floorAmount = (String) getSqlMapClientTemplate().queryForObject("ChargebackSearch.getApprovalLimitForUser",	map);

		} catch (Exception e) {
			e.printStackTrace();
			log.error(e);
			throw new DataAccessException(e);
		}

		return floorAmount;
	}

	@Override
	public String deleteApproverReference(String userId) throws DataAccessException {

		String approverReference = null;
		try {

			HashMap<String, String> map = new HashMap<String, String>();
			map.put("userId", userId);

			approverReference = (String) getSqlMapClientTemplate()
					.queryForObject("ChargebackSearch.deleteApproverReference", map);

		} catch (Exception e) {
			e.printStackTrace();
			log.error(e);
			throw new DataAccessException(e);
		}

		return approverReference;
	}

	public void massUpdateChargebackApprover(List massApprovalList) throws DataAccessException {
		try {
			for (int i = 0; i < massApprovalList.size(); i++) {

				ChargebackBO cbkBO = (ChargebackBO) massApprovalList.get(i);

				getSqlMapClientTemplate().update("ChargebackSearch.updateChargebackApprover", cbkBO);
				
				getSqlMapClientTemplate().insert("ChargebackSearch.insertApprovals", cbkBO);

			}

		} catch (Exception e) {
			log.error(e);
			throw new DataAccessException(e);
		}
	}

	/*
	 * public void massApproveChargebacks(List massApprovalList) throws
	 * DataAccessException { try { for (int i = 0; i < massApprovalList.size(); i++)
	 * {
	 * 
	 * ChargebackBO cbkBO = (ChargebackBO) massApprovalList.get(i);
	 * getSqlMapClientTemplate().insert("ChargebackSearch.insertApprovals", cbkBO);
	 * }
	 * 
	 * } catch (Exception e) { log.error(e); throw new DataAccessException(e); } }
	 */

	@Override
	public String getValidAccountNumber(String companyCode, String accNum, String acct_unit)
			throws DataAccessException {

		String validAccount = null;
		try {
			HashMap<String, String> map = new HashMap<String, String>();
			map.put("companyCode", companyCode);
			map.put("accNum", accNum);
			map.put("acct_unit", acct_unit);
			validAccount = (String) getSqlMapClientTemplate().queryForObject("ChargebackSearch.getValidAccountNumber",
					map);

		} catch (Exception e) {
			e.printStackTrace();
			log.error(e);
			throw new DataAccessException(e);
		}

		return validAccount;
	}

	@Override
	public String getInvoiceEditableStatus(String invoiceNumber) throws DataAccessException {

		String editableInvoice = null;
		try {
			editableInvoice = (String) getSqlMapClientTemplate()
					.queryForObject("ChargebackSearch.getInvoiceEditableStatus", invoiceNumber);

		} catch (Exception e) {
			e.printStackTrace();
			log.error(e);
			throw new DataAccessException(e);
		}

		return editableInvoice;
	}

	@Override
	public String getApprovalWith5KLimit(String userId, String locationNumber) throws DataAccessException {

		String roleId = null;
		try {
			HashMap<String, String> map = new HashMap<String, String>();
			map.put("userId", userId);
			map.put("locationNumber", locationNumber);

			roleId = (String) getSqlMapClientTemplate().queryForObject("ChargebackSearch.getApprovalWith5KLimit", map);

		} catch (Exception e) {
			e.printStackTrace();
			log.error(e);
			throw new DataAccessException(e);
		}

		return roleId;
	}

	@Override
	public String getMaxStepNumberForInvoice(String invoiceNumber) throws DataAccessException {

		String maxStepNumber = null;
		try {

			maxStepNumber = (String) getSqlMapClientTemplate()
					.queryForObject("ChargebackSearch.getMaxStepNumberForInvoice", invoiceNumber);

		} catch (Exception e) {
			e.printStackTrace();
			log.error(e);
			throw new DataAccessException(e);
		}

		return maxStepNumber;
	}

	@Override
	public String getInvoiceEligibleForApprove(String userId, String invoiceNumber) throws DataAccessException {

		String eligibleInvoice = null;
		try {
			HashMap<String, String> map = new HashMap<String, String>();
			map.put("userId", userId);
			map.put("invoiceNumber", invoiceNumber);

			eligibleInvoice = (String) getSqlMapClientTemplate()
					.queryForObject("ChargebackSearch.getInvoiceEligibleForApprove", map);

		} catch (Exception e) {
			e.printStackTrace();
			log.error(e);
			throw new DataAccessException(e);
		}

		return eligibleInvoice;
	}

	@Override
	public String getMaxStepNumberWithInvoiceAmount(String invoiceNumber, String locationNumber, String typeId)
			throws DataAccessException {

		String maxStep = null;
		try {

			HashMap<String, String> map = new HashMap<String, String>();
			map.put("invoiceNumber", invoiceNumber);
			map.put("locationNumber", locationNumber);
			map.put("typeId", typeId);

			maxStep = (String) getSqlMapClientTemplate()
					.queryForObject("ChargebackSearch.getMaxStepNumberWithInvoiceAmount", map);

		} catch (Exception e) {
			e.printStackTrace();
			log.error(e);
			throw new DataAccessException(e);
		}

		return maxStep;
	}

	@Override
	public String getMaxStepNumberWithAmount(String typeId, String chargebackTotal) throws DataAccessException {

		String maxStep = null;
		try {

			HashMap<String, String> map = new HashMap<String, String>();
			map.put("chargebackTotal", chargebackTotal);
			map.put("typeId", typeId);

			maxStep = (String) getSqlMapClientTemplate().queryForObject("ChargebackSearch.getMaxStepNumberWithAmount",
					map);

		} catch (Exception e) {
			e.printStackTrace();
			log.error(e);
			throw new DataAccessException(e);
		}

		return maxStep;
	}

	@Override
	public String getMinStepNumberWithAmount(String typeId, String chargebackTotal) throws DataAccessException {

		String minStep = null;
		try {

			HashMap<String, String> map = new HashMap<String, String>();
			map.put("chargebackTotal", chargebackTotal);
			map.put("typeId", typeId);

			minStep = (String) getSqlMapClientTemplate().queryForObject("ChargebackSearch.getMinStepNumberWithAmount",
					map);

		} catch (Exception e) {
			e.printStackTrace();
			log.error(e);
			throw new DataAccessException(e);
		}

		return minStep;
	}

	@Override
	public String getMinStepNumberWithInvoiceAmount(String invoiceNumber, String locationNumber, String typeId)
			throws DataAccessException {

		String minStep = null;
		try {

			HashMap<String, String> map = new HashMap<String, String>();
			map.put("invoiceNumber", invoiceNumber);
			map.put("locationNumber", locationNumber);
			map.put("typeId", typeId);

			minStep = (String) getSqlMapClientTemplate()
					.queryForObject("ChargebackSearch.getMinStepNumberWithInvoiceAmount", map);

		} catch (Exception e) {
			e.printStackTrace();
			log.error(e);
			throw new DataAccessException(e);
		}

		return minStep;
	}

	/**
	 * 
	 */
	public String getApproverStepsUpWithInvoiceAmount(String invoiceNumber, String locationNumber, String typeId,
			String stepNumber) throws DataAccessException {
		String nextStepNumber = null;

		try {

			HashMap<String, String> map = new HashMap<String, String>();
			map.put("invoiceNumber", invoiceNumber);
			map.put("locationNumber", locationNumber);
			map.put("typeId", typeId);
			map.put("stepNumber", stepNumber);

			nextStepNumber = (String) getSqlMapClientTemplate()
					.queryForObject("ChargebackSearch.getApproverStepsUpWithInvoiceAmount", map);

		} catch (Exception e) {
			throw new DataAccessException(e);
		}

		return nextStepNumber;
	}

	public String getApproverStepsUpWithmount(String typeId, String chargebackTotal, String stepNumber)
			throws DataAccessException {
		String nextStepNumber = null;

		try {

			HashMap<String, String> map = new HashMap<String, String>();
			map.put("chargebackTotal", chargebackTotal);
			map.put("typeId", typeId);
			map.put("stepNumber", stepNumber);

			nextStepNumber = (String) getSqlMapClientTemplate()
					.queryForObject("ChargebackSearch.getApproverStepsUpWithmount", map);

		} catch (Exception e) {
			throw new DataAccessException(e);
		}

		return nextStepNumber;
	}

	public String getApproverStepsDownWithmount(String typeId, String chargebackTotal, String stepNumber)
			throws DataAccessException {
		String nextStepNumber = null;

		try {

			HashMap<String, String> map = new HashMap<String, String>();
			map.put("chargebackTotal", chargebackTotal);
			map.put("typeId", typeId);
			map.put("stepNumber", stepNumber);

			nextStepNumber = (String) getSqlMapClientTemplate()
					.queryForObject("ChargebackSearch.getApproverStepsDownWithmount", map);

		} catch (Exception e) {
			throw new DataAccessException(e);
		}

		return nextStepNumber;
	}

	/**
	 * 
	 */
	public String getApproverStepsDownWithInvoiceAmount(String invoiceNumber, String locationNumber, String typeId,
			String stepNumber) throws DataAccessException {
		String nextStepNumber = null;

		try {

			HashMap<String, String> map = new HashMap<String, String>();
			map.put("invoiceNumber", invoiceNumber);
			map.put("locationNumber", locationNumber);
			map.put("typeId", typeId);
			map.put("stepNumber", stepNumber);

			nextStepNumber = (String) getSqlMapClientTemplate()
					.queryForObject("ChargebackSearch.getApproverStepsDownWithInvoiceAmount", map);

		} catch (Exception e) {
			throw new DataAccessException(e);
		}

		return nextStepNumber;
	}

	public ChargebackBO getChargebackDetailInfo(Map formSearchValuesMap) throws DataAccessException {
		ChargebackBO c = null;

		try {
			// HashMap map = new HashMap();
			// map.put("authCode", authCode);

			c = (ChargebackBO) getSqlMapClientTemplate().queryForObject("ChargebackSearch.getChargebackDetailInfo",
					formSearchValuesMap);

		} catch (Exception e) {
			log.error(e);
			throw new DataAccessException(e);
		}

		checkIfNull(c);
		return c;
	}

	@Override
	public String getRoleIdForNextApprover(String invoiceNumber, String typeId, String locationNumber, String userId)
			throws DataAccessException {

		String maxStep = null;
		try {

			HashMap<String, String> map = new HashMap<String, String>();
			map.put("invoiceNumber", invoiceNumber);
			map.put("userId", userId);
			map.put("locationNumber", locationNumber);
			map.put("typeId", typeId);

			maxStep = (String) getSqlMapClientTemplate().queryForObject("ChargebackSearch.getRoleIdForNextApprover",
					map);

		} catch (Exception e) {
			e.printStackTrace();
			log.error(e);
			throw new DataAccessException(e);
		}

		return maxStep;
	}
	
	@Override
	public void createCbkFundsRecord(ChargebackBO cbkBO) throws DataAccessException {
		try {

			System.out.println("---ChargebackSearchDaoImpl.java---createCbkFundsRecord()--");
			getSqlMapClientTemplate().insert("ChargebackSearch.insertFundsCbk", cbkBO);
		} catch (Exception e) {
			log.error(e);
			throw new DataAccessException(e);
		}

	}

	@Override
	public void createCbkItemFundsRecord(ChargebackBO cbkBO) throws DataAccessException {
		try {

			System.out.println("---ChargebackSearchDaoImpl.java---createCbkItemFundsRecord()--");
			getSqlMapClientTemplate().insert("ChargebackSearch.insertFundsCbkItem", cbkBO);
		} catch (Exception e) {
			log.error(e);
			throw new DataAccessException(e);
		}
	}

	@Override
	public void createCbkDistributionFundsRecord(ChargebackBO cbkBO) throws DataAccessException {
		try {

			System.out.println("---ChargebackSearchDaoImpl.java---createCbkDistributionFundsRecord()--");
			getSqlMapClientTemplate().insert("ChargebackSearch.insertFundsCbkDistribution", cbkBO);
		} catch (Exception e) {
			log.error(e);
			throw new DataAccessException(e);
		}
	}

	@Override
	public void createCbkApprFundsRecord(ChargebackBO cbkBO) throws DataAccessException {
		try {

			System.out.println("---ChargebackSearchDaoImpl.java---createCbkApprFundsRecord()--");
			getSqlMapClientTemplate().insert("ChargebackSearch.insertFundsApprovals", cbkBO);
		} catch (Exception e) {
			log.error(e);
			throw new DataAccessException(e);
		}
	}
	
	@Override
    public String getStepNumberForApproverByRoleid(String approverId) throws DataAccessException {

           String maxStepNumber = null;
           try {

                  maxStepNumber = (String) getSqlMapClientTemplate()
                               .queryForObject("ChargebackSearch.getStepNumberForApproverByRoleid", approverId);

           } catch (Exception e) {
                  e.printStackTrace();
                  log.error(e);
                  throw new DataAccessException(e);
           }

           return maxStepNumber;
    }
	
	@Override
	public String getValidateUserId(String userId) throws DataAccessException {
		String availableUserid = null;

		try {

			HashMap map = new HashMap();
			System.out.println("------in Impl--getValidateUserId--userId--"+userId);
			map.put("userId", userId);
			availableUserid = (String) getSqlMapClientTemplate().queryForObject("ChargebackSearch.getValidateUserId", map);

		} catch (Exception e) {
			log.error(e);
			throw new DataAccessException(e);
		}

		
		return availableUserid;

	}
	
	@Override
	public void getCancelChargeback(String  invoiceNumber) throws DataAccessException{
		String status =  null;
		try {
			System.out.println("--- update--in ChargebackSearchDaoImpl.java----getCancelChargeback()-----");
			getSqlMapClientTemplate().update("ChargebackSearch.getCancelChargeback", invoiceNumber);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Override
    public CreateNewUserBO getActiveUserDetails(String userId) throws DataAccessException {
           CreateNewUserBO c = null;

           try {

                  HashMap map = new HashMap();
                  System.out.println("------in Impl---getUserDetails()-----userId--"+userId);
                  map.put("userId", userId);
                  c = (CreateNewUserBO) getSqlMapClientTemplate().queryForObject("ChargebackSearch.getActiveUserDetails", map);

           } catch (Exception e) {
                  log.error(e);
                  throw new DataAccessException(e);
           }

           return c;

    }
	
	public List<ChargebackBO> getChargebackTypesForCreate() throws DataAccessException {

        List<ChargebackBO> l = null;
        try {
               l = (List) getSqlMapClientTemplate().queryForList("ChargebackSearch.getChargebackTypesForCreate");
        } catch (Exception e) {
               e.printStackTrace();
               log.error(e);
               throw new DataAccessException(e);
        }
        return l;
 }
	
	public ChargebackBO getVendorInfoByVendorId(String vendorId) throws DataAccessException {
		ChargebackBO c = null;

		try {
			
			HashMap map = new HashMap();
			map.put("vendorId", vendorId);
			c = (ChargebackBO) getSqlMapClientTemplate().queryForObject("ChargebackSearch.getVendorInfoByVendorId",
					map);

		} catch (Exception e) {
			log.error(e);
			throw new DataAccessException(e);
		}

		return c;
	}
	
	@Override
	public String getValidMaxAmount(String creatorId, Integer typeId) throws DataAccessException {
		String validMaxAmount = null;
		try {

			HashMap map = new HashMap();
			map.put("creatorId", creatorId);
			map.put("typeId", typeId);
			System.out.println("----getValidMaxAmount()----"+creatorId+" "+typeId);
			validMaxAmount = (String) getSqlMapClientTemplate().queryForObject("ChargebackSearch.getValidMaxAmount",
					map);

		} catch (Exception e) {
			e.printStackTrace();
			log.error(e);
			throw new DataAccessException(e);
		}

		return validMaxAmount;
	}



}