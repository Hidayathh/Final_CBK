package com.unfi.cbk.ui;

/**
 * @author yhp6y2l
 * @version 1.0 Jun 14, 2005
 */
public interface Pageable {
	public String getVcrAction();

	public String getVcrStart();

	public void setVcrAction(String string);

	public void setVcrStart(String string);

	public boolean isShowAll();
}
