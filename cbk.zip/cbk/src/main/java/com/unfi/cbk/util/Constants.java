/*
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.unfi.cbk.util;

/**
 * @author vpil001
 *
 *         To change the template for this generated type comment go to
 *         Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class Constants {

	// Constants for site minder request header
	public static final String ATTRIBUTE_SM_USER = "SM_USER";
	public static final String ATTRIBUTE_LDAPCN = "LDAPCN";
	public static final String ATTRIBUTE_SM_ROLE = "sm_role";
	public static final String ATTRIBUTE_USER_BEAN = "userBean";
	public static final String ATTRIBUTE_ENVIRONMENT_RESOURCES = "environmentResources";

	public static final String DEFAULT_USERID = "DEFAULT_USER_ID";
	public static final String DEFAULT_USER_NAME = "DEFAULT_USER_NAME";
	public static final String DEFAULT_ROLES = "DEFAULT_USER_ROLES";
	public static final String DEFAULT_USER_TYPE = "DEFAULT_USER_TYPE";

	public static final String EMPLOYEE_ROLE = "employee";
	public static final String BROKER_ROLE = "broker";
	public static final String MANUFACTURER_ROLE = "manufacturer";
	public static final String CARRIER_ROLE = "carrier";

	public static final String READONLY_ROLE = "readOnly";
	public static final String UPDATE_ROLE = "update";

	public static final String SV_ROLE = "SV";

	public static final String ADMIN_ROLE = "Admin";

	public static final String ACTION_OPEN = "open";
	public static final String ACTION_SUCCESS = "success";
	public static final String ACTION_DISPLAY = "display";
	public static final String ACTION_CANCEL = "cancel";
	public static final String ACTION_MODIFY_OPTIONS = "modify";
	public static final String ACTION_ADD = "add";
	public static final String ACTION_DELETE = "delete";
	public static final String ACTION_DONE = "done";
	public static final String ACTION_IMPORT = "import";
	public static final String ACTION_EDIT = "editPage";
	public static final String ACTION_FAILURE = "failure";
	public static final String ACTION_ERROR = "error";
	public static final Integer MAX_INVOICE = 999999;
	public static final Integer MAX_BARCODE = 9999999;
	public static final Integer MIN_BARCODE = 9900000;
	public static final String BARCODE_LOCATION_NO = "-1";

	public static final String LOCKBOX_DISTRIBUTION_ROW_LIMIT = "LockboxDistributionRowLimit";

	public static final String LOCKBOX_AUTO_COMMENT_REF_CODE_APPROVED = "Reference Code Approved";
	public static final String LOCKBOX_AUTO_COMMENT_UNAPPLIED = "Pass Returned to Unapplied Status";

	public static final String EXECUTE_TYPE_INSERT = "I";
	public static final String EXECUTE_TYPE_UPDATE = "U";
	public static final String EXECUTE_TYPE_SELECT = "S";
	public static final String EXECUTE_TYPE_INSERT_RETURNKEY = "K"; // Flag to indicate that common util will return a
																	// PK
	public static final String EXECUTE_TYPE_DELETE = "D";
	public static final String EXECUTE_TYPE_CHECK = "Q";

	public static final int STATUS_CANCEL = 1;
	public static final int STATUS_CLOSED = 2;
	public static final int STATUS_OPEN = 3;

	public static final int LOCKBOX_ATTACHMENT_NUMBER = 2;

	public static final int DTL_STATUS_REPAID = 1;
	public static final int DTL_STATUS_DENIED = 2;
	public static final int DTL_STATUS_ASSIGNED_TO = 3;
	public static final int DTL_STATUS_RETURN_TO_ASSIGNEE = 4;
	public static final int DTL_STATUS_WAITING_FOR_REQUESTER = 5;
	public static final int DTL_STATUS_SUBMITTED_FOR_PAYMENT = 6;
	public static final int DTL_STATUS_CANCEL = 7;
	public static final int DTL_STATUS_CLOSED = 8;
	public static final int DTL_STATUS_NO_REQ_RESPONSE = 9;
	public static final int DTL_STATUS_PENDING_APPROVAL = 10;
	public static final int DTL_STATUS_OPEN_APPROVED = 11;
	public static final int DTL_STATUS_CLOSED_APPROVED = 12;

	public static final String DTL_STATUS_RETURN_TO_REQ = "Return to Requester";
	public static final String DENY_PASS_RETURN_TO_REQ = "Denied - Returned to Preparer";

	public static final int REQUEST_TYPE_ADDL_BACKUP = 1;
	public static final int REQUEST_TYPE_DEDUCT_DISPUTE = 2;
	public static final int REQUEST_TYPE_DOC_FOUND = 3;
	public static final int REQUEST_TYPE_DOC_NOT_FOUND = 4;
	public static final int REQUEST_TYPE_PAID = 5;
	public static final int REQUEST_TYPE_PYMT_DISPUTE = 6;
	public static final int REQUEST_TYPE_PYMT_NOT_FOUND = 7;
	public static final int REQUEST_TYPE_SCHED_TO_BE_PAID = 8;
	public static final int REQUEST_TYPE_MISC_BILL_OF_LADING = 9;
	public static final int REQUEST_TYPE_MISC_CHECK_ISSUES = 10;
	public static final int REQUEST_TYPE_MISC_NEW_VENDOR = 11;
	public static final int REQUEST_TYPE_MISC_OTHER = 12;
	public static final int REQUEST_TYPE_CORR_EDI_CONTACT_CHANGE = 13;
	public static final int REQUEST_TYPE_VENDOR_NAME_REMIT_CHANGE = 14;

	public static final int REQUEST_SOURCE_PASS = 1;
	public static final int REQUEST_SOURCE_POSTAL = 2;
	public static final int REQUEST_SOURCE_FAX = 3;
	public static final int REQUEST_SOURCE_EMAIL = 4;
	public static final int REQUEST_SOURCE_PHONE = 5;

	public static final int ATTACH_TYPE_INVOICE = 1;
	public static final int ATTACH_TYPE_PROOFOFDELIVERY = 2;
	public static final int ATTACH_TYPE_OTHER = 3;
	public static final int ATTACH_TYPE_CHECKREMIT = 4;
	public static final int ATTACH_TYPE_RESOLUTION = 5;

	public static final int ROUTING_TYPE_ID_GROUP = 1;
	public static final int ROUTING_TYPE_ID_CLASSIFICATION = 2;
	public static final int ROUTING_TYPE_ID_CHARGEBACK_REQUESTER = 3;
	public static final int ROUTING_TYPE_ID_DOC_NUM_PREFIX = 4;
	public static final int ROUTING_TYPE_ID_LOCATION_GROUP = 5;

	public static final int ASSIGNED_GROUP_VENDOR_CORRESPONDENCE = 3444;
	public static final int ASSIGNED_GROUP_MERCH_AP = 2;
	public static final int ASSIGNED_GROUP_EXPENSE_AP = 866;
	public static final int ASSIGNED_GROUP_VENDOR_FIlE_SUPPORT = 4613;
	public static final int ASSIGNED_GROUP_VENDOR_FIlE_SUPPORT2 = 4853;
	public static final int ASSIGNED_GROUP_VENDOR_FILE_DATA_ENTRY = 5097;

	public static final String AUDIT_TYPE_CHANGE_STATUS_CODE = "154";
	public static final String LOCKBOX_AUDIT_TYPE_RETURN_TO_UNAPPLIED = "163";

	public static final int AUDIT_TYPE_CHANGE_STATUS = 1;
	public static final int AUDIT_TYPE_CREATED = 2;
	public static final int AUDIT_TYPE_REASSIGN = 3;
	public static final int AUDIT_TYPE_UPDATE = 4;
	public static final int AUDIT_TYPE_REMINDER_EMAIL_TO_ASSIGNEE = 5;
	public static final int AUDIT_TYPE_AUTO_CLOSE_NO_REQUESTER_RESPONSE = 6;
	public static final int AUDIT_TYPE_AUTO_CLOSE_WHEN_CREATED = 7;
	public static final int AUDIT_TYPE_AUTO_CLOSE_ROUTE_OUTSIDE_EPASS = 8;
	public static final int AUDIT_TYPE_REQUEST_TYPE_CHANGED = 9;

	public static final String AUDIT_COMMENT_CREATED = "PASS Created and Assigned to ";
	public static final String AUDIT_COMMENT_REASSIGNED = "PASS Reassigned to ";
	public static final String AUDIT_COMMENT_UPDATED = "PASS Updated.";
	public static final String AUDIT_COMMENT_STATUS_CHANGED = "PASS Status Changed to ";
	public static final String AUDIT_COMMENT_REMINDER_EMAIL_TO_ASSIGNEE = "PASS Reminder Email Sent to Assignee.";
	public static final String AUDIT_COMMENT_AUTO_CLOSE_NO_REQUESTER_RESPONSE = "PASS Automatically Closed. No response from Requester.";
	public static final String AUDIT_COMMENT_AUTO_CLOSE_WHEN_CREATED = "PASS Closed when Created.";
	public static final String AUDIT_COMMENT_AUTO_CLOSE_ROUTE_OUTSIDE_EPASS = "PASS Automatically Closed and Routed outside ePASS.";
	public static final String AUDIT_COMMENT_REQUEST_TYPE_CHANGED = "PASS Request Type Changed to ";

	public static final String AUTO_COMMENT_W9_NOT_RECEIVED = "Waiting for W9 form.";
	public static final String AUTO_COMMENT_W9_RECIEVED = "Received W9 form.";
	public static final String AUTO_COMMENT_NOTARY_NOT_RECEIVED = "Waiting for SUPERVALU Vendor Name/Remit Address Change Authorization form.";
	public static final String AUTO_COMMENT_NOTARY_RECEIVED = "Received SUPERVALU Vendor Name/Remit Address Change Authorization form.";

	public final static String AUTHORITY_CODE_ASSURANCE_AUDIT = "PRG,CON";
	public final static String AUTHORITY_CODE_PROMOTIONS = "PRM";

	/** Routing types for assigning PASS#s */
	public static final Integer[] ROUTING_TYPES_ASSIGN = { new Integer(ROUTING_TYPE_ID_GROUP),
			new Integer(ROUTING_TYPE_ID_CLASSIFICATION), new Integer(ROUTING_TYPE_ID_CHARGEBACK_REQUESTER),
			new Integer(ROUTING_TYPE_ID_DOC_NUM_PREFIX) };
	/** Routing types for approving PASS#s for repayment */
	public static final Integer[] ROUTING_TYPES_REPAY = { new Integer(ROUTING_TYPE_ID_GROUP),
			new Integer(ROUTING_TYPE_ID_LOCATION_GROUP) };

	public static final int MAX_ATTACHMENT_SIZE_BYTES = 5 * 1024 * 1024;

	public static final String NO_CHANGE_MERSSAGE = "No New Change";

	public static final String W9_LINK = "http://www.irs.gov/pub/irs-pdf/fw9.pdf";
	public static final String BOTH_FORMS_NOT_RECEIVED_TEXT = "copies of the W-9 (" + W9_LINK
			+ ") and original notarization forms";
	public static final String W9_NOT_RECEIVED_TEXT = "a copy of the W-9 form (" + W9_LINK + ")";
	public static final String NOTARY_FORM_NOT_RECEIVED_TEXT = "a copy of the original notarization form";
	public final static String IT_EMAIL_GROUP = "itgroup.email.address";
	// Report Distribution Codes
	public final static String AXS_ONE_GL_ACCOUNT = "201";
	public final static String ORACLE_GL_ACCOUNT = "203";
	public final static String ORACLE_CLAIM = "204";
	// charge back
	public final static String CHARGE_BACK = "202";
	// cash applied_group
	public final static String CASH_APPLIED_GROUP_CD = "124";

	public final static int MAX_ROW = 20;
	public static final String MSG_ERROR = "key_error";
	public static final String MSG_INFO = "key_info";
	public static final String MSG_WARN = "key_warn";

}
