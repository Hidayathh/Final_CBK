package com.unfi.cbk.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.unfi.cbk.beans.UserDataBean;
import com.unfi.cbk.dao.ChargebackCommonDao;
import com.unfi.cbk.forms.OriginatorSelectorForm;
import com.unfi.cbk.util.ActionMessages;
import com.unfi.cbk.util.ActionUrlMapping;
import com.unfi.cbk.util.Constants;

/**
 * The action method that will be called is automatically determined based upon
 * the value of the parameter that is passed in.
 * <p>
 * The action method will then sets the user data in the request, sets any
 * values needed, and forwards to the appropriate action mapping.
 *
 * @author vpil001
 * @version 1.0
 */
@Controller
public class OriginatorSelectorController {
	static Logger log = Logger.getLogger(OriginatorSelectorController.class);
	private ChargebackCommonDao chargebackCommonDao;

	public OriginatorSelectorController(@Autowired ChargebackCommonDao dao) {
		this.chargebackCommonDao = dao;
	}

	@Autowired
	ActionMessages errors;

	/**
	 * The open() method displays the Vendor Selector pop up.
	 * 
	 * @param mapping  The ActionMapping used to select this instance
	 * @param form     The ActionForm bean for this request
	 * @param request  The HTTP request we are processing
	 * @param response The HTTP response we are creating
	 * @return an ActionForward instance describing where and how control should be
	 *         forwarded, or null if the response has already been completed.
	 * @throws Exception if an exception occurs
	 */
	@RequestMapping(value = "/originatorSelector", method = { RequestMethod.GET, RequestMethod.POST }, params = {
			"action=open" })
	public ModelAndView open(@ModelAttribute OriginatorSelectorForm originatorSelectorForm, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		ModelAndView mav = new ModelAndView();
		boolean exceptionOccurred = false;

		try {
			log.debug("***** ORIGINATOR SELECTOR OPEN *****");


		} catch (Exception e) {
			exceptionOccurred = true;
			mav.setViewName(ActionUrlMapping.GLOBAL.get(Constants.ACTION_FAILURE));
			log.error("Exception in execute:" + e);

			if (errors.isEmpty()) {
				errors.add("error", "errors.general");
			}
		}

		if (!exceptionOccurred) {
			mav.setViewName(ActionUrlMapping.ORIGINATORSELECTORACTIONS.get("open"));
		}

		// If a message is required, save the specified key(s) into the request.
		if (!errors.isEmpty()) {
			log.debug("FAILED");
			mav.setViewName(ActionUrlMapping.GLOBAL.get(Constants.ACTION_FAILURE));
		}

		request.setAttribute("actionMessages", errors);
		request.setAttribute("originatorSelectorForm", originatorSelectorForm);
		return mav;
	}

	/**
	 * The search() method get the values from the database.
	 * 
	 * @param mapping  The ActionMapping used to select this instance
	 * @param form     The ActionForm bean for this request
	 * @param request  The HTTP request we are processing
	 * @param response The HTTP response we are creating
	 * @return an ActionForward instance describing where and how control should be
	 *         forwarded, or null if the response has already been completed.
	 * @throws Exception if an exception occurs
	 */
	@RequestMapping(value = "/originatorSelector", method = { RequestMethod.GET, RequestMethod.POST }, params = {
			"action=search" })
	public ModelAndView search(@ModelAttribute OriginatorSelectorForm originatorSelectorForm,
			HttpServletRequest request, HttpServletResponse response) throws Exception {
		ModelAndView mav = new ModelAndView();
		ActionMessages errors = new ActionMessages();
		boolean exceptionOccurred = false;

		try {
			log.info("***** ORIGINATOR SELECTOR SEARCH *****");

			UserDataBean userBean = new UserDataBean(request);
			// Get the list of vendors and put them into the bean for the JSP page
			List searchResults = chargebackCommonDao.doOriginatorSearch(originatorSelectorForm.getUserId(),
					originatorSelectorForm.getUserName());
			originatorSelectorForm.setSearchResults(searchResults);
			originatorSelectorForm.setResults(new Integer(searchResults.size()));
		} catch (Exception e) {
			exceptionOccurred = true;
			e.printStackTrace();
			mav.setViewName(ActionUrlMapping.GLOBAL.get(Constants.ACTION_FAILURE));
			log.error("Exception in execute:" + e);
			// Only add the general error if no other errors are present
			if (errors.isEmpty()) {
				errors.add("error", "errors.general");
			}
		}

		if (!exceptionOccurred) {
			// forward = mapping.findForward("open");
			mav.setViewName(ActionUrlMapping.ORIGINATORSELECTORACTIONS.get("open"));
		}

		// If a message is required, save the specified key(s) into the request.
		if (!errors.isEmpty()) {
			log.debug("FAILED");
			mav.setViewName(ActionUrlMapping.GLOBAL.get(Constants.ACTION_FAILURE));
		}

		// Finish with
		// return (forward);
		request.setAttribute("actionMessages", errors);
		request.setAttribute("originatorSelectorForm", originatorSelectorForm);
		return mav;
	}
}
