package com.unfi.cbk.delegates;

import java.util.Map;

import com.unfi.cbk.beans.ResultList;
import com.unfi.cbk.dao.UserSearchResultDao;
import com.unfi.cbk.exceptions.DataAccessException;

public class UserSearchResultDeligate {

	private UserSearchResultDao userSearchResultDao;

	public UserSearchResultDeligate(UserSearchResultDao userSearchResultDao) {
		this.userSearchResultDao = userSearchResultDao;
	}

	public ResultList allUsers(Map map) throws DataAccessException {
		ResultList rL = userSearchResultDao.allUsers(map);
		return rL;
	}
	
	public ResultList specificUserResults(Map map) throws DataAccessException {
		ResultList rL = userSearchResultDao.specificUserResults(map);
		return rL;
	}
	
	public ResultList specificUserSearch(Map map) throws DataAccessException {
		ResultList rL = userSearchResultDao.specificUserSearch(map);
		return rL;
	}
	
	public ResultList specificRoleIdSearch(Map map) throws DataAccessException {
		ResultList rL = userSearchResultDao.specificRoleIdSearch(map);
		return rL;
	}
	
	public ResultList userResultsByRole(Map map) throws DataAccessException {
		ResultList rL = userSearchResultDao.userResultsByRole(map);
		return rL;
	}

	public ResultList userResultsByUser(Map map) throws DataAccessException {
		ResultList rL = userSearchResultDao.userResultsByUser(map);
		return rL;
	}

	public ResultList userResultsByLocation(Map map) throws DataAccessException {
		ResultList rL = userSearchResultDao.userResultsByLocation(map);
		return rL;
	}

}
