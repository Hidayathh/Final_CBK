package com.unfi.cbk.controller.chargeback;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.servlet.ModelAndView;

import com.unfi.cbk.beans.ResultList;
import com.unfi.cbk.bo.ChargebackBO;
import com.unfi.cbk.bo.CreateNewUserBO;
import com.unfi.cbk.controller.PageAccessResolver;
import com.unfi.cbk.delegates.ChargebackSearchDelegate;
import com.unfi.cbk.forms.MassApprovalsForm;
import com.unfi.cbk.util.ActionMessages;
import com.unfi.cbk.util.ActionUrlMapping;
import com.unfi.cbk.util.Constants;
import com.unfi.cbk.util.DateFunctions;
import com.unfi.cbk.util.ESAPIUtil;
import com.unfi.cbk.util.StringFunctions;
import com.unfi.cbk.utilcore.ApplicationProperties;
import com.unfi.cbk.email.ChargebackMailer;

/**
 * The MassApprovalsController class is the struts action called for the search criteria
 * entry page. The action sets the user data in the request, sets any values
 * needed for the form, and forwards to the JSP specific to the userType.
 *
 * @author vpil001
 * @since 1.0
 */
@Controller("massApprovalsAction_massApprovals")
@Scope(value = WebApplicationContext.SCOPE_REQUEST, proxyMode = ScopedProxyMode.TARGET_CLASS)
public class MassApprovalsController {// extends Action {
	static Logger log = Logger.getLogger(MassApprovalsController.class);
	@Autowired
	ActionMessages errors;
	@Autowired
	private ChargebackSearchDelegate chargebackSearchDelegate;
	@Autowired
	ActionMessages messages;
	@Autowired
	Environment env;
	@Autowired
    private ChargebackMailer chargebackMailer;
	// Externalize this value
	@Value("${cbk.autoGrowCollectionLimit:100000}")
	private int autoGrowCollectionLimit;
	private static String TEST_EMAIL = ApplicationProperties.getDummyEMail();
	@InitBinder
	public void initBinder(WebDataBinder dataBinder) {
		dataBinder.setAutoGrowCollectionLimit(autoGrowCollectionLimit);
	}

	/**
	 * 
	 * @param massApprovalsForm
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/massApprovalsSearch", method = { RequestMethod.GET, RequestMethod.POST })
	public ModelAndView execute(@ModelAttribute("massApprovalsForm") MassApprovalsForm massApprovalsForm,
			HttpServletRequest request, HttpServletResponse response) throws Exception {
		System.out.println("***** MASS APPROVAL SEARCH *****-massApprovalSearch-- execute()---");
		ModelAndView mav = new ModelAndView();
		massApprovalsForm.setFormParameterMap(request);
		
		HttpSession session = request.getSession();
        String SmUserId = (String) session.getAttribute("SmUserId");
        
		Map<String, Comparable> searchParametersFromForm = massApprovalsForm.getMap();
		System.out.println("MASS APPROVALS - SEARCH--isformreset--"+request.getParameter("isformreset"));
		
		
		if (request.getParameter("isformreset") != null) {
			//massApprovalsForm.reset(request);
			System.out.println("--resetForm-----");
			massApprovalsForm.resetForm(massApprovalsForm);
			massApprovalsForm.setFromDate("");
			massApprovalsForm.setToDate("");
		}
		log.debug("***** MASS APPROVAL SEARCH*****massApprovalsSearch");
		
		
		// GET THE APPROVAL LIMIT AMOUNT FOR THE USER. 
		searchParametersFromForm.put("userId", SmUserId);
		
		ResultList searchResults =  chargebackSearchDelegate.getRoleIdRouteIdForUser(searchParametersFromForm);
		String floorAmount = null;
		String roleId = null;
		List  l = searchResults.getList();
		for(int i=0; i<l.size(); i++)
		{
			ChargebackBO cbo = new ChargebackBO();
			cbo = (ChargebackBO)l.get(i);
			if(cbo.getRoleId() != null && cbo.getRouteId() != null && cbo.getFloorAmount() !=null)// Double.parseDouble(approvalLimit)))
			{
				System.out.println("------- roleId, RouteId--" + cbo.getRoleId()+"--"+cbo.getRouteId());
				searchParametersFromForm.put("roleId", cbo.getRoleId());
				roleId = cbo.getRoleId().toString();
				searchParametersFromForm.put("routeId", cbo.getRouteId());
				floorAmount = cbo.getFloorAmount().toString();
			}
		}
		String approvalLimit = null;
		if(roleId !=null)// Double.parseDouble(approvalLimit)))
		{
			  approvalLimit = chargebackSearchDelegate.getApprovalLimitForUser(searchParametersFromForm);
		}
		if(approvalLimit != null && !("").equals(approvalLimit)) {
			massApprovalsForm.setUserApprovalLimit(Double.parseDouble(approvalLimit));
		}
		
		System.out.println("-------approvalLimit--for user----"+SmUserId+"---"+approvalLimit);
		massApprovalsForm.setAmountFrom("0");
		if(approvalLimit==null)
			massApprovalsForm.setAmountTo("5000000");
		else
			massApprovalsForm.setAmountTo(approvalLimit);
		// END
		
		
		mav.setViewName(ActionUrlMapping.MASSAPPROVALSACTIONS.get(Constants.ACTION_SUCCESS));
		System.out.println("URL mapping~~~~~~~~~" + mav.getViewName());
		request.setAttribute("actionMessages", errors);
		System.out.println("FromDate~~~~~~~~"+massApprovalsForm.getFromDate());
		request.setAttribute("massApprovalsForm", massApprovalsForm);
		
		return mav;

	}

	@RequestMapping(value = "/getMassApprovalResults", method = { RequestMethod.GET, RequestMethod.POST }, params = {
			"action=massApprovalResults" })
	public ModelAndView massApprovalResults(@ModelAttribute("massApprovalsForm") MassApprovalsForm massApprovalsForm,
			HttpServletRequest request) throws Exception {
		ModelAndView mav = new ModelAndView();
		log.debug("***** MASS APPROVALS RESULTS *****");
		massApprovalsForm.setFormParameterMap(request);
		// **** Exceptions handled by global exception handlers ****
		String dateCriteria = request.getParameter("dateCriteria");
		HttpSession session = request.getSession();
        String SmUserId = (String) session.getAttribute("SmUserId");
        String amount = massApprovalsForm.getAmountTo();
		System.out.println("MASS APPROVALS - RESULTS...SmUserId....." + SmUserId);
		
		Map<String, Comparable> searchParametersFromForm = massApprovalsForm.getMap();
		searchParametersFromForm.put("userId", SmUserId);
		
		if (massApprovalsForm.getLocationNumber() != null) {

			String idPattern = "[\\s0-9,. ]*";
			boolean specialCharFlag = validateSpecialCharacters(massApprovalsForm.getLocationNumber().toString(),
					idPattern);
			if (specialCharFlag == true) {
				messages.add("locationNumber", "errors.validateLocation", null);
			}
		}

		if (messages.isEmpty()) {
			System.out.println("--------validation start ----");
			searchParametersFromForm.put("originator", massApprovalsForm.getOriginator());
			searchParametersFromForm.put("approver", massApprovalsForm.getApprover());
			searchParametersFromForm.put("vendorId", massApprovalsForm.getVendorId());
			
			if (!massApprovalsForm.getLocationNumber().isEmpty()
					&& massApprovalsForm.getLocationNumber() != null) {
				String location = massApprovalsForm.getLocationNumber().substring(0, 2);
				searchParametersFromForm.put("location", location);
			} else {
				searchParametersFromForm.put("location", "");
			}
			searchParametersFromForm.put("locationNumber", massApprovalsForm.getLocationNumber());

			searchParametersFromForm.put("invoiceFrom", massApprovalsForm.getInvoiceFrom());
			searchParametersFromForm.put("invoiceTo", massApprovalsForm.getInvoiceTo());
			if (massApprovalsForm.getInvoiceTo() == null || massApprovalsForm.getInvoiceTo().isEmpty()) {
				searchParametersFromForm.put("invoiceTo", massApprovalsForm.getInvoiceFrom());
				System.out.println("invoice to  is null" + massApprovalsForm.getInvoiceFrom());
			}

			searchParametersFromForm.put("amountFrom", massApprovalsForm.getAmountFrom());
			searchParametersFromForm.put("amountTo", massApprovalsForm.getAmountTo());
			searchParametersFromForm.put("dateCriteria", dateCriteria);
			searchParametersFromForm.put("type", massApprovalsForm.getType());
			searchParametersFromForm.put("fromDate", massApprovalsForm.getFromDate());
			searchParametersFromForm.put("toDate", massApprovalsForm.getToDate());

			System.out.println("--FROM DATE--" + searchParametersFromForm.get("fromDate"));
			System.out.println("--TO DATE--" + searchParametersFromForm.get("toDate"));
			/*
			 * System.out.println("--STATUS--" + massApprovalsForm.getStatus());
			 * System.out.println("--APSTATUS--" + massApprovalsForm.getAPStatus());
			 * System.out.println("--TYPE--" + massApprovalsForm.getType());
			 * 
			 * searchParametersFromForm.put("notFinal", true); // notFinal IS NULL
			 * searchParametersFromForm.put("active", true); // Active is NULL
			 * searchParametersFromForm.put("type",7); // Type - Imported Chbk
			 */

			if (massApprovalsForm.getLocationNumber() != null && !massApprovalsForm.getLocationNumber().isEmpty()) {
				ResultList locationValidatorResult = chargebackSearchDelegate
						.locationNumberValidator(searchParametersFromForm);
				System.out.println("-------------AFTER QEURY------locationvalidator--size----------"
						+ locationValidatorResult.getList().size());
				if (locationValidatorResult.getList().size() == 0) {
					messages.add("locationNumber", "errors.InvalidLocationNumber", null);
				}
			}
			
			if (massApprovalsForm.getVendorId() != null && !massApprovalsForm.getVendorId().isEmpty()) { 
				String vendorId = StringFunctions.spaceFillLeft(massApprovalsForm.getVendorId(),9,true);
				System.out.println("----VENDOR SELECTOR SEARCH---vendorId---"+vendorId);
				ResultList vendorValidatorResult = chargebackSearchDelegate.vendorNumberValidator(vendorId); 
				  System.out.println("-------------AFTER QEURY------vendorValidatorResult--size----------" + vendorValidatorResult.getList().size()); 
				  if (vendorValidatorResult.getList().size() == 0) { 
					  messages.add("vendorId", "errors.InvalidVendorNumber", null); 
			      }
			}
			 

			if (massApprovalsForm.getOriginator() != null && !massApprovalsForm.getOriginator().isEmpty()) {
				ResultList originatorValidatorResult = chargebackSearchDelegate
						.originatorValidator(searchParametersFromForm);
				System.out.println("-------------AFTER QEURY------originatorValidatorResult--size----------"
						+ originatorValidatorResult.getList().size());
				if (originatorValidatorResult.getList().size() == 0) {
					messages.add("originator", "errors.InvalidOriginator", null);
				}
			}

			if (massApprovalsForm.getApprover() != null && !massApprovalsForm.getApprover().isEmpty()) {
				ResultList approverValidatorResult = chargebackSearchDelegate
						.nextApproverValidator(searchParametersFromForm);
				System.out.println("-------------AFTER QEURY------approverValidatorResult--size----------"
						+ approverValidatorResult.getList().size());
				if (approverValidatorResult.getList().size() == 0) {
					messages.add("approver", "errors.InvalidApprover", null);
				}
			}
		}

		massApprovalsForm.validate(request, messages);

		System.out.println("-- FROM DATE--" + searchParametersFromForm.get("fromDate"));
		System.out.println("--TO DATE--" + searchParametersFromForm.get("toDate"));
		
		// GET THE APPROVAL LIMIT AMOUNT FOR THE USER. 
		
		ResultList searchResults =  chargebackSearchDelegate.getRoleIdRouteIdForUser(searchParametersFromForm);
		String floorAmount = null;
		String roleId = null;
		List  l = searchResults.getList();
		for(int i=0; i<l.size(); i++)
		{
			ChargebackBO cbo = new ChargebackBO();
			cbo = (ChargebackBO)l.get(i);
			if(cbo.getRoleId() != null && cbo.getRouteId() != null && cbo.getFloorAmount() !=null)// Double.parseDouble(approvalLimit)))
			{
				System.out.println("----- roleId, RouteId--" + cbo.getRoleId()+"--"+cbo.getRouteId());
				searchParametersFromForm.put("roleId", cbo.getRoleId());
				roleId = cbo.getRoleId().toString();
				searchParametersFromForm.put("routeId", cbo.getRouteId());
				floorAmount = cbo.getFloorAmount().toString();
			}
		}
		String approvalLimit = null;
		if(roleId !=null)// Double.parseDouble(approvalLimit)))
		{
			 approvalLimit = chargebackSearchDelegate.getApprovalLimitForUser(searchParametersFromForm);
		}
		
		if(approvalLimit != null && !("").equals(approvalLimit)) {
			massApprovalsForm.setUserApprovalLimit(Double.parseDouble(approvalLimit));
		}
		else {
			massApprovalsForm.setUserApprovalLimit(5000000.00);
			approvalLimit ="5000000.00";
		}
			
			System.out.println("-------approvalLimit--for user in massApprovalResults()----"+SmUserId+"---"+approvalLimit);
		
			String typeId ="7";
			String maxStepNumber = chargebackSearchDelegate.getMaxStepNumber(typeId); // Need to review if still issue exists.
			//String maxStepNumber = chargebackSearchDelegate.getStepNumberForMassApproval(typeId, roleId);
			massApprovalsForm.setMaxStepNumber(maxStepNumber);
			System.out.println("-------maxstepNumber --for user in massApprovalResults()-------"+maxStepNumber);
			// Mass approvals chargebacks List
			//Validation for Floor Amount
			ResultList searchResults1 = chargebackSearchDelegate.getMassApprovalsList(searchParametersFromForm);
			//System.out.println("-------getMassApprovals()------searchResults--size-------" + searchResults.getList().size());
			List  li = searchResults1.getList();
			for(int i=0; i<li.size(); i++)
			{
				ChargebackBO cbo = new ChargebackBO();
				cbo = (ChargebackBO)li.get(i);
				//System.out.println("------cbo.getMassAppNetAmount() --"+cbo.getMassAppNetAmount()+":::approvalLimit-------" + approvalLimit);
				if(cbo.getMassAppNetAmount() != null && (cbo.getMassAppNetAmount() > Double.parseDouble(approvalLimit)))
				{
					//System.out.println("-------exceeds ApprovalLimit---" + Integer.parseInt(cbo.getNetAmount())+"--"+Integer.parseInt(massApprovalsForm.getAmountTo()));
					massApprovalsForm.setFlagValue("true");
					break;
				}
			}
			
			massApprovalsForm.setLocationNumber(massApprovalsForm.getLocationNumber());
			massApprovalsForm.setAmountTo(amount);
			// Populate the 'searchResults' property in the ActionForm
			massApprovalsForm.setSearchResults(searchResults1.getList());
			// massApprovalsForm.setTotalRecords(searchResults.getTotalCount().intValue());
			if (!messages.isEmpty()) {

				List chargebackTypes = chargebackSearchDelegate.getChargebackTypes();
				massApprovalsForm.setChargebackTypes(chargebackTypes);
				request.setAttribute("actionMessages", messages);
				messages.saveMessages(request);
				mav.setViewName(ActionUrlMapping.MASSAPPROVALSACTIONS.get(Constants.ACTION_SUCCESS));
				request.setAttribute("massApprovalsForm", massApprovalsForm);
				return mav;
			}	

		messages.saveMessages(request);
		//System.out.println("-------getMassApprovals()------setUserApprovalLimit------" + massApprovalsForm.getUserApprovalLimit());
		PageAccessResolver resolver = new PageAccessResolver(request);
		if (resolver.hasAccess()) {
			mav.setViewName(ActionUrlMapping.MASSAPPROVALSACTIONS.get("results"));
			System.out.println("URL mapping----" + mav.getViewName());
			request.setAttribute("actionMessages", messages);
			request.setAttribute("massApprovalsForm", massApprovalsForm);
			return mav;
		}
		mav.setViewName(ActionUrlMapping.MASSAPPROVALSACTIONS.get("other"));
		request.setAttribute("actionMessages", messages);
		request.setAttribute("massApprovalsForm", massApprovalsForm);
		return mav;
	}

	/**
	 * 
	 * @param massApprovalsForm
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */

	@RequestMapping(value = "/massApproveChargebacks", method = { RequestMethod.GET, RequestMethod.POST }, params = {
			"action=massApprove" })
	public ModelAndView massApprove(@ModelAttribute("massApprovalsForm") MassApprovalsForm massApprovalsForm,
			HttpServletRequest request, HttpServletResponse response) throws Exception {
		massApprovalsForm.setFormParameterMap(request);
		ModelAndView mav = new ModelAndView();
		log.debug("***** SELECTED CHARGEBACKS MASS APPROVE ****massApprove()****");
		Map<String, Comparable> searchParametersFromForm = massApprovalsForm.getMap();
		try {
		
		    

			HttpSession session = request.getSession();
			String SmUserId = (String) session.getAttribute("SmUserId");
			String nextApproverId = null;
			
			String stepNumber = null;
			String invoiceCount  =  null;
			System.out.println("------invoiceCount-----"+request.getParameter("invoiceCount"));
			
			//if(!request.getParameter("invoiceCount").equals("null"))
			if (!("null").equals(request.getParameter("invoiceCount"))  && request.getParameter("invoiceCount") != "null") 
			{
				invoiceCount = request.getParameter("invoiceCount");
			}
			
			System.out.println("------request.getParameter(approverId)-----"+request.getParameter("approverId"));
			System.out.println("------request.getParameter(stepNumber)-----"+request.getParameter("stepNumber"));
			//if(!request.getParameter("approverId").equals("null"))
			if (!("null").equals(request.getParameter("approverId"))) 
			{
				nextApproverId = request.getParameter("approverId");
				//nextApprId = request.getParameter("approverId");
			}
			else 
			{ 
				nextApproverId ="No further approvals"; 
				//nextApprId = request.getParameter("approverId");
			}
			
			System.out.println("------nextApproverId-----"+nextApproverId);
			
			stepNumber = chargebackSearchDelegate.getStepNumberForApproverByRoleid(SmUserId);
			/*
			 * else { stepNumber = request.getParameter("maxStepNumber"); }
			 */
			System.out.println("---current stepNumber for user-----"+stepNumber);
			
			String maxStepNumber = request.getParameter("maxStepNumber");
			System.out.println("---maxStepNumber -----"+maxStepNumber);
			if (maxStepNumber != null && maxStepNumber.equals(stepNumber)  ) {
                log.debug("---Reached Max StepNumber-----");
                nextApproverId = "No further approvals";
            }
		
			// GET THE APPROVAL LIMIT AMOUNT FOR THE USER. 
						searchParametersFromForm.put("userId", SmUserId);
						
						ResultList searchResults =  chargebackSearchDelegate.getRoleIdRouteIdForUser(searchParametersFromForm);
						String floorAmount = null;
						String roleId = null;
						List  l = searchResults.getList();
						for(int i=0; i<l.size(); i++)
						{
							ChargebackBO cbo = new ChargebackBO();
							cbo = (ChargebackBO)l.get(i);
							if(cbo.getRoleId() != null && cbo.getRouteId() != null && cbo.getFloorAmount() !=null)// Double.parseDouble(approvalLimit)))
							{
								System.out.println("------- roleId, RouteId--" + cbo.getRoleId()+"--"+cbo.getRouteId());
								searchParametersFromForm.put("roleId", cbo.getRoleId());
								roleId = cbo.getRoleId().toString();
								searchParametersFromForm.put("routeId", cbo.getRouteId());
								floorAmount = cbo.getFloorAmount().toString();
							}
						}
						String approvalLimit = null;
						if(roleId !=null)// Double.parseDouble(approvalLimit)))
						{
						  approvalLimit = chargebackSearchDelegate.getApprovalLimitForUser(searchParametersFromForm);
						}
						massApprovalsForm.setAmountFrom("0");
						if(approvalLimit != null && !("").equals(approvalLimit)) {
							massApprovalsForm.setUserApprovalLimit(Double.parseDouble(approvalLimit));
						}
						
						if(approvalLimit != null && !("").equals(approvalLimit)) {
							massApprovalsForm.setUserApprovalLimit(Double.parseDouble(approvalLimit));
						}
						else {
							massApprovalsForm.setAmountTo("5000000");
						}
						
						//System.out.println("-------approvalLimit--for user----"+SmUserId+"---"+approvalLimit);
						massApprovalsForm.setAmountFrom("0");
						if(approvalLimit==null)
							massApprovalsForm.setAmountTo("5000000");
						else
							massApprovalsForm.setAmountTo(approvalLimit);
						System.out.println("-------approvalLimit--for user----"+SmUserId+"---"+approvalLimit);
						
						// END
						
			List selectedInvoices = Arrays.asList(massApprovalsForm.getChargebackSelections());
			System.out.println("-------selectedInvoices- size-----" + selectedInvoices.size());
						
			List<ChargebackBO> massApprovalList = new ArrayList<ChargebackBO>();
			ChargebackBO cbkBo = null;
			int count =0;
			Double singleInvoiceAmt = 0.00;
			Double finalTotal = 0.00;
			if("1".equals(invoiceCount)) {
				
				cbkBo = new ChargebackBO();
					String nextApprId = null;	
					cbkBo.setInvoiceNumber(selectedInvoices.get(0).toString());
					cbkBo.setVendorId(selectedInvoices.get(1).toString());
					cbkBo.setLocationNumber(selectedInvoices.get(2).toString());
					singleInvoiceAmt = Double.parseDouble(selectedInvoices.get(5).toString());
					//massAppNetAmount  5
					System.out.println("---IF--nextApproverId-----"+nextApproverId);
					if( singleInvoiceAmt <= Double.parseDouble(approvalLimit)  && nextApproverId.equalsIgnoreCase("No further approvals")) //Normal Case < floorAmt - No popup
					{
						nextApprId = "No further approvals";
						finalTotal  =  finalTotal + singleInvoiceAmt;
						count = count + 1;
					}//pop selected
					if(singleInvoiceAmt > Double.parseDouble(approvalLimit)  && !nextApproverId.equalsIgnoreCase("No further approvals")) //Normal Case > floorAmt - Popup selected
					{
						nextApprId = nextApproverId;
						finalTotal  =  finalTotal + singleInvoiceAmt;
						count = count + 1;
					}
					//2 records checked - 1 < and 1 > flooramount with popup selected
					if( singleInvoiceAmt <= Double.parseDouble(approvalLimit) && !nextApproverId.equalsIgnoreCase("No further approvals")) //Normal Case < and  > floorAmt -  popup selected
					{
						nextApprId = "No further approvals";
						finalTotal  =  finalTotal + singleInvoiceAmt;
						count = count + 1;
					}
					
					//2 records checked- 1 < and 1 > flooramount with  no popup selected
					if( singleInvoiceAmt > Double.parseDouble(approvalLimit) && nextApproverId.equalsIgnoreCase("No further approvals")) //Normal Case < and  > floorAmt -  popup selected
					{
						nextApprId = null;
						//finalTotal  =  finalTotal + singleInvoiceAmt;
						//count = count + 1;
					}
					
					cbkBo.setApproverId(SmUserId);
					cbkBo.setStepNumber(stepNumber);
					//cbkBo.setApprovalDate(new Date());
					cbkBo.setApprovalDate(DateFunctions.adjustCurrentDateByDaysNoFormat(0));
					cbkBo.setNextAproverId(nextApprId);
					massApprovalList.add(cbkBo);
			}
			else
			{
				Iterator i = selectedInvoices.iterator();
				System.out.println("---ELSE---nextApproverId-----"+nextApproverId);
				while (i.hasNext()) {
					cbkBo = new ChargebackBO();
					String nextApprId = null;
					String rowSelected = i.next().toString();
					System.out.println("-------invoice- Selected-----" + rowSelected);
					String[] row = rowSelected.split(",");
					//value="<c:out value="${chargeback.invoiceNumber},${chargeback.vendorId},${chargeback.locationNumber},
					//${chargeback.originalApprover},${chargeback.stepNumber},${chargeback.netAmount},${chargeback.typeId}"/>">
					//-------invoice- Selected-----44407160,0035691,44041,,,60,
					//-------invoice- Selected-----44407161,0122556,44041,,,30,
					
					cbkBo.setInvoiceNumber(row[0]);
					cbkBo.setVendorId(row[1]);
					cbkBo.setLocationNumber(row[2]);
					singleInvoiceAmt = Double.parseDouble(row[5]);
					System.out.println("---IF--nextApproverId-----"+nextApproverId);
					if( singleInvoiceAmt <= Double.parseDouble(approvalLimit)  && nextApproverId.equalsIgnoreCase("No further approvals")) //Normal Case < floorAmt - No popup
					{
						nextApprId = "No further approvals";
						finalTotal  =  finalTotal + singleInvoiceAmt;
						count = count + 1;
					}//pop selected
					if(singleInvoiceAmt > Double.parseDouble(approvalLimit)  && !nextApproverId.equalsIgnoreCase("No further approvals")) //Normal Case > floorAmt - Popup selected
					{
						nextApprId = nextApproverId;
						finalTotal  =  finalTotal + singleInvoiceAmt;
						count = count + 1;
					}
					//2 records checked - 1 < and 1 > flooramount with popup selected
					if( singleInvoiceAmt <= Double.parseDouble(approvalLimit) && !nextApproverId.equalsIgnoreCase("No further approvals")) //Normal Case < and  > floorAmt -  popup selected
					{
						nextApprId = "No further approvals";
						finalTotal  =  finalTotal + singleInvoiceAmt;
						count = count + 1;
					}
					
					//2 records checked- 1 < and 1 > flooramount with  no popup selected
					if( singleInvoiceAmt > Double.parseDouble(approvalLimit) && nextApproverId.equalsIgnoreCase("No further approvals")) //Normal Case < and  > floorAmt -  popup selected
					{
						nextApprId = null;
						//finalTotal  =  finalTotal + singleInvoiceAmt;
						//count = count + 1;
					}
					cbkBo.setApproverId(SmUserId);
					cbkBo.setStepNumber(stepNumber);
					//cbkBo.setApprovalDate(new Date());
					cbkBo.setApprovalDate(DateFunctions.adjustCurrentDateByDaysNoFormat(0));
					cbkBo.setNextAproverId(nextApprId);
					massApprovalList.add(cbkBo);
				}
			}
			
			System.out.println("-----Invoices Approved ---count--"+count+"      finalTotal--"+finalTotal);
			massApprovalsForm.setInvoiceCount(count);
			massApprovalsForm.setTotalAmt(Double.parseDouble(String.format("%.2f",finalTotal)));
			System.out.println("------massApprovalList size-----"+massApprovalList.size());
			chargebackSearchDelegate.massUpdateChargebackApprover(massApprovalList);
			
            // Get the Email address of the Approver
            String location = null;
            String nextApprover = null;
            String assignedApproverId = null;
            StringBuffer approvedInvoicesList = new StringBuffer();
    		StringBuffer assignedApproverInvoicesList = new StringBuffer();
    		
			for( int i=0;i< massApprovalList.size(); i++)
			{
				ChargebackBO  cbkBo1 = new ChargebackBO();
				cbkBo1 = massApprovalList.get(i);
				nextApprover = cbkBo1.getNextAproverId();
				location = cbkBo1.getLocationNumber(); 
				 if(!("null").equals(nextApprover) && nextApprover.equalsIgnoreCase("No further approvals"))
				 {
					 approvedInvoicesList  = approvedInvoicesList.append(cbkBo1.getInvoiceNumber()+", ");
				 }
				 if(!("null").equals(nextApprover) && !nextApprover.equalsIgnoreCase("No further approvals"))
				 {
					 assignedApproverId =  nextApprover;
					 assignedApproverInvoicesList  = assignedApproverInvoicesList.append(cbkBo1.getInvoiceNumber()+", ");
				 }
			}
			
			System.out.println("Approved Invoices List -----"+approvedInvoicesList);
			System.out.println("Approver assigned  Invoices List -----"+assignedApproverInvoicesList);
			
            if(approvedInvoicesList!=null && approvedInvoicesList.length()>0) {
                  CreateNewUserBO UserBODetails = chargebackSearchDelegate.getActiveUserDetails(SmUserId);
                  // Send email only when user finally confirmed on the approver and notification
                  if (UserBODetails.getUseremailId() != null) {
                         UserBODetails.setUseremailId(TEST_EMAIL); // need to remove this line when we are at actual environment. 
                         chargebackMailer.massApprovedInvoiceSendEmail(approvedInvoicesList, location, UserBODetails.getUseremailId(), SmUserId);
                  }
            }
            if(assignedApproverInvoicesList!=null && assignedApproverInvoicesList.length()>0) {
                CreateNewUserBO UserBODetails = chargebackSearchDelegate.getActiveUserDetails(assignedApproverId);
                // Send email only when user finally confirmed on the approver and notification
                if (UserBODetails.getUseremailId() != null) {
                       UserBODetails.setUseremailId(TEST_EMAIL); // need to remove this line when we are at actual environment. 
                       chargebackMailer.massAssignedApproverInvoiceSendEmail(assignedApproverInvoicesList, location, UserBODetails.getUseremailId(), SmUserId, assignedApproverId);
                }
          }
			
			/*UPDATE ${db.schema.name}.CBK_CHARGEBACK
			SET NEXT_APPROVER_ID = #nextAproverId#
			WHERE LTRIM(INVOICE_NUMBER) = #invoiceNumber:VARCHAR# AND
			LTRIM(LOCATION_NUMBER)= #locationNumber#
			*/
			// Perform the APPROVE (INSERT)
			//chargebackSearchDelegate.massApproveChargebacks(massApprovalList);
		/*<insert id="insertApprovals" parameterClass="ChargebackBO">
			INSERT INTO ${db.schema.name}.CBK_APPROVALS
			(INVOICE_NUMBER,LOCATION_NUMBER,STEP_NUMBER,APPROVER_ID,APPROVAL_DATE)
			values(#invoiceNumber#, #locationNumber#,#stepNumber#, #approverId#,
			#approvalDate#)
		</insert>*/

		} catch (Exception e) {
			e.printStackTrace();
			mav.setViewName(ActionUrlMapping.GLOBAL.get(Constants.ACTION_FAILURE));
			log.error("Exception in execute:" + e);
		}

		// Finish with
		 mav.setViewName(ActionUrlMapping.MASSAPPROVALSACTIONS.get("count"));
		System.out.println("URL mapping--" + mav.getViewName());
		request.setAttribute("actionMessages", errors);
		request.setAttribute("massApprovalsForm", massApprovalsForm);
		return mav;

	}

	
	/*
	 * (non-Javadoc)
	 * 
	 * @see org.apache.struts.action.Action#execute(org.apache.struts.action.
	 * ActionMapping, org.apache.struts.action.ActionForm,
	 * javax.servlet.http.HttpServletRequest,
	 * javax.servlet.http.HttpServletResponse)
	 */
	@RequestMapping(value = "/massApprovalExport", method = { RequestMethod.GET, RequestMethod.POST }, params = {"action=export" })
	public ModelAndView export(@ModelAttribute("massApprovalsForm") MassApprovalsForm massApprovalsForm,
			HttpServletRequest request, HttpServletResponse response) throws Exception 
	{
		massApprovalsForm.setFormParameterMap(request);
		ServletOutputStream out = null;

		try {
			log.debug("***** MASS APPROVAL- EXPORT *****");
			massApprovalsForm.setFormParameterMap(request);
			// **** Exceptions handled by global exception handlers ****
			String dateCriteria = request.getParameter("dateCriteria");
			HttpSession session = request.getSession();
	        String SmUserId = (String) session.getAttribute("SmUserId");
	        String amount = massApprovalsForm.getAmountTo();
			System.out.println("MASS APPROVALS - RESULTS...SmUserId....." + SmUserId);
			
			Map<String, Comparable> searchParametersFromForm = massApprovalsForm.getMap();
			searchParametersFromForm.put("userId", SmUserId);
			
			if (massApprovalsForm.getLocationNumber() != null) {

				String idPattern = "[\\s0-9,. ]*";
				boolean specialCharFlag = validateSpecialCharacters(massApprovalsForm.getLocationNumber().toString(),
						idPattern);
				if (specialCharFlag == true) {
					messages.add("locationNumber", "errors.validateLocation", null);
				}
			}
			String vendorUsed = String.valueOf(massApprovalsForm.getValue("vendorId"));
			if (messages.isEmpty()) {
				System.out.println("--------validation start ----");
				
				searchParametersFromForm.put("originator", massApprovalsForm.getOriginator());
				searchParametersFromForm.put("approver", massApprovalsForm.getApprover());
				searchParametersFromForm.put("vendorId", massApprovalsForm.getVendorId());
				searchParametersFromForm.put("locationNumber", massApprovalsForm.getLocationNumber());

				searchParametersFromForm.put("invoiceFrom", massApprovalsForm.getInvoiceFrom());
				searchParametersFromForm.put("invoiceTo", massApprovalsForm.getInvoiceTo());
				if (massApprovalsForm.getInvoiceTo() == null || massApprovalsForm.getInvoiceTo().isEmpty()) {
					searchParametersFromForm.put("invoiceTo", massApprovalsForm.getInvoiceFrom());
					System.out.println("invoice to  is null" + massApprovalsForm.getInvoiceFrom());
				}

				searchParametersFromForm.put("amountFrom", massApprovalsForm.getAmountFrom());
				searchParametersFromForm.put("amountTo", massApprovalsForm.getAmountTo());
				searchParametersFromForm.put("dateCriteria", dateCriteria);
				searchParametersFromForm.put("type", massApprovalsForm.getType());
				searchParametersFromForm.put("fromDate", massApprovalsForm.getFromDate());
				searchParametersFromForm.put("toDate", massApprovalsForm.getToDate());

				System.out.println("--FROM DATE--" + searchParametersFromForm.get("fromDate"));
				System.out.println("--TO DATE--" + searchParametersFromForm.get("toDate"));
				/*
				 * System.out.println("--STATUS--" + massApprovalsForm.getStatus());
				 * System.out.println("--APSTATUS--" + massApprovalsForm.getAPStatus());
				 * System.out.println("--TYPE--" + massApprovalsForm.getType());
				 * 
				 * searchParametersFromForm.put("notFinal", true); // notFinal IS NULL
				 * searchParametersFromForm.put("active", true); // Active is NULL
				 * searchParametersFromForm.put("type",7); // Type - Imported Chbk
				 */

				if (massApprovalsForm.getLocationNumber() != null && !massApprovalsForm.getLocationNumber().isEmpty()) {
					ResultList locationValidatorResult = chargebackSearchDelegate
							.locationNumberValidator(searchParametersFromForm);
					System.out.println("-------------AFTER QEURY------locationvalidator--size----------"
							+ locationValidatorResult.getList().size());
					if (locationValidatorResult.getList().size() == 0) {
						messages.add("locationNumber", "errors.InvalidLocationNumber", null);
					}
				}

				if (massApprovalsForm.getVendorId() != null &&	  !massApprovalsForm.getVendorId().isEmpty()) { 
					  
					  String vendorId = StringFunctions.spaceFillLeft(massApprovalsForm.getVendorId(),9,true);
						System.out.println("--in export--VENDOR SELECTOR SEARCH---vendorId---"+vendorId);
						ResultList vendorValidatorResult = chargebackSearchDelegate.vendorNumberValidator(vendorId);  
					  System.out. println("-------------AFTER QEURY------vendorValidatorResult--size---export-------" + vendorValidatorResult.getList().size()); 
					  if(vendorValidatorResult.getList().size() == 0) 
					  { 
						  messages.add("vendorId", "errors.InvalidVendorNumber", null); 
					  }
				  }
				 

				if (massApprovalsForm.getOriginator() != null && !massApprovalsForm.getOriginator().isEmpty()) {
					ResultList originatorValidatorResult = chargebackSearchDelegate
							.originatorValidator(searchParametersFromForm);
					System.out.println("-------------AFTER QEURY------originatorValidatorResult--size----------"
							+ originatorValidatorResult.getList().size());
					if (originatorValidatorResult.getList().size() == 0) {
						messages.add("originator", "errors.InvalidOriginator", null);
					}
				}

				if (massApprovalsForm.getApprover() != null && !massApprovalsForm.getApprover().isEmpty()) {
					ResultList approverValidatorResult = chargebackSearchDelegate
							.nextApproverValidator(searchParametersFromForm);
					System.out.println("-------------AFTER QEURY------approverValidatorResult--size----------"
							+ approverValidatorResult.getList().size());
					if (approverValidatorResult.getList().size() == 0) {
						messages.add("approver", "errors.InvalidApprover", null);
					}
				}
			}

			massApprovalsForm.validate(request, messages);

			System.out.println("-- FROM DATE--" + searchParametersFromForm.get("fromDate"));
			System.out.println("--TO DATE--" + searchParametersFromForm.get("toDate"));
			
			// GET THE APPROVAL LIMIT AMOUNT FOR THE USER. 
			ResultList searchResults =  chargebackSearchDelegate.getRoleIdRouteIdForUser(searchParametersFromForm);
			String floorAmount = null;
			String roleId = null;
			List  l = searchResults.getList();
			for(int i=0; i<l.size(); i++)
			{
				ChargebackBO cbo = new ChargebackBO();
				cbo = (ChargebackBO)l.get(i);
				if(cbo.getRoleId() != null && cbo.getRouteId() != null && cbo.getFloorAmount() !=null)// Double.parseDouble(approvalLimit)))
				{
					System.out.println("------- roleId, RouteId--" + cbo.getRoleId()+"--"+cbo.getRouteId());
					searchParametersFromForm.put("roleId", cbo.getRoleId());
					roleId = cbo.getRoleId().toString();
					searchParametersFromForm.put("routeId", cbo.getRouteId());
					floorAmount = cbo.getFloorAmount().toString();
				}
			}
			String approvalLimit = null;
			if(roleId !=null)// Double.parseDouble(approvalLimit)))
			{
			  approvalLimit = chargebackSearchDelegate.getApprovalLimitForUser(searchParametersFromForm);
			}
			if(approvalLimit != null && !("").equals(approvalLimit)) {
				massApprovalsForm.setUserApprovalLimit(Double.parseDouble(approvalLimit));
			}
			else {
				massApprovalsForm.setUserApprovalLimit(0.00);
			}
				
				System.out.println("-------approvalLimit--for user in massApprovalResults()----"+SmUserId+"---"+approvalLimit);
			
				String typeId ="7";
				String maxStepNumber = chargebackSearchDelegate.getMaxStepNumber(typeId);
				massApprovalsForm.setMaxStepNumber(maxStepNumber);
				
				// Mass approvals chargebacks List
				//Validation for Floor Amount
				ResultList searchResults1 = chargebackSearchDelegate.getMassApprovalsList(searchParametersFromForm);
				//System.out.println("-------getMassApprovals()------searchResults--size-------" + searchResults.getList().size());
				System.out.println("-------------AFTER QEURY---in EXPORT---searchResults--size----------"
					+ searchResults1.getList().size());

				massApprovalsForm.setSearchResults(searchResults1.getList());
				// massApprovalsForm =
				// (massApprovalsForm)session.getAttribute("massApprovalsForm");
				List ResulstList = (List) massApprovalsForm.getSearchResults();
	
				out = response.getOutputStream();
	
				// The response headers must be set in the following order, or else IE
				// won't handle things properly.
				// response.setHeader("Content-length", ""+file.getFile().length());
				response.setHeader("Content-disposition", "attachment; filename=MassApprovalExportResults.csv");
				response.setContentType("text/comma-separated-values");
				response.setHeader("Pragma", "public");
				response.setHeader("Cache-control", "must-revalidate");
	
				// out.println("Document Results (" + searchCriteriaSummary + ")");
				out.println("Chargebacks pulled for vendor number: " + vendorUsed);
				out.println("Chargebacks pulled: " + DateFunctions.getTodayTime());
				/*
				 * if (!dateRangeUsed.equals("")) { out.println("Deduction extract date range: "
				 * + dateRangeUsed); }
				 */
				out.println();
				out.println("Invoice, Location, Invoice Date, Vendor, Amount, Originator, Next Approver, FIN, CA");
	
				for (int i = 0; i < ResulstList.size(); i++) {
					ChargebackBO chargebackBO = (ChargebackBO) ResulstList.get(i);
	
					// Put a '=' and quotes around the document number to avoid
					// Excel dropping any leading zeros in the value.
	
					out.print("=\"" + ESAPIUtil.encodeforXSS(StringFunctions.convertNull(chargebackBO.getInvoiceNumber()))
							+ "\"");
					out.print(",");
					out.print(ESAPIUtil.encodeforXSS(StringFunctions.convertNull(chargebackBO.getLocationNumber())));
					out.print(",");
					out.print(ESAPIUtil.encodeforXSS(StringFunctions.convertNull(chargebackBO.getInvoiceDateString())));
					out.print(",");
					out.print(ESAPIUtil.encodeforXSS(StringFunctions.convertNull(chargebackBO.getVendorId())));
					out.print(",");
					out.print(ESAPIUtil.encodeforXSS(StringFunctions.convertNull(chargebackBO.getMassAppNetAmount().toString())));
					out.print(",");
					out.print(ESAPIUtil.encodeforXSS(StringFunctions.convertNull(chargebackBO.getOriginator())));
					out.print(",");
					out.print(ESAPIUtil.encodeforXSS(StringFunctions.convertNull(chargebackBO.getOriginalApprover())));
					out.print(",");
					out.print(ESAPIUtil.encodeforXSS(StringFunctions.convertNull(chargebackBO.getFin())));
					out.print(",");
					out.print(ESAPIUtil.encodeforXSS(StringFunctions.convertNull(chargebackBO.getCa())));
					out.print("\n");
				}
	
			} catch (Exception e) {
				e.printStackTrace();
				// Report the error using the appropriate name and ID.
				log.error("Exception in execute():" + e);
			} finally {
				if (out != null) {
					out.close();
				}
				response.flushBuffer();
			}
	
			// No mappings or forwards for this action...
			return null;
		}
	
	
	/**
	 * 
	 * @param string
	 * @param idNamePattern
	 * @return
	 */

	private boolean validateSpecialCharacters(String string, String idNamePattern) {
		Pattern pattern = Pattern.compile(idNamePattern);

		Matcher matcher = pattern.matcher(string);

		boolean patternFlag = false;

		if (!matcher.matches()) {

			patternFlag = true;
			System.out.println("String--- " + string + " contains special character");
		}

		return patternFlag;
	}

}