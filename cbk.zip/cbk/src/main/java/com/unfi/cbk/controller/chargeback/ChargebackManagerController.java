package com.unfi.cbk.controller.chargeback;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.core.env.Environment;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.servlet.ModelAndView;

import com.unfi.cbk.beans.ResultList;
import com.unfi.cbk.bo.ChargebackBO;
import com.unfi.cbk.bo.ChargebackManagerBO;
import com.unfi.cbk.controller.PageAccessResolver;
import com.unfi.cbk.delegates.ChargebackManagerDelegate;
import com.unfi.cbk.delegates.ChargebackSearchDelegate;
import com.unfi.cbk.exceptions.DataAccessException;
import com.unfi.cbk.forms.ChargebackManagerForm;
import com.unfi.cbk.util.ActionMessages;
import com.unfi.cbk.util.ActionUrlMapping;
import com.unfi.cbk.util.Constants;
import com.unfi.cbk.util.DateFunctions;
import com.unfi.cbk.util.ESAPIUtil;
import com.unfi.cbk.util.StringFunctions;

@Controller("chargebackManagerController_chargeback")
@Scope(value = WebApplicationContext.SCOPE_REQUEST, proxyMode = ScopedProxyMode.TARGET_CLASS)
public class ChargebackManagerController {
	static Logger log = Logger.getLogger(ChargebackManagerController.class);
	@Autowired
	ActionMessages errors;

	@Autowired
	ActionMessages messages;
	@Autowired
	Environment env;

	@Autowired
	private ChargebackManagerDelegate chargebackManagerDelegate;
	
	@Autowired
	private ChargebackSearchDelegate chargebackSearchDelegate;

	// Externalize this value
	@Value("${cbk.autoGrowCollectionLimit:100000}")
	private int autoGrowCollectionLimit;

	@InitBinder
	public void initBinder(WebDataBinder dataBinder) {
		dataBinder.setAutoGrowCollectionLimit(autoGrowCollectionLimit);
	}

	@RequestMapping(value = "/chargebackManager", method = { RequestMethod.GET, RequestMethod.POST }, params = {
			"action=managerHome" })
	public ModelAndView managerHome(
			@ModelAttribute("chargebackManagerForm") ChargebackManagerForm chargebackManagerForm,
			HttpServletRequest request) throws Exception {
		ModelAndView mav = new ModelAndView();
		chargebackManagerForm.setFormParameterMap(request);

		if (request.getParameter("isformreset") != null) {
			chargebackManagerForm.reset(request);
		}
		log.debug("*****CHARGEBACK MANAGER *****ManagerHome()");

		// If a message is required, save the specified key(s) into the request.
		if (!errors.isEmpty()) {
			log.debug("FAILED");
			// saveMessages(request, errors);
			errors.saveMessages(request);
		}

		// Finish with
		// return (forward);
		mav.setViewName(ActionUrlMapping.CHARGEBACKMANAGERACTION.get("managerMenu"));
		request.setAttribute("actionMessages", errors);
		request.setAttribute("chargebackManagerForm", chargebackManagerForm);

		return mav;

	}

	@RequestMapping(value = "/workWithChargebackSearch", method = { RequestMethod.GET, RequestMethod.POST }, params = {
			"action=chargeSearch" })
	public ModelAndView chargeSearch(
			@ModelAttribute("chargebackManagerForm") ChargebackManagerForm chargebackManagerForm,
			HttpServletRequest request) throws Exception {
		ModelAndView mav = new ModelAndView();
		log.debug("*****CHARGEBACK MANAGER ***workWithChargebackSearch**chargeSearch()");
		chargebackManagerForm.setFormParameterMap(request);
		Map<String, Comparable> searchParametersFromForm = chargebackManagerForm.getMap();

		if (request.getParameter("isformreset") != null) {
			chargebackManagerForm.reset(request);
		}

		boolean Approver = true;

		// Define the display parameters
		int maxRows = 20;
		chargebackManagerForm.setDisplayCount(maxRows);

		if (chargebackManagerForm.isShowAll()) {
			searchParametersFromForm.put("showAll", "true");
		} else {
			searchParametersFromForm.put("rowStart", new Integer(chargebackManagerForm.getCurrentRecord()));
			searchParametersFromForm.put("rowEnd", new Integer(chargebackManagerForm.getCurrentRecord() + maxRows - 1));
		}

		if (Approver) {

			// Get the ChargebackType list

			List chargebackTypes = chargebackManagerDelegate.getChargebackTypes();
			chargebackManagerForm.setChargebackTypes(chargebackTypes);

			mav.setViewName(ActionUrlMapping.CHARGEBACKMANAGERACTION.get(Constants.ACTION_SUCCESS));
			request.setAttribute("actionMessages", errors);
			request.setAttribute("chargebackManagerForm", chargebackManagerForm);
		} else {

			List chargebackTypes = chargebackManagerDelegate.getChargebackTypes();
			chargebackManagerForm.setChargebackTypes(chargebackTypes);

			mav.setViewName(ActionUrlMapping.CHARGEBACKMANAGERACTION.get(Constants.ACTION_SUCCESS));
			request.setAttribute("actionMessages", errors);
			request.setAttribute("chargebackManagerForm", chargebackManagerForm);
		}
		return mav;

	}

	

	@RequestMapping(value = "/chargebackResults", method = { RequestMethod.GET, RequestMethod.POST }, params = {"action=chargeResults"})
	public ModelAndView chargeResults(
			@ModelAttribute("chargebackManagerForm") ChargebackManagerForm chargebackManagerForm,
			HttpServletRequest request) throws Exception {
		ModelAndView mav = new ModelAndView();
		chargebackManagerForm.setFormParameterMap(request);
		// **** Exceptions handled by global exception handlers ****
		String dateCriteria = request.getParameter("dateCriteria");
		Map<String, Comparable> searchParametersFromForm = chargebackManagerForm.getMap();
		log.debug("*****CHARGEBACK MANAGER *****chargeResults()");
		if (chargebackManagerForm.getLocationNumber() != null) {

			String idPattern = "[\\s0-9,. ]*";
			boolean specialCharFlag = validateSpecialCharacters(chargebackManagerForm.getLocationNumber().toString(),idPattern);
			if (specialCharFlag == true) {
				messages.add("locationNumber", "errors.validateLocation", null);
			}
		}
		
		
		System.out.println("--locationNumber --"+chargebackManagerForm.getLocationNumber());
		if (messages.isEmpty()) {
			searchParametersFromForm.put("originator", chargebackManagerForm.getOriginator());
			searchParametersFromForm.put("approver", chargebackManagerForm.getApprover());
			searchParametersFromForm.put("vendorId", chargebackManagerForm.getVendorId());
			searchParametersFromForm.put("locationNumber", chargebackManagerForm.getLocationNumber());

			searchParametersFromForm.put("invoiceFrom", chargebackManagerForm.getInvoiceFrom());
			searchParametersFromForm.put("invoiceTo", chargebackManagerForm.getInvoiceTo());
			if (chargebackManagerForm.getInvoiceTo() == null || chargebackManagerForm.getInvoiceTo().isEmpty()) {
				searchParametersFromForm.put("invoiceTo", chargebackManagerForm.getInvoiceFrom());
			}

			searchParametersFromForm.put("amountFrom", chargebackManagerForm.getAmountFrom());
			searchParametersFromForm.put("amountTo", chargebackManagerForm.getAmountTo());
			searchParametersFromForm.put("dateCriteria", dateCriteria);
			searchParametersFromForm.put("type", chargebackManagerForm.getType());
			searchParametersFromForm.put("fromDate", chargebackManagerForm.getFromDate());
			searchParametersFromForm.put("toDate", chargebackManagerForm.getToDate());

			if (("Cancelled").equalsIgnoreCase(chargebackManagerForm.getStatus())) {// Cancelled IS NOT NULL

				searchParametersFromForm.put("cancelled", "true");
			} else
			// Active is NULL
			{
				searchParametersFromForm.put("active", "true");
			}
			if (("Final").equalsIgnoreCase(chargebackManagerForm.getAPStatus())) {// Final IS NOT NULL

				searchParametersFromForm.put("final", true);
			} else
			// notFinal IS NULL
			{
				searchParametersFromForm.put("notFinal", true);
			}

			if (chargebackManagerForm.getLocationNumber() != null
					&& !chargebackManagerForm.getLocationNumber().isEmpty()) {
				ResultList locationValidatorResult = chargebackManagerDelegate
						.locationNumberValidator(searchParametersFromForm);

				if (locationValidatorResult.getList().size() == 0) {
					messages.add("locationNumber", "errors.InvalidLocationNumber", null);
				}
			}

			if (chargebackManagerForm.getVendorId() != null && !chargebackManagerForm.getVendorId().isEmpty()) {
				
				String vendorId = StringFunctions.spaceFillLeft(chargebackManagerForm.getVendorId(),9,true);
				System.out.println("----VENDOR VALIDATOR SEARCH---vendorId---"+vendorId);
				ResultList vendorValidatorResult = chargebackSearchDelegate.vendorNumberValidator(vendorId);
				if (vendorValidatorResult.getList().size() == 0) {
					messages.add("vendorId", "errors.InvalidVendorNumber", null);
				}
			}

			if (chargebackManagerForm.getOriginator() != null && !chargebackManagerForm.getOriginator().isEmpty()) {
				ResultList originatorValidatorResult = chargebackManagerDelegate
						.originatorValidator(searchParametersFromForm);

				if (originatorValidatorResult.getList().size() == 0) {
					messages.add("originator", "errors.InvalidOriginator", null);
				}
			}

			if (chargebackManagerForm.getApprover() != null && !chargebackManagerForm.getApprover().isEmpty()) {
				ResultList approverValidatorResult = chargebackManagerDelegate
						.approverValidator(searchParametersFromForm);

				if (approverValidatorResult.getList().size() == 0) {
					messages.add("approver", "errors.InvalidApprover", null);
				}
			}
		}

		chargebackManagerForm.validate(request, messages);
		if (!messages.isEmpty()) {

			List chargebackTypes = chargebackSearchDelegate.getChargebackTypes();
			chargebackManagerForm.setChargebackTypes(chargebackTypes);
			request.setAttribute("actionMessages", messages);
			messages.saveMessages(request);
			mav.setViewName(ActionUrlMapping.CHARGEBACKMANAGERACTION.get(Constants.ACTION_SUCCESS));
			request.setAttribute("chargebackManagerForm", chargebackManagerForm);
			return mav;
		}
		
		// Define the display parameters
		int maxRows = 20;
		chargebackManagerForm.setDisplayCount(maxRows);

		if (chargebackManagerForm.isShowAll()) {
			searchParametersFromForm.put("showAll", "true");
		} else {
			searchParametersFromForm.put("rowStart", new Integer(chargebackManagerForm.getCurrentRecord()));
			searchParametersFromForm.put("rowEnd", new Integer(chargebackManagerForm.getCurrentRecord() + maxRows - 1));
		}
		// Put the map in session for export
		// HttpSession session=request.getSession();
		// session.setAttribute("searchParametersFromForm",searchParametersFromForm);
		HttpSession session = request.getSession();
		String SmUserId = (String) session.getAttribute("SmUserId");

		searchParametersFromForm.put("userId", SmUserId);
		System.out.println("-----loc from map--"+searchParametersFromForm.get("locationNumber"));
		// Available Chargebacks List
		ResultList searchResults = chargebackManagerDelegate.getChargebacks(searchParametersFromForm);

		// Populate the 'searchResults' property in the ActionForm
		chargebackManagerForm.setSearchResults(searchResults.getList());
		chargebackManagerForm.setTotalRecords(searchResults.getTotalCount().intValue());

		messages.saveMessages(request);
		
		
		PageAccessResolver resolver = new PageAccessResolver(request);
		if (resolver.hasAccess()) {
			mav.setViewName(ActionUrlMapping.CHARGEBACKMANAGERACTION.get("workWithChargebackResults"));
			request.setAttribute("actionMessages", errors);
			request.setAttribute("chargebackManagerForm", chargebackManagerForm);
			// HttpSession session=request.getSession();
			// session.setAttribute("massApprovalsForm", massApprovalsForm);

			return mav;
		}
		mav.setViewName(ActionUrlMapping.CHARGEBACKMANAGERACTION.get("other"));
		request.setAttribute("actionMessages", messages);
		request.setAttribute("chargebackManagerForm", chargebackManagerForm);
		return mav;
	}
	
	/**
	 * Cancel Chargeback method
	 * 
	 * @param ChargebackManagerForm
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
    @RequestMapping(value = "/cancelChargeback", method = { RequestMethod.GET,
            RequestMethod.POST }, consumes = "application/json", params = { "action=cancelCBK" })
	public @ResponseBody ResponseEntity<?> processAJAXRequest(@RequestParam("invoiceNumber") String invoiceNumber) {
	
	     boolean validate = false;
	     if (invoiceNumber != null) {
	    	 log.debug("*****CHARGEBACK MANAGER *****cancelChargeback");
	
	            // VALIDATE FROM DATABASE
	            try {
	            	 chargebackManagerDelegate.getCancelChargeback(invoiceNumber);
	                 
	                         validate = true;
	                        
	
	            } catch (DataAccessException e) {
	                  // TODO Auto-generated catch block
	                  e.printStackTrace();
	            }
	
	     }
	     return ResponseEntity.ok(validate);
	    }


	@RequestMapping(value = "/chargebackAccruals", method = { RequestMethod.GET, RequestMethod.POST })
	public ModelAndView accruals(@ModelAttribute("chargebackManagerForm") ChargebackManagerForm chargebackManagerForm,
			HttpServletRequest request, HttpServletResponse response) throws Exception {
		chargebackManagerForm.setFormParameterMap(request);
		ServletOutputStream out = null;

		try {
			log.debug("***MANAGER** CHARGEBACK ACCRUALS- REPORT *****accruals()");

			Map searchParametersFrom = chargebackManagerForm.getMap();
			ResultList searchResults = chargebackManagerDelegate.getChargeAccrual(searchParametersFrom);
			chargebackManagerForm.setSearchResults(searchResults.getList());

			List l1 = (List) searchResults.getList();
			List<String> slist = new ArrayList<String>();
			for (int i = 0; i < l1.size(); i++) {
				ChargebackManagerBO b1 = (ChargebackManagerBO) l1.get(i);
				slist.add(b1.getLocationNumber().trim());
			}
			Set<String> hashSet = new LinkedHashSet(slist);
			ArrayList<String> locationNumbers = new ArrayList(hashSet);
			List finalList = new ArrayList();
			for (int j = 0; j < locationNumbers.size(); j++) {
				String locationNumb = locationNumbers.get(j).trim();
				List<ChargebackManagerBO> groupList = new ArrayList<ChargebackManagerBO>();
				for (int k = 0; k < l1.size(); k++) {
					ChargebackManagerBO b2 = (ChargebackManagerBO) l1.get(k);
					if (locationNumb.equals(b2.getLocationNumber().trim())) {
						groupList.add(b2);
					}
				}
				finalList.add(groupList);
			}

			List finalPopulateList = new ArrayList();
			for (int l = 0; l < finalList.size(); l++) {
				List insideList = (List) finalList.get(l);
				for (int m = 0; m < insideList.size(); m++) {
					ChargebackManagerBO b3 = (ChargebackManagerBO) insideList.get(m);
					if (b3 != null && b3.getCompanyCode() != null) {
						String company_code = b3.getCompanyCode();
						String acc_number = b3.getAccNumber();
						String location = b3.getLocationNumber();
						String rName = b3.getrName();
						String distAcc = b3.getDistAcct();

						List<ChargebackManagerBO> insideFinallist = new ArrayList<ChargebackManagerBO>();
						for (int n = 0; n < insideList.size(); n++) {
							ChargebackManagerBO b4 = (ChargebackManagerBO) insideList.get(n);
							if (b4 != null && b4.getCompanyCode() != null) {
								if (b4.getCompanyCode().equals(company_code) && b4.getAccNumber().equals(acc_number)
										&& b4.getLocationNumber().equals(location) && b4.getrName().equals(rName)
										&& b4.getDistAcct().equals(distAcc)) {
									insideFinallist.add(b4);
									insideList.set(n, new ChargebackManagerBO());
								}
							}
						}
						finalPopulateList.add(insideFinallist);
					}
				}
			}

			for (int r = 0; r < finalPopulateList.size(); r++) {
				List s = (List) finalPopulateList.get(r);
				for (int t = 0; t < s.size(); t++) {
					ChargebackManagerBO b5 = (ChargebackManagerBO) s.get(t);
				}
			}

			out = response.getOutputStream();

			// The response headers must be set in the following order, or else IE
			// won't handle things properly.
			response.setHeader("Content-disposition", "attachment; filename=ChargebackAccruals.csv");
			response.setContentType("text/comma-separated-values");
			response.setHeader("Pragma", "public");
			response.setHeader("Cache-control", "must-revalidate");

			out.println();
			out.println();
			out.println("  ,,,,,                                                " + "   CHARGEBACK ACCRUALS  ");
			out.println("  ,,,,,,         									     " + DateFunctions.getTodayTime());
			// out.println(" ,,,,, " + " CHARGEBACK ACCRUALS ");
			String locationNo = null;
			for (int i = 0; i < finalPopulateList.size(); i++) {
				List s = (List) finalPopulateList.get(i);
				// Calculation of amount--ChargebackManagerBO
				ChargebackManagerBO bo = new ChargebackManagerBO();
				Double total = 0.00;
				for (int k = 0; k < s.size(); k++) {
					bo = (ChargebackManagerBO) s.get(k);
					total = total + Double.parseDouble(bo.getAmount());
				}

				for (int j = 0; j < s.size(); j++) {
					ChargebackManagerBO mgrBO = (ChargebackManagerBO) s.get(j);
					if (j == 0) {
						out.println();
						out.print("  ,,,,, ,           " + mgrBO.getLocationNumber());
						out.print(",,");
						out.print(mgrBO.getrName());
						out.println();
						if (!mgrBO.getLocationNumber().equals(locationNo)) {
							out.println(",,,,, Chargeback #: , Date:, Vendor #: , Creator:,  Amount:  ");
							locationNo = mgrBO.getLocationNumber();
						}
						out.print(",");
						out.print(mgrBO.getCompanyCode());
						out.print(",");
						out.print(mgrBO.getAccNumber());
						out.print(",");
						out.print(mgrBO.getDistAcct());
						out.println(" , , , ,,,  " + "$ " + total);
					}
					// Put a '=' and quotes around the document number to avoid
					// Excel dropping any leading zeros in the value.
					out.print(",");
					out.print(",");
					out.print(",");
					out.print(",");
					out.print(",");
					out.print("=\"" + ESAPIUtil.encodeforXSS(StringFunctions.convertNull(mgrBO.getInvoiceNumber()))
							+ "\"");
					out.print(",");
					out.print(ESAPIUtil.encodeforXSS(StringFunctions.convertNull(mgrBO.getInvoiceDateString())));
					out.print(",");
					out.print(ESAPIUtil.encodeforXSS(StringFunctions.convertNull(mgrBO.getVendorNumber())));
					out.print(",");
					out.print(ESAPIUtil.encodeforXSS(StringFunctions.convertNull(mgrBO.getCreatorId())));
					out.print(",");
					out.print(ESAPIUtil.encodeforXSS(StringFunctions.convertNull("$   " + mgrBO.getAmount())));
					out.print(",");
					out.print("\n");
				}
			}
			/*
			 * out.println(""); out.print("  ,,,, ,           " + locationNum);
			 * out.print(","); out.print(rname); out.println(",,total,  " +
			 * chargebackManagerForm.getTotalAccruals());
			 */

		} catch (Exception e) {
			e.printStackTrace();
			// Report the error using the appropriate name and ID.
			log.error("Exception in execute():" + e);
		} finally {
			if (out != null) {
				out.close();
			}
			response.flushBuffer();
		}

		// No mappings or forwards for this action...
		return null;
	}

	@RequestMapping(value = "/chargebackRoles", method = { RequestMethod.GET, RequestMethod.POST }, params = {
			"action=roles" })
	public ModelAndView roles(@ModelAttribute("chargebackManagerForm") ChargebackManagerForm chargebackManagerForm,
			HttpServletRequest request) throws Exception {

		ModelAndView mav = new ModelAndView();
		log.debug("***MANAGER**  *****roles()");
		if (request.getParameter("isformreset") != null) {
			chargebackManagerForm.reset(request);
		}

		Map searchParametersFrom = chargebackManagerForm.getMap();
		// Define the display parameters
		int maxRows = 20;
		chargebackManagerForm.setDisplayCount(maxRows);

		// If a message is required, save the specified key(s) into the request.
		if (!errors.isEmpty()) {
			log.debug("FAILED");
			// saveMessages(request, errors);
			errors.saveMessages(request);
		}

		ResultList searchResults = chargebackManagerDelegate.getChargebackRoles(searchParametersFrom);
		chargebackManagerForm.setSearchResults(searchResults.getList());
		// chargebackManagerForm.setTotalRecords(searchResults.getTotalCount().intValue());

		PageAccessResolver resolver = new PageAccessResolver(request);
		if (resolver.hasAccess()) {
			mav.setViewName(ActionUrlMapping.CHARGEBACKMANAGERACTION.get("chargeRoles"));
			request.setAttribute("chargebackManagerForm", chargebackManagerForm);

		}

		request.setAttribute("actionMessages", errors);
		return mav;

	}

	@RequestMapping(value = "/chargebackManager", method = { RequestMethod.GET, RequestMethod.POST }, params = {
			"action=auditLog" })
	public ModelAndView AuditLog(@ModelAttribute("chargebackManagerForm") ChargebackManagerForm chargebackManagerForm,
			HttpServletRequest request) throws Exception {

		ModelAndView mav = new ModelAndView();
		log.debug("***MANAGER**  *****AuditLog()");

		if (request.getParameter("isformreset") != null) {
			chargebackManagerForm.reset(request);
		}
		if (!errors.isEmpty()) {
			log.debug("FAILED");
			// saveMessages(request, errors);
			errors.saveMessages(request);
		}

		mav.setViewName(ActionUrlMapping.CHARGEBACKMANAGERACTION.get("auditLog"));
		request.setAttribute("actionMessages", errors);
		request.setAttribute("chargebackManagerForm", chargebackManagerForm);

		return mav;

	}

	@RequestMapping(value = "/chargebackManager", method = { RequestMethod.GET, RequestMethod.POST }, params = {
			"action=auditLogSearch" })
	public ModelAndView AuditLogSearch(
			@ModelAttribute("chargebackManagerForm") ChargebackManagerForm chargebackManagerForm,
			HttpServletRequest request) throws Exception {
		ModelAndView mav = new ModelAndView();
		log.debug("***MANAGER**  *****AuditLogSearch()");
		String dateCriteria = request.getParameter("dateCriteria");

		if (request.getParameter("isformreset") != null) {
			chargebackManagerForm.reset(request);
		}

		Map searchParametersFrom = chargebackManagerForm.getMap();

		if (!errors.isEmpty()) {
			log.debug("FAILED"); // saveMessages(request, errors);
			errors.saveMessages(request);
		}

		String dt = chargebackManagerForm.getDate();
		if (messages.isEmpty()) {

			searchParametersFrom.put("dateCriteria", dateCriteria);
			if (chargebackManagerForm.getDate() != null && !chargebackManagerForm.getDate().isEmpty()) {

				searchParametersFrom.put("date",
						DateFunctions.chargebackDateConversion(chargebackManagerForm.getDate()));
			}
		}

		ResultList searchResults = chargebackManagerDelegate.getAuditResults(searchParametersFrom);
		chargebackManagerForm.setSearchResults(searchResults.getList());

//Calculation of amount
		Double total = 0.00;
		String exporterName = "";
		if (searchResults.getList().size() > 0) {
			List l1 = (List) searchResults.getList();
			ChargebackManagerBO bo = new ChargebackManagerBO();

			for (int i = 0; i < l1.size(); i++) {
				bo = (ChargebackManagerBO) l1.get(i);

				total = total + Double.parseDouble(bo.getExportedAmount());
				if (("").equals(exporterName)) {
					exporterName = bo.getExportedId();
				}
			}

			chargebackManagerForm.setTotalExportedAmount(String.format("%.2f",total));
			chargebackManagerForm.setExporterName(exporterName);
		}
		chargebackManagerForm.setDate(dt);

		PageAccessResolver resolver = new PageAccessResolver(request);
		if (resolver.hasAccess()) {
			mav.setViewName(ActionUrlMapping.CHARGEBACKMANAGERACTION.get("auditLog"));
			request.setAttribute("chargebackManagerForm", chargebackManagerForm);

		}

		request.setAttribute("actionMessages", errors);

		return mav;

	}

	@RequestMapping(value = "/chargebackManager", method = { RequestMethod.GET, RequestMethod.POST }, params = {
			"action=cbkLocations" })
	public ModelAndView CbkLocations(
			@ModelAttribute("chargebackManagerForm") ChargebackManagerForm chargebackManagerForm,
			HttpServletRequest request) throws Exception {
		ModelAndView mav = new ModelAndView();
		log.debug("***MANAGER**  *****CbkLocations()");
		chargebackManagerForm.setFormParameterMap(request);

		if (request.getParameter("isformreset") != null) {
			chargebackManagerForm.reset(request);
		}
		if (!errors.isEmpty()) {
			log.debug("FAILED");
			// saveMessages(request, errors);
			errors.saveMessages(request);
		}
		List searchResults = chargebackManagerDelegate.getLocations();
		chargebackManagerForm.setSearchResults(searchResults);

		mav.setViewName(ActionUrlMapping.CHARGEBACKMANAGERACTION.get("cbkLocation"));
		request.setAttribute("actionMessages", errors);
		request.setAttribute("chargebackManagerForm", chargebackManagerForm);
		return mav;

	}

	@RequestMapping(value = "/chargebackManager", method = { RequestMethod.GET, RequestMethod.POST }, params = {
			"action=cbkLocationResults" })
	public ModelAndView CbkLocationResults(
			@ModelAttribute("chargebackManagerForm") ChargebackManagerForm chargebackManagerForm,
			HttpServletRequest request) throws Exception {
		ModelAndView mav = new ModelAndView();
		log.debug("***MANAGER**  *****CbkLocationResults()");
		chargebackManagerForm.setFormParameterMap(request);

		if (request.getParameter("isformreset") != null) {
			chargebackManagerForm.reset(request);
		}

		Map searchParametersFrom = chargebackManagerForm.getMap();

// If a message is required, save the specified key(s) into the request.
		if (!errors.isEmpty()) {
			log.debug("FAILED");
			// saveMessages(request, errors);
			errors.saveMessages(request);
		}

		// Location
		searchParametersFrom.put("location", chargebackManagerForm.getLocationNumber());
		if (chargebackManagerForm.getLocationNumber().equals("2")) {
			searchParametersFrom.put("locationNumber", chargebackManagerForm.getLocationNumber());
		}

		ResultList searchResults = chargebackManagerDelegate.getCbkLocDetails(searchParametersFrom);
		chargebackManagerForm.setSearchResults(searchResults.getList());
		mav.setViewName(ActionUrlMapping.CHARGEBACKMANAGERACTION.get("cbkLocation"));
		request.setAttribute("actionMessages", errors);
		request.setAttribute("chargebackManagerForm", chargebackManagerForm);
		return mav;

	}

	@RequestMapping(value = "/chargebackManager", method = { RequestMethod.GET, RequestMethod.POST }, params = {
			"action=createLocation" })
	public ModelAndView CreateLocation(
			@ModelAttribute("chargebackManagerForm") ChargebackManagerForm chargebackManagerForm,
			HttpServletRequest request) throws Exception {
		ModelAndView mav = new ModelAndView();
		log.debug("***MANAGER**  *****CreateLocation()");
		chargebackManagerForm.setFormParameterMap(request);

		if (request.getParameter("isformreset") != null) {
			chargebackManagerForm.reset(request);
		}
		if (!errors.isEmpty()) {
			log.debug("FAILED");
			// saveMessages(request, errors);
			errors.saveMessages(request);
		}
		mav.setViewName(ActionUrlMapping.CHARGEBACKMANAGERACTION.get("createLocation"));
		request.setAttribute("actionMessages", errors);
		request.setAttribute("chargebackManagerForm", chargebackManagerForm);
		return mav;

	}

	@RequestMapping(value = "/chargebackManager", method = { RequestMethod.GET, RequestMethod.POST }, params = {
			"action=saveCreateLocation" })
	public ModelAndView SaveCreateLocation(
			@ModelAttribute("chargebackManagerForm") ChargebackManagerForm chargebackManagerForm,
			HttpServletRequest request) throws Exception {
		ModelAndView mav = new ModelAndView();
		log.debug("***MANAGER**  *****SaveCreateLocation()");
		chargebackManagerForm.setFormParameterMap(request);

		if (request.getParameter("isformreset") != null) {
			chargebackManagerForm.reset(request);
		}

		Map searchParametersFrom = chargebackManagerForm.getMap();


		if (!errors.isEmpty()) {
			log.debug("FAILED"); // saveMessages(request, errors);
			errors.saveMessages(request);
		}

		searchParametersFrom.put("locationNumber", chargebackManagerForm.getLocationNumber());
		searchParametersFrom.put("parentNumber", chargebackManagerForm.getParentNumber());
		searchParametersFrom.put("stateCode", chargebackManagerForm.getStateCode());
		chargebackManagerDelegate.saveCreateLocation(searchParametersFrom);

		ResultList searchResults = chargebackManagerDelegate.getCbkLocDetails(searchParametersFrom);
		chargebackManagerForm.setSearchResults(searchResults.getList());
		mav.setViewName(ActionUrlMapping.CHARGEBACKMANAGERACTION.get("cbkLocation"));
		request.setAttribute("actionMessages", errors);
		request.setAttribute("chargebackManagerForm", chargebackManagerForm);
		return mav;

	}

	@RequestMapping(value = "/chargebackManager", method = { RequestMethod.GET, RequestMethod.POST }, params = {
			"action=editLocation" })
	public ModelAndView EditLocation(
			@ModelAttribute("chargebackManagerForm") ChargebackManagerForm chargebackManagerForm,
			HttpServletRequest request) throws Exception {
		ModelAndView mav = new ModelAndView();
		log.debug("***MANAGER**  *****EditLocation()");
		chargebackManagerForm.setFormParameterMap(request);

		Map searchParametersFromForm = chargebackManagerForm.getMap();

		String locationNumber = (String) request.getParameter("locationNumber");
		String locationName = (String) request.getParameter("locationName");
		String parentName = (String) request.getParameter("parentName");

		chargebackManagerForm.setLocationName(locationName);
		chargebackManagerForm.setParentName(parentName);

		log.debug("*****CHARGEBACK MANAGER *****EditLocation()");
		ChargebackManagerBO editLocBODetails = chargebackManagerDelegate.getEditLocDetails(locationNumber);

		chargebackManagerForm.populateFormFromObject(editLocBODetails);
		if (!errors.isEmpty()) {
			log.debug("FAILED");
			errors.saveMessages(request);
		}

		mav.setViewName(ActionUrlMapping.CHARGEBACKMANAGERACTION.get("editLocation"));
		request.setAttribute("actionMessages", errors);
		request.setAttribute("chargebackManagerForm", chargebackManagerForm);
		return mav;

	}

	@RequestMapping(value = "/chargebackManager", method = { RequestMethod.GET, RequestMethod.POST }, params = {
			"action=updateLocation" })
	public ModelAndView SaveUpdateLocation(
			@ModelAttribute("chargebackManagerForm") ChargebackManagerForm chargebackManagerForm,
			HttpServletRequest request) throws Exception {
		ModelAndView mav = new ModelAndView();
		log.debug("***MANAGER**  *****SaveUpdateLocation()");
		chargebackManagerForm.setFormParameterMap(request);

		if (request.getParameter("isformreset") != null) {
			chargebackManagerForm.reset(request);
		}

		Map searchParametersFrom = chargebackManagerForm.getMap();

		if (!errors.isEmpty()) {
			log.debug("FAILED"); // saveMessages(request, errors);
			errors.saveMessages(request);
		}

		searchParametersFrom.put("locationNumber", chargebackManagerForm.getLocationNumber());
		searchParametersFrom.put("parentNumber", chargebackManagerForm.getParentNumber());
		searchParametersFrom.put("stateCode", chargebackManagerForm.getStateCode());
		chargebackManagerDelegate.updateLocation(searchParametersFrom);

		List searchResults = chargebackManagerDelegate.getLocations();
		chargebackManagerForm.setSearchResults(searchResults);
		mav.setViewName(ActionUrlMapping.CHARGEBACKMANAGERACTION.get("cbkLocation"));
		request.setAttribute("actionMessages", errors);
		request.setAttribute("chargebackManagerForm", chargebackManagerForm);
		return mav;

	}

	@RequestMapping(value = "/chargebackManager", method = { RequestMethod.GET, RequestMethod.POST }, params = {
			"action=deleteLocation" })
	public ModelAndView DeleteLocation(
			@ModelAttribute("chargebackManagerForm") ChargebackManagerForm chargebackManagerForm,
			HttpServletRequest request) throws Exception {
		ModelAndView mav = new ModelAndView();
		log.debug("***MANAGER**  *****DeleteLocation()");
		chargebackManagerForm.setFormParameterMap(request);
		Map searchParametersFromForm = chargebackManagerForm.getMap();

		String locationNumber = (String) request.getParameter("locationNumber");

		log.debug("*****CHARGEBACK MANAGER *****DeleteLocation()");
		chargebackManagerDelegate.deleteLocDetails(locationNumber);

		List searchResults = chargebackManagerDelegate.getLocations();
		chargebackManagerForm.setSearchResults(searchResults);
		if (!errors.isEmpty()) {
			log.debug("FAILED");
			errors.saveMessages(request);
		}
		mav.setViewName(ActionUrlMapping.CHARGEBACKMANAGERACTION.get("cbkLocation"));
		request.setAttribute("actionMessages", errors);
		request.setAttribute("chargebackManagerForm", chargebackManagerForm);
		return mav;

	}

	@RequestMapping(value = "/productGroup", method = { RequestMethod.GET, RequestMethod.POST }, params = {
			"action=product" })
	public ModelAndView product(@ModelAttribute("chargebackManagerForm") ChargebackManagerForm chargebackManagerForm,
			HttpServletRequest request) throws Exception {

		ModelAndView mav = new ModelAndView();
		log.debug("***MANAGER**  *****product()");
		if (request.getParameter("isformreset") != null) {
			chargebackManagerForm.reset(request);
		}

		Map searchParametersFrom = chargebackManagerForm.getMap();
		// Define the display parameters
		int maxRows = 20;
		chargebackManagerForm.setDisplayCount(maxRows);

		// If a message is required, save the specified key(s) into the request.
		if (!errors.isEmpty()) {
			log.debug("FAILED");
			errors.saveMessages(request);
		}

		ResultList searchResults = chargebackManagerDelegate.getProductGroup(searchParametersFrom);
		chargebackManagerForm.setSearchResults(searchResults.getList());

		PageAccessResolver resolver = new PageAccessResolver(request);
		if (resolver.hasAccess()) {
			mav.setViewName(ActionUrlMapping.CHARGEBACKMANAGERACTION.get("productGroup"));
			request.setAttribute("chargebackManagerForm", chargebackManagerForm);
		}

		request.setAttribute("actionMessages", errors);
		return mav;

	}

	@RequestMapping(value = "/productGroup", method = { RequestMethod.GET, RequestMethod.POST }, params = {
			"action=create" })
	public ModelAndView create(@ModelAttribute("chargebackManagerForm") ChargebackManagerForm chargebackManagerForm,
			HttpServletRequest request) throws Exception {
		ModelAndView mav = new ModelAndView();
		log.debug("***MANAGER**  *****create()");
		chargebackManagerForm.setFormParameterMap(request);

		if (!errors.isEmpty()) {
			log.debug("FAILED");
			errors.saveMessages(request);
		}

		mav.setViewName(ActionUrlMapping.CHARGEBACKMANAGERACTION.get("createProduct"));
		request.setAttribute("actionMessages", errors);
		request.setAttribute("chargebackManagerForm", chargebackManagerForm);

		return mav;

	}

	@RequestMapping(value = "/productGroup", method = { RequestMethod.GET, RequestMethod.POST }, params = {
			"action=createNewProduct" })
	public ModelAndView createNewProduct(
			@ModelAttribute("chargebackManagerForm") ChargebackManagerForm chargebackManagerForm,
			HttpServletRequest request) throws Exception {
		ModelAndView mav = new ModelAndView();
		chargebackManagerForm.setFormParameterMap(request);
		log.debug("***MANAGER**  *****createNewProduct()");
		Map searchParametersFromForm = chargebackManagerForm.getMap();
		searchParametersFromForm.put("productCode", chargebackManagerForm.getProductCode());
		searchParametersFromForm.put("description", chargebackManagerForm.getDescription());

		if (!errors.isEmpty()) {
			log.debug("FAILED");
			errors.saveMessages(request);
		}

		chargebackManagerDelegate.InsertProductCode(searchParametersFromForm);

		ResultList searchResults = chargebackManagerDelegate.getProductGroup(searchParametersFromForm);
		chargebackManagerForm.setSearchResults(searchResults.getList());
		int maxRows = 20;
		chargebackManagerForm.setDisplayCount(maxRows);

		mav.setViewName(ActionUrlMapping.CHARGEBACKMANAGERACTION.get("productGroup"));
		request.setAttribute("actionMessages", errors);
		request.setAttribute("chargebackManagerForm", chargebackManagerForm);

		return mav;

	}

	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/editProductGroup", method = { RequestMethod.GET, RequestMethod.POST }, params = {
			"action=edit" })
	public ModelAndView edit(@ModelAttribute("chargebackManagerForm") ChargebackManagerForm chargebackManagerForm,
			HttpServletRequest request) throws Exception {
		ModelAndView mav = new ModelAndView();
		chargebackManagerForm.setFormParameterMap(request);
		log.debug("***** CHARGEBACK MANAGER *****editProductGroup");

		if (!errors.isEmpty()) {
			log.debug("FAILED");
			errors.saveMessages(request);
		}
		Map createParametersFromForm = chargebackManagerForm.getMap();

		String productCode = (String) request.getParameter("selectedUserId");

		ChargebackManagerBO UserBODetails = chargebackManagerDelegate.getProductDetails(productCode);
		chargebackManagerForm.populateFormFromObject(UserBODetails);

		mav.setViewName(ActionUrlMapping.CHARGEBACKMANAGERACTION.get("editProduct"));
		request.setAttribute("actionMessages", errors);
		request.setAttribute("chargebackManagerForm", chargebackManagerForm);

		return mav;

	}

	@RequestMapping(value = "/editProductGroup", method = { RequestMethod.GET, RequestMethod.POST }, params = {
			"action=saveEditProduct" })
	public ModelAndView saveEditProduct(
			@ModelAttribute("chargebackManagerForm") ChargebackManagerForm chargebackManagerForm,
			HttpServletRequest request) throws Exception {
		ModelAndView mav = new ModelAndView();
		chargebackManagerForm.setFormParameterMap(request);
		boolean exceptionOccurred = false;
		log.debug("***** CHARGEBACK MANAGER *****saveEditProduct");
		if (!errors.isEmpty()) {
			log.debug("FAILED");
			errors.saveMessages(request);
		}

		Map searchParametersFromForm = chargebackManagerForm.getMap();

		searchParametersFromForm.put("productCode", chargebackManagerForm.getProductCode());
		searchParametersFromForm.put("description", chargebackManagerForm.getDescription());

		chargebackManagerDelegate.updateProductCode(searchParametersFromForm);

		ResultList searchResults = chargebackManagerDelegate.getProductGroup(searchParametersFromForm);
		chargebackManagerForm.setSearchResults(searchResults.getList());

		mav.setViewName(ActionUrlMapping.CHARGEBACKMANAGERACTION.get("productGroup"));
		request.setAttribute("actionMessages", errors);
		request.setAttribute("chargebackManagerForm", chargebackManagerForm);
		return mav;

	}

	@RequestMapping(value = "/deleteProductGroup", method = { RequestMethod.GET, RequestMethod.POST }, params = {
			"action=deleteProduct" })
	public ModelAndView deleteProduct(
			@ModelAttribute("chargebackManagerForm") ChargebackManagerForm chargebackManagerForm,
			HttpServletRequest request) throws Exception {
		ModelAndView mav = new ModelAndView();

		chargebackManagerForm.setFormParameterMap(request);
		Map searchParametersFromForm = chargebackManagerForm.getMap();
		log.debug("***** CHARGEBACK MANAGER *****deleteProduct");
		String productCode = (String) request.getParameter("productCode");

		chargebackManagerDelegate.deleteProductDetails(productCode);

		// deleteProduct Reference
		productCode = chargebackManagerDelegate.deleteProductGroupCodeReference(productCode);
		chargebackManagerForm.setProductCode(productCode);

		ResultList searchResults = chargebackManagerDelegate.getProductGroup(searchParametersFromForm);
		chargebackManagerForm.setSearchResults(searchResults.getList());

		if (!errors.isEmpty()) {
			log.debug("FAILED");
			errors.saveMessages(request);
		}

		mav.setViewName(ActionUrlMapping.CHARGEBACKMANAGERACTION.get("productGroup"));
		request.setAttribute("actionMessages", errors);
		request.setAttribute("chargebackManagerForm", chargebackManagerForm);
		return mav;

	}

	@RequestMapping(value = "/excludedVendor", method = { RequestMethod.GET, RequestMethod.POST }, params = {
			"action=vendor" })
	public ModelAndView vendor(@ModelAttribute("chargebackManagerForm") ChargebackManagerForm chargebackManagerForm,
			HttpServletRequest request) throws Exception {
		ModelAndView mav = new ModelAndView();
		if (request.getParameter("isformreset") != null) {
			chargebackManagerForm.reset(request);
		}
		Map searchParametersFrom = chargebackManagerForm.getMap();
		log.debug("***** CHARGEBACK MANAGER *****vendor()");
		// If a message is required, save the specified key(s) into the request.
		if (!errors.isEmpty()) {
			log.debug("FAILED");
			errors.saveMessages(request);
		}

		ResultList searchResults = chargebackManagerDelegate.getExcludedVendor(searchParametersFrom);
		chargebackManagerForm.setSearchResults(searchResults.getList());
		PageAccessResolver resolver = new PageAccessResolver(request);
		if (resolver.hasAccess()) {
			mav.setViewName(ActionUrlMapping.CHARGEBACKMANAGERACTION.get("exclVendor"));
			request.setAttribute("chargebackManagerForm", chargebackManagerForm);
		}
		request.setAttribute("actionMessages", errors);
		return mav;
	}

	@RequestMapping(value = "/excludedVendor", method = { RequestMethod.GET, RequestMethod.POST }, params = {
			"action=createVendor" })
	public ModelAndView createVendor(
			@ModelAttribute("chargebackManagerForm") ChargebackManagerForm chargebackManagerForm,
			HttpServletRequest request) throws Exception {
		ModelAndView mav = new ModelAndView();
		log.debug("***** CHARGEBACK MANAGER *****createVendor()");
		chargebackManagerForm.setFormParameterMap(request);

		if (!errors.isEmpty()) {
			log.debug("FAILED");
			errors.saveMessages(request);
		}

		mav.setViewName(ActionUrlMapping.CHARGEBACKMANAGERACTION.get("createVendor"));
		request.setAttribute("actionMessages", errors);
		request.setAttribute("chargebackManagerForm", chargebackManagerForm);

		return mav;
	}

	@RequestMapping(value = "/excludedVendor", method = { RequestMethod.GET, RequestMethod.POST }, params = {
			"action=saveNewProduct" })
	public ModelAndView saveNewProduct(
			@ModelAttribute("chargebackManagerForm") ChargebackManagerForm chargebackManagerForm,
			HttpServletRequest request) throws Exception {
		ModelAndView mav = new ModelAndView();
		chargebackManagerForm.setFormParameterMap(request);
		Map searchParametersFromForm = chargebackManagerForm.getMap();
		log.debug("***** CHARGEBACK MANAGER *****saveNewProduct()");
		searchParametersFromForm.put("vendor", chargebackManagerForm.getVendor());

		// If a message is required, save the specified key(s) into the request.
		if (!errors.isEmpty()) {
			log.debug("FAILED");
			errors.saveMessages(request);
		}
		chargebackManagerDelegate.InsertExcludedVendor(searchParametersFromForm);

		ResultList searchResults = chargebackManagerDelegate.getExcludedVendor(searchParametersFromForm);
		chargebackManagerForm.setSearchResults(searchResults.getList());

		mav.setViewName(ActionUrlMapping.CHARGEBACKMANAGERACTION.get("exclVendor"));
		request.setAttribute("actionMessages", errors);
		request.setAttribute("chargebackManagerForm", chargebackManagerForm);

		return mav;

	}

	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/editExcludedVendor", method = { RequestMethod.GET, RequestMethod.POST }, params = {
			"action=editVendor" })
	public ModelAndView editVendor(@ModelAttribute("chargebackManagerForm") ChargebackManagerForm chargebackManagerForm,
			HttpServletRequest request) throws Exception {
		ModelAndView mav = new ModelAndView();
		chargebackManagerForm.setFormParameterMap(request);
		log.debug("***** CHARGEBACK MANAGER *****editVendor()");

		// If a message is required, save the specified key(s) into the request.
		if (!errors.isEmpty()) {
			log.debug("FAILED");
			errors.saveMessages(request);
		}
		Map createParametersFromForm = chargebackManagerForm.getMap();

		String vendor = (String) request.getParameter("selectedVendor");

		ChargebackManagerBO UserBODetails = chargebackManagerDelegate.getVendorDetails(vendor);
		chargebackManagerForm.populateFormFromObject(UserBODetails);
		mav.setViewName(ActionUrlMapping.CHARGEBACKMANAGERACTION.get("editVendor"));
		request.setAttribute("actionMessages", errors);
		request.setAttribute("chargebackManagerForm", chargebackManagerForm);

		return mav;

	}

	@RequestMapping(value = "/editExcludedVendor", method = { RequestMethod.GET, RequestMethod.POST }, params = {
			"action=saveEditVendor" })
	public ModelAndView saveEditVendor(
			@ModelAttribute("chargebackManagerForm") ChargebackManagerForm chargebackManagerForm,
			HttpServletRequest request) throws Exception {
		ModelAndView mav = new ModelAndView();
		chargebackManagerForm.setFormParameterMap(request);
		if (!errors.isEmpty()) {
			log.debug("FAILED");
			errors.saveMessages(request);
		}
		log.debug("***** CHARGEBACK MANAGER *****saveEditVendor()");
		Map searchParametersFromForm = chargebackManagerForm.getMap();
		searchParametersFromForm.put("vendor", chargebackManagerForm.getVendor());
		searchParametersFromForm.put("oldVendor", chargebackManagerForm.getOldVendorId());
		chargebackManagerDelegate.updateVendor(searchParametersFromForm);

		ResultList searchResults = chargebackManagerDelegate.getExcludedVendor(searchParametersFromForm);
		chargebackManagerForm.setSearchResults(searchResults.getList());

		mav.setViewName(ActionUrlMapping.CHARGEBACKMANAGERACTION.get("exclVendor"));
		request.setAttribute("actionMessages", errors);
		request.setAttribute("chargebackManagerForm", chargebackManagerForm);
		return mav;

	}

	@RequestMapping(value = "/deleteExcludedVendor", method = { RequestMethod.GET, RequestMethod.POST }, params = {
			"action=deleteVendor" })
	public ModelAndView deleteVendor(
			@ModelAttribute("chargebackManagerForm") ChargebackManagerForm chargebackManagerForm,
			HttpServletRequest request) throws Exception {
		ModelAndView mav = new ModelAndView();
		log.debug("***** CHARGEBACK MANAGER *****deleteVendor()");
		chargebackManagerForm.setFormParameterMap(request);
		Map searchParametersFromForm = chargebackManagerForm.getMap();

		String vendor = (String) request.getParameter("vendor");
		chargebackManagerDelegate.deleteExcludedVend(vendor);
		ResultList searchResults = chargebackManagerDelegate.getExcludedVendor(searchParametersFromForm);
		chargebackManagerForm.setSearchResults(searchResults.getList());

		if (!errors.isEmpty()) {
			log.debug("FAILED");
			errors.saveMessages(request);
		}

		mav.setViewName(ActionUrlMapping.CHARGEBACKMANAGERACTION.get("exclVendor"));
		request.setAttribute("actionMessages", errors);
		request.setAttribute("chargebackManagerForm", chargebackManagerForm);
		return mav;

	}

	@RequestMapping(value = "/routeName", method = { RequestMethod.GET, RequestMethod.POST }, params = {
			"action=route" })
	public ModelAndView route(@ModelAttribute("chargebackManagerForm") ChargebackManagerForm chargebackManagerForm,
			HttpServletRequest request) throws Exception {
		ModelAndView mav = new ModelAndView();
		log.debug("***** CHARGEBACK MANAGER *****route()");
		if (request.getParameter("isformreset") != null) {
			chargebackManagerForm.reset(request);
		}

		Map searchParametersFrom = chargebackManagerForm.getMap();

		// If a message is required, save the specified key(s) into the request.
		if (!errors.isEmpty()) {
			log.debug("FAILED");
			errors.saveMessages(request);
		}

		ResultList searchResults = chargebackManagerDelegate.getRouteName(searchParametersFrom);
		chargebackManagerForm.setSearchResults(searchResults.getList());

		PageAccessResolver resolver = new PageAccessResolver(request);
		if (resolver.hasAccess()) {
			mav.setViewName(ActionUrlMapping.CHARGEBACKMANAGERACTION.get("routePage"));
			request.setAttribute("chargebackManagerForm", chargebackManagerForm);
		}
		request.setAttribute("actionMessages", errors);
		return mav;

	}

	@RequestMapping(value = "/routeName", method = { RequestMethod.GET, RequestMethod.POST }, params = {
			"action=createRoute" })
	public ModelAndView createRoute(
			@ModelAttribute("chargebackManagerForm") ChargebackManagerForm chargebackManagerForm,
			HttpServletRequest request) throws Exception {
		ModelAndView mav = new ModelAndView();
		log.debug("***** CHARGEBACK MANAGER *****createRoute()");
		chargebackManagerForm.setFormParameterMap(request);
		Map searchParametersFrom = chargebackManagerForm.getMap();

		ChargebackManagerBO userBODetails = chargebackManagerDelegate.getRouteId(searchParametersFrom);

		// RoutId Auto Generator
		Integer id = Integer.parseInt(userBODetails.getRouteId());
		Integer next_Rout_Id = id + 1;

		chargebackManagerForm.setRouteId(next_Rout_Id.toString());

		log.debug("***** CHARGEBACK MANAGER *****");

		if (!errors.isEmpty()) {
			log.debug("FAILED");
			errors.saveMessages(request);
		}

		mav.setViewName(ActionUrlMapping.CHARGEBACKMANAGERACTION.get("createRoutePage"));
		request.setAttribute("actionMessages", errors);
		request.setAttribute("chargebackManagerForm", chargebackManagerForm);

		return mav;

	}

	@RequestMapping(value = "/routeName", method = { RequestMethod.GET, RequestMethod.POST }, params = {
			"action=saveCreatedRoute" })
	public ModelAndView saveCreatedRoute(
			@ModelAttribute("chargebackManagerForm") ChargebackManagerForm chargebackManagerForm,
			HttpServletRequest request) throws Exception {
		ModelAndView mav = new ModelAndView();
		log.debug("***** CHARGEBACK MANAGER *****saveCreatedRoute()");
		chargebackManagerForm.setFormParameterMap(request);

		Map searchParametersFromForm = chargebackManagerForm.getMap();
		searchParametersFromForm.put("routeId", chargebackManagerForm.getRouteId());
		searchParametersFromForm.put("routeName", chargebackManagerForm.getRouteName());
		if (!errors.isEmpty()) {
			log.debug("FAILED");
			errors.saveMessages(request);
		}

		chargebackManagerDelegate.InsertRouteName(searchParametersFromForm);
		ResultList searchResults = chargebackManagerDelegate.getRouteName(searchParametersFromForm);
		chargebackManagerForm.setSearchResults(searchResults.getList());

		mav.setViewName(ActionUrlMapping.CHARGEBACKMANAGERACTION.get("routePage"));
		request.setAttribute("actionMessages", errors);
		request.setAttribute("chargebackManagerForm", chargebackManagerForm);

		return mav;

	}

	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/editRouteName", method = { RequestMethod.GET, RequestMethod.POST }, params = {
			"action=editRoute" })
	public ModelAndView editRoute(@ModelAttribute("chargebackManagerForm") ChargebackManagerForm chargebackManagerForm,
			HttpServletRequest request) throws Exception {
		ModelAndView mav = new ModelAndView();
		chargebackManagerForm.setFormParameterMap(request);
		log.debug("***** CHARGEBACK MANAGER *****editRoute()");
		// If a message is required, save the specified key(s) into the request.
		if (!errors.isEmpty()) {
			log.debug("FAILED");
			errors.saveMessages(request);
		}
		Map createParametersFromForm = chargebackManagerForm.getMap();

		String routeId = (String) request.getParameter("selectedRouteId");
		ChargebackManagerBO UserBODetails = chargebackManagerDelegate.getRouteDetails(routeId);
		chargebackManagerForm.populateFormFromObject(UserBODetails);
		mav.setViewName(ActionUrlMapping.CHARGEBACKMANAGERACTION.get("editRoute"));
		request.setAttribute("actionMessages", errors);
		request.setAttribute("chargebackManagerForm", chargebackManagerForm);

		return mav;

	}

	@RequestMapping(value = "/editRouteName", method = { RequestMethod.GET, RequestMethod.POST }, params = {
			"action=saveEditRoute" })
	public ModelAndView saveEditRoute(
			@ModelAttribute("chargebackManagerForm") ChargebackManagerForm chargebackManagerForm,
			HttpServletRequest request) throws Exception {
		ModelAndView mav = new ModelAndView();
		chargebackManagerForm.setFormParameterMap(request);
		if (!errors.isEmpty()) {
			log.debug("FAILED");
			errors.saveMessages(request);
		}
		log.debug("***** CHARGEBACK MANAGER *****saveEditRoute()");
		Map searchParametersFromForm = chargebackManagerForm.getMap();

		searchParametersFromForm.put("routeId", chargebackManagerForm.getRouteId());
		searchParametersFromForm.put("routeName", chargebackManagerForm.getRouteName());
		chargebackManagerDelegate.updateRouteName(searchParametersFromForm);
		ResultList searchResults = chargebackManagerDelegate.getRouteName(searchParametersFromForm);
		chargebackManagerForm.setSearchResults(searchResults.getList());

		mav.setViewName(ActionUrlMapping.CHARGEBACKMANAGERACTION.get("routePage"));
		request.setAttribute("actionMessages", errors);
		request.setAttribute("chargebackManagerForm", chargebackManagerForm);
		return mav;

	}

	@RequestMapping(value = "/deleteRouteName", method = { RequestMethod.GET, RequestMethod.POST }, params = {
			"action=deleteRoute" })
	public ModelAndView deleteRoute(
			@ModelAttribute("chargebackManagerForm") ChargebackManagerForm chargebackManagerForm,
			HttpServletRequest request) throws Exception {
		ModelAndView mav = new ModelAndView();
		log.debug("***** CHARGEBACK MANAGER *****deleteRoute()");
		chargebackManagerForm.setFormParameterMap(request);
		Map searchParametersFromForm = chargebackManagerForm.getMap();

		String routeId = (String) request.getParameter("routeId");
		chargebackManagerDelegate.deleteRouteDetails(routeId);

		// delete Reference
		routeId = chargebackManagerDelegate.deleteRouteReference(routeId);
		chargebackManagerForm.setRouteId(routeId);

		ResultList searchResults = chargebackManagerDelegate.getRouteName(searchParametersFromForm);
		chargebackManagerForm.setSearchResults(searchResults.getList());

		// If a message is required, save the specified key(s) into the request.
		if (!errors.isEmpty()) {
			log.debug("FAILED");
			errors.saveMessages(request);
		}

		mav.setViewName(ActionUrlMapping.CHARGEBACKMANAGERACTION.get("routePage"));
		request.setAttribute("actionMessages", errors);
		request.setAttribute("chargebackManagerForm", chargebackManagerForm);
		return mav;

	}

	public static boolean isRowEmpty(Row row) {
		for (int c = row.getFirstCellNum(); c < row.getLastCellNum(); c++) {
			Cell cell = row.getCell(c);
			if (cell != null && cell.getCellType() != Cell.CELL_TYPE_BLANK)
				return false;
		}
		return true;
	}

	/**
	 * 
	 * @param string
	 * @param idNamePattern
	 * @return
	 */

	private boolean validateSpecialCharacters(String string, String idNamePattern) {
		Pattern pattern = Pattern.compile(idNamePattern);

		Matcher matcher = pattern.matcher(string);

		boolean patternFlag = false;

		if (!matcher.matches()) {

			patternFlag = true;
		}

		return patternFlag;
	}

	@RequestMapping(value = "/chargebackManager", method = { RequestMethod.GET, RequestMethod.POST }, params = {
			"action=cbkReasonSearch" })
	public ModelAndView cbkReasonSearch(
			@ModelAttribute("chargebackManagerForm") ChargebackManagerForm chargebackManagerForm,
			HttpServletRequest request) throws Exception {
		ModelAndView mav = new ModelAndView();
		
		chargebackManagerForm.setFormParameterMap(request);

		if (request.getParameter("isformreset") != null) {
			chargebackManagerForm.reset(request);
		}
		String userType = null;
		if (request.getAttribute("userType") != null) {
			userType = (String) request.getAttribute("userType");
		}
		log.debug("*****CHARGEBACK MANAGER *****CbkReasonSearch()");

		Map searchParametersFrom = chargebackManagerForm.getMap();
		if (!errors.isEmpty()) {
			log.debug("FAILED");
			// saveMessages(request, errors);
			errors.saveMessages(request);
		}

		mav.setViewName(ActionUrlMapping.CHARGEBACKMANAGERACTION.get("cbkReasonSearch"));
		request.setAttribute("actionMessages", errors);
		request.setAttribute("chargebackManagerForm", chargebackManagerForm);
		return mav;

	}

	@RequestMapping(value = "/chargebackManager", method = { RequestMethod.GET, RequestMethod.POST }, params = {
			"action=reasonSearchResults" })
	public ModelAndView ReasonSearchResults(
			@ModelAttribute("chargebackManagerForm") ChargebackManagerForm chargebackManagerForm,
			HttpServletRequest request) throws Exception {
		ModelAndView mav = new ModelAndView();
		chargebackManagerForm.setFormParameterMap(request);
		if (request.getParameter("isformreset") != null) {
			chargebackManagerForm.reset(request);
		}
		String userType = null;
		if (request.getAttribute("userType") != null) {
			userType = (String) request.getAttribute("userType");
		}
		Map searchParametersFrom = chargebackManagerForm.getMap();
		log.debug("*****CHARGEBACK MANAGER *****ReasonSearchResults()");

		ResultList searchResults = chargebackManagerDelegate.getReasonResults();
		chargebackManagerForm.setSearchResults(searchResults.getList());

		if (!errors.isEmpty()) {
			log.debug("FAILED");
			// saveMessages(request, errors);
			errors.saveMessages(request);
		}

		mav.setViewName(ActionUrlMapping.CHARGEBACKMANAGERACTION.get("cbkReasonSearch"));
		request.setAttribute("actionMessages", errors);
		request.setAttribute("chargebackManagerForm", chargebackManagerForm);
		return mav;

	}

	@RequestMapping(value = "/chargebackManager", method = { RequestMethod.GET, RequestMethod.POST }, params = {
			"action=createReason" })
	public ModelAndView CreateReason(
			@ModelAttribute("chargebackManagerForm") ChargebackManagerForm chargebackManagerForm,
			HttpServletRequest request) throws Exception {
		ModelAndView mav = new ModelAndView();
		log.debug("*****CHARGEBACK MANAGER *****CreateReason()");
		chargebackManagerForm.setFormParameterMap(request);

		if (request.getParameter("isformreset") != null) {
			chargebackManagerForm.reset(request);
		}
		if (!errors.isEmpty()) {
			log.debug("FAILED");
			// saveMessages(request, errors);
			errors.saveMessages(request);
		}
		mav.setViewName(ActionUrlMapping.CHARGEBACKMANAGERACTION.get("createReason"));
		request.setAttribute("actionMessages", errors);
		request.setAttribute("chargebackManagerForm", chargebackManagerForm);
		return mav;

	}

	@RequestMapping(value = "/chargebackManager", method = { RequestMethod.GET, RequestMethod.POST }, params = {
			"action=saveCreateReason" })
	public ModelAndView SaveCreateReason(
			@ModelAttribute("chargebackManagerForm") ChargebackManagerForm chargebackManagerForm,
			HttpServletRequest request) throws Exception {
		ModelAndView mav = new ModelAndView();
		log.debug("*****CHARGEBACK MANAGER *****SaveCreateReason()");
		chargebackManagerForm.setFormParameterMap(request);
		if (request.getParameter("isformreset") != null) {
			chargebackManagerForm.reset(request);
		}
		Map searchParametersFromForm = chargebackManagerForm.getMap();

		if (!errors.isEmpty()) {
			log.debug("FAILED"); // saveMessages(request, errors);
			errors.saveMessages(request);
		}
		searchParametersFromForm.put("chargebackreason", chargebackManagerForm.getChargebackReason());
		searchParametersFromForm.put("accountNumber", chargebackManagerForm.getAccountNumber());
		searchParametersFromForm.put("eDICode", chargebackManagerForm.geteDICode());
// BalanceSheet
		if (chargebackManagerForm.getBalanceSheet() == null)
			searchParametersFromForm.put("balanceSheet", "0");
		else
			searchParametersFromForm.put("balanceSheet", "1");
// Active
		if (chargebackManagerForm.getActive() == null)
			searchParametersFromForm.put("active", "-1");
		else
			searchParametersFromForm.put("active", "1");

		chargebackManagerDelegate.saveCreateReason(searchParametersFromForm);

		ResultList searchResults = chargebackManagerDelegate.getReasonResults();
		chargebackManagerForm.setSearchResults(searchResults.getList());

		mav.setViewName(ActionUrlMapping.CHARGEBACKMANAGERACTION.get("cbkReasonSearch"));
		request.setAttribute("actionMessages", errors);
		request.setAttribute("chargebackManagerForm", chargebackManagerForm);
		return mav;

	}

	@RequestMapping(value = "/chargebackManager", method = { RequestMethod.GET, RequestMethod.POST }, params = {
			"action=editReason" })
	public ModelAndView EditReason(@ModelAttribute("chargebackManagerForm") ChargebackManagerForm chargebackManagerForm,
			HttpServletRequest request) throws Exception {
		ModelAndView mav = new ModelAndView();
		log.debug("*****CHARGEBACK MANAGER *****EditReason()");
		chargebackManagerForm.setFormParameterMap(request);

		Map searchParametersFromForm = chargebackManagerForm.getMap();

		String chargebackReason = (String) request.getParameter("chargebackReason");
		ChargebackManagerBO reasonBODetails = chargebackManagerDelegate.getReasonDetails(chargebackReason);
		chargebackManagerForm.populateFormFromObject(reasonBODetails);

		if (!errors.isEmpty()) {
			log.debug("FAILED");
			errors.saveMessages(request);
		}

		mav.setViewName(ActionUrlMapping.CHARGEBACKMANAGERACTION.get("editReason"));
		request.setAttribute("actionMessages", errors);
		request.setAttribute("chargebackManagerForm", chargebackManagerForm);
		return mav;

	}

	@RequestMapping(value = "/chargebackManager", method = { RequestMethod.GET, RequestMethod.POST }, params = {
			"action=updateReason" })
	public ModelAndView updateReason(
			@ModelAttribute("chargebackManagerForm") ChargebackManagerForm chargebackManagerForm,
			HttpServletRequest request) throws Exception {
		ModelAndView mav = new ModelAndView();
		log.debug("*****CHARGEBACK MANAGER *****updateReason()");
		chargebackManagerForm.setFormParameterMap(request);

		if (request.getParameter("isformreset") != null) {
			chargebackManagerForm.reset(request);
		}

		Map searchParametersFromForm = chargebackManagerForm.getMap();

		if (!errors.isEmpty()) {
			log.debug("FAILED"); // saveMessages(request, errors);
			errors.saveMessages(request);
		}

		searchParametersFromForm.put("chargebackreason", chargebackManagerForm.getChargebackReason());
		searchParametersFromForm.put("accountNumber", chargebackManagerForm.getAccountNumber());
		searchParametersFromForm.put("eDICode", chargebackManagerForm.geteDICode());
		if (chargebackManagerForm.getBalanceSheet() == null)
			searchParametersFromForm.put("balanceSheet", "0");
		else
			searchParametersFromForm.put("balanceSheet", "1");
		if (chargebackManagerForm.getActive() == null)
			searchParametersFromForm.put("active", "-1");
		else
			searchParametersFromForm.put("active", "0");

		chargebackManagerDelegate.updateReason(searchParametersFromForm);
		ResultList searchResults = chargebackManagerDelegate.getReasonResults();
		chargebackManagerForm.setSearchResults(searchResults.getList());

		mav.setViewName(ActionUrlMapping.CHARGEBACKMANAGERACTION.get("cbkReasonSearch"));
		request.setAttribute("actionMessages", errors);
		request.setAttribute("chargebackManagerForm", chargebackManagerForm);
		return mav;
	}

	@RequestMapping(value = "/chargebackManager", method = { RequestMethod.GET, RequestMethod.POST }, params = {
			"action=deleteReason" })
	public ModelAndView DeleteReason(
			@ModelAttribute("chargebackManagerForm") ChargebackManagerForm chargebackManagerForm,
			HttpServletRequest request) throws Exception {
		ModelAndView mav = new ModelAndView();
		log.debug("*****CHARGEBACK MANAGER *****DeleteReason()");
		chargebackManagerForm.setFormParameterMap(request);

		Map searchParametersFromForm = chargebackManagerForm.getMap();

		String chargebackReason = (String) request.getParameter("chargebackReason");

		chargebackManagerDelegate.deleteReasonDetails(chargebackReason);

		ResultList searchResults = chargebackManagerDelegate.getReasonResults();
		chargebackManagerForm.setSearchResults(searchResults.getList());

		if (!errors.isEmpty()) {
			log.debug("FAILED");
			// saveMessages(request, errors);
			errors.saveMessages(request);
		}

		mav.setViewName(ActionUrlMapping.CHARGEBACKMANAGERACTION.get("cbkReasonSearch"));
		request.setAttribute("actionMessages", errors);
		request.setAttribute("chargebackManagerForm", chargebackManagerForm);
		return mav;

	}

	@RequestMapping(value = "/chargebackManager", method = { RequestMethod.GET, RequestMethod.POST }, params = {
			"action=cbkAuthorizationByType" })
	public ModelAndView CbkAuthorizationByType(
			@ModelAttribute("chargebackManagerForm") ChargebackManagerForm chargebackManagerForm,
			HttpServletRequest request) throws Exception {
		ModelAndView mav = new ModelAndView();
		log.debug("*****CHARGEBACK MANAGER *****CbkAuthorizationByType()");
		chargebackManagerForm.setFormParameterMap(request);

		if (request.getParameter("isformreset") != null) {
			chargebackManagerForm.reset(request);
		}

		List cbkAllTypes = chargebackManagerDelegate.getAllTypes();
		chargebackManagerForm.setCbkAllTypes(cbkAllTypes);

//If a message is required, save the specified key(s) into the request.
		if (!errors.isEmpty()) {
			log.debug("FAILED");
			// saveMessages(request, errors);
			errors.saveMessages(request);
		}

//Finish with
//return (forward);
		mav.setViewName(ActionUrlMapping.CHARGEBACKMANAGERACTION.get("cbkByType"));
		request.setAttribute("actionMessages", errors);
		request.setAttribute("chargebackManagerForm", chargebackManagerForm);
		return mav;
	}

	@RequestMapping(value = "/chargebackManager", method = { RequestMethod.GET, RequestMethod.POST }, params = {
			"action=cbkAuthTypeResults" })
	public ModelAndView CbkAuthTypeResults(
			@ModelAttribute("chargebackManagerForm") ChargebackManagerForm chargebackManagerForm,
			HttpServletRequest request) throws Exception {
		ModelAndView mav = new ModelAndView();
		log.debug("*****CHARGEBACK MANAGER *****CbkAuthTypeResults()");
		chargebackManagerForm.setFormParameterMap(request);

		if (request.getParameter("isformreset") != null) {
			chargebackManagerForm.reset(request);
		}
		List cbkAllTypes = chargebackManagerDelegate.getAllTypes();
		chargebackManagerForm.setCbkAllTypes(cbkAllTypes);

		boolean exceptionOccurred = false;
		Map searchParametersFrom = chargebackManagerForm.getMap();
		String chargebackType = request.getParameter("typeId");
		String[] row = chargebackType.split(",");
		String typeId = row[0];
		String typeName = row[1];
		chargebackManagerForm.setTypeId(typeId);
		chargebackManagerForm.setTypeName(typeName);

		searchParametersFrom.put("typeId", typeId);
		ResultList searchResults = chargebackManagerDelegate.getTypeDetails(searchParametersFrom);
		chargebackManagerForm.setSearchResults(searchResults.getList());

//If a message is required, save the specified key(s) into the request.
		if (!errors.isEmpty()) {
			log.debug("FAILED");
			// saveMessages(request, errors);
			errors.saveMessages(request);
		}

//Finish with
//return (forward);
		mav.setViewName(ActionUrlMapping.CHARGEBACKMANAGERACTION.get("cbkByType"));
		request.setAttribute("actionMessages", errors);
		request.setAttribute("chargebackManagerForm", chargebackManagerForm);
		return mav;
	}

	@RequestMapping(value = "/chargebackManager", method = { RequestMethod.GET, RequestMethod.POST }, params = {
			"action=createAmountByType" })
	public ModelAndView CreateAmountByType(
			@ModelAttribute("chargebackManagerForm") ChargebackManagerForm chargebackManagerForm,
			HttpServletRequest request) throws Exception {
		ModelAndView mav = new ModelAndView();
		log.debug("*****CHARGEBACK MANAGER *****CreateAmountByType()");
		chargebackManagerForm.setFormParameterMap(request);
		Map searchParametersFrom = chargebackManagerForm.getMap();

		String chargebackType = request.getParameter("typeId");
		String chargebackTypeName = request.getParameter("typeName");

		String[] row = chargebackType.split(",");
		String typeId = row[0];
		String typeName = row[1];

		chargebackManagerForm.setTypeId(typeId);
		chargebackManagerForm.setTypeName(typeName);

		if (request.getParameter("isformreset") != null) {
			chargebackManagerForm.reset(request);
		}

		boolean exceptionOccurred = false;
		List roles = chargebackManagerDelegate.getAllRoles();
		chargebackManagerForm.setSearchResults(roles);

//If a message is required, save the specified key(s) into the request.
		if (!errors.isEmpty()) {
			log.debug("FAILED");
			// saveMessages(request, errors);
			errors.saveMessages(request);
		}
//Finish with
//return (forward);
// request.setAttribute("chargebackManagerForm", chargebackType);
		mav.setViewName(ActionUrlMapping.CHARGEBACKMANAGERACTION.get("createByType"));
		request.setAttribute("actionMessages", errors);
		request.setAttribute("chargebackManagerForm", chargebackManagerForm);
		return mav;

	}

	@RequestMapping(value = "/chargebackManager", method = { RequestMethod.GET, RequestMethod.POST }, params = {
			"action=saveAmountByType" })
	public ModelAndView SaveAmountByType(
			@ModelAttribute("chargebackManagerForm") ChargebackManagerForm chargebackManagerForm,
			HttpServletRequest request) throws Exception {
		ModelAndView mav = new ModelAndView();

		chargebackManagerForm.setFormParameterMap(request);
		boolean exceptionOccurred = false;

		log.debug("*****CHARGEBACK MANAGER *****SaveAmountByType()");
		List cbkAllTypes = chargebackManagerDelegate.getAllTypes();
		chargebackManagerForm.setCbkAllTypes(cbkAllTypes);

		Map searchParametersForm = chargebackManagerForm.getMap();
		String roleId = request.getParameter("roleId");
		String maxAmount = request.getParameter("maxAmount");

		if (!errors.isEmpty()) {
			log.debug("FAILED"); // saveMessages(request, errors);
			errors.saveMessages(request);
		}
		searchParametersForm.put("roleId", chargebackManagerForm.getRoleId());
		searchParametersForm.put("typeId", chargebackManagerForm.getTypeId());
		searchParametersForm.put("maxAmount", chargebackManagerForm.getMaxAmount());
		chargebackManagerDelegate.saveAmountByType(searchParametersForm);

		mav.setViewName(ActionUrlMapping.CHARGEBACKMANAGERACTION.get("cbkByType"));
		request.setAttribute("actionMessages", errors);
		request.setAttribute("chargebackManagerForm", chargebackManagerForm);
		return mav;

	}

	@RequestMapping(value = "/chargebackManager", method = { RequestMethod.GET, RequestMethod.POST }, params = {
			"action=editAmountByType" })
	public ModelAndView EditAmountByType(
			@ModelAttribute("chargebackManagerForm") ChargebackManagerForm chargebackManagerForm,
			HttpServletRequest request) throws Exception {
		ModelAndView mav = new ModelAndView();
		log.debug("*****CHARGEBACK MANAGER *****EditAmountByType()");
		chargebackManagerForm.setFormParameterMap(request);

		Map searchParametersForm = chargebackManagerForm.getMap();
		String roleId = (String) request.getParameter("roleId");

		String chargebackType = request.getParameter("typeId");
		String[] row = chargebackType.split(",");
		String typeId = row[0];
		String typeName = row[1];
		chargebackManagerForm.setTypeId(typeId);
		chargebackManagerForm.setTypeName(typeName);

		List cbkAllTypes = chargebackManagerDelegate.getAllTypes();
		chargebackManagerForm.setCbkAllTypes(cbkAllTypes);

		boolean exceptionOccurred = false;

		if (!errors.isEmpty()) {
			log.debug("FAILED");
			errors.saveMessages(request);
		}
		searchParametersForm.put("typeId", typeId);
		searchParametersForm.put("roleId", roleId);

		ChargebackManagerBO editTypeBODetails = chargebackManagerDelegate.getEditType(searchParametersForm);
		chargebackManagerForm.populateFormFromObject(editTypeBODetails);

		ResultList searchResults = chargebackManagerDelegate.getTypeDetails(searchParametersForm);
		chargebackManagerForm.setSearchResults(searchResults.getList());

		mav.setViewName(ActionUrlMapping.CHARGEBACKMANAGERACTION.get("editType"));
		request.setAttribute("actionMessages", errors);
		request.setAttribute("chargebackManagerForm", chargebackManagerForm);
		return mav;

	}

	@RequestMapping(value = "/chargebackManager", method = { RequestMethod.GET, RequestMethod.POST }, params = {
			"action=updateAmountByType" })
	public ModelAndView UpdateAmountByType(
			@ModelAttribute("chargebackManagerForm") ChargebackManagerForm chargebackManagerForm,
			HttpServletRequest request) throws Exception {
		ModelAndView mav = new ModelAndView();
		
		chargebackManagerForm.setFormParameterMap(request);

		if (request.getParameter("isformreset") != null) {
			chargebackManagerForm.reset(request);
		}

		boolean exceptionOccurred = false;

		log.debug("*****CHARGEBACK MANAGER *****UpdateAmountByType()");

		Map searchParametersForm = chargebackManagerForm.getMap();
		List cbkAllTypes = chargebackManagerDelegate.getAllTypes();
		chargebackManagerForm.setCbkAllTypes(cbkAllTypes);

		if (!errors.isEmpty()) {
			log.debug("FAILED"); // saveMessages(request, errors);
			errors.saveMessages(request);
		}
		searchParametersForm.put("roleId", chargebackManagerForm.getRoleId());
		searchParametersForm.put("maxAmount", chargebackManagerForm.getMaxAmount());
		searchParametersForm.put("typeId", chargebackManagerForm.getTypeId());

		chargebackManagerDelegate.updateAmountByType(searchParametersForm);

		ResultList searchResults = chargebackManagerDelegate.getTypeDetails(searchParametersForm);
		chargebackManagerForm.setSearchResults(searchResults.getList());

		mav.setViewName(ActionUrlMapping.CHARGEBACKMANAGERACTION.get("cbkByType"));
		request.setAttribute("actionMessages", errors);
		request.setAttribute("chargebackManagerForm", chargebackManagerForm);
		return mav;
	}

	@RequestMapping(value = "/chargebackManager", method = { RequestMethod.GET, RequestMethod.POST }, params = {
			"action=deleteAmountByType" })
	public ModelAndView DeleteAmountByType(
			@ModelAttribute("chargebackManagerForm") ChargebackManagerForm chargebackManagerForm,
			HttpServletRequest request) throws Exception {
		ModelAndView mav = new ModelAndView();

		chargebackManagerForm.setFormParameterMap(request);
		Map searchParametersForm = chargebackManagerForm.getMap();

		String chargebackType = request.getParameter("typeId");
		String[] row = chargebackType.split(",");
		String typeId = row[0];
		String typeName = row[1];
		chargebackManagerForm.setTypeId(typeId);
		chargebackManagerForm.setTypeName(typeName);

		boolean exceptionOccurred = false;

		log.debug("*****CHARGEBACK MANAGER *****DeleteAmountByType()");
		List cbkAllTypes = chargebackManagerDelegate.getAllTypes();
		chargebackManagerForm.setCbkAllTypes(cbkAllTypes);

		String roleId = (String) request.getParameter("roleId");

		if (!errors.isEmpty()) {
			log.debug("FAILED");
			// saveMessages(request, errors);
			errors.saveMessages(request);
		}
		chargebackManagerDelegate.deleteAmountByType(roleId);

		searchParametersForm.put("typeId", typeId);
		searchParametersForm.put("roleId", roleId);

		ResultList searchResults = chargebackManagerDelegate.getTypeDetails(searchParametersForm);
		chargebackManagerForm.setSearchResults(searchResults.getList());

		mav.setViewName(ActionUrlMapping.CHARGEBACKMANAGERACTION.get("cbkByType"));
		request.setAttribute("actionMessages", errors);
		request.setAttribute("chargebackManagerForm", chargebackManagerForm);
		return mav;

	}

	@RequestMapping(value = "/chargebackManager", method = { RequestMethod.GET, RequestMethod.POST }, params = {
			"action=cbkAuthorizationRole" })
	public ModelAndView CbkRoles(@ModelAttribute("chargebackManagerForm") ChargebackManagerForm chargebackManagerForm,
			HttpServletRequest request) throws Exception {
		ModelAndView mav = new ModelAndView();
		log.debug("*****CHARGEBACK MANAGER *****CbkRoles()");
		chargebackManagerForm.setFormParameterMap(request);

		if (request.getParameter("isformreset") != null) {
			chargebackManagerForm.reset(request);
		}

		if (!errors.isEmpty()) {
			log.debug("FAILED");
			// saveMessages(request, errors);
			errors.saveMessages(request);
		}

		List allRoles = chargebackManagerDelegate.getRoles();
		chargebackManagerForm.setAllRoles(allRoles);
		mav.setViewName(ActionUrlMapping.CHARGEBACKMANAGERACTION.get("searchCbkRole"));
		request.setAttribute("actionMessages", errors);
		request.setAttribute("chargebackManagerForm", chargebackManagerForm);
		return mav;

	}

	@RequestMapping(value = "/chargebackManager", method = { RequestMethod.GET, RequestMethod.POST }, params = {
			"action=cbkAuthorizationRoleResults" })
	public ModelAndView cbkAuthorizationRoleResults(
			@ModelAttribute("chargebackManagerForm") ChargebackManagerForm chargebackManagerForm,
			HttpServletRequest request) throws Exception {
		ModelAndView mav = new ModelAndView();
		log.debug("*****CHARGEBACK MANAGER *****cbkAuthorizationRoleResults()");
		chargebackManagerForm.setFormParameterMap(request);

		if (request.getParameter("isformreset") != null) {
			chargebackManagerForm.reset(request);
		}

		Map searchParametersFrom = chargebackManagerForm.getMap();

		String role = request.getParameter("roleId");
		String[] row = role.split(",");
		String roleId = row[0];
		String roles = row[1];
		chargebackManagerForm.setRoleId(roleId);
		chargebackManagerForm.setRoles(roles);

		searchParametersFrom.put("roleId", roleId);

		// If a message is required, save the specified key(s) into the request.
		if (!errors.isEmpty()) {
			log.debug("FAILED");
			// saveMessages(request, errors);
			errors.saveMessages(request);
		}
		// Roles
		searchParametersFrom.put("roles", chargebackManagerForm.getRoles());
		searchParametersFrom.put("roleId", chargebackManagerForm.getRoleId());

		ResultList searchResults = chargebackManagerDelegate.getAuthAmount(searchParametersFrom);
		chargebackManagerForm.setSearchResults(searchResults.getList());

		// Grtting Roles
		List allRoles = chargebackManagerDelegate.getRoles();
		chargebackManagerForm.setAllRoles(allRoles);

		mav.setViewName(ActionUrlMapping.CHARGEBACKMANAGERACTION.get("searchCbkRole"));
		request.setAttribute("actionMessages", errors);
		request.setAttribute("chargebackManagerForm", chargebackManagerForm);

		return mav;

	}

	@RequestMapping(value = "/chargebackManager", method = { RequestMethod.GET, RequestMethod.POST }, params = {
			"action=createByRole" })
	public ModelAndView CreateByRole(
			@ModelAttribute("chargebackManagerForm") ChargebackManagerForm chargebackManagerForm,
			HttpServletRequest request) throws Exception {
		ModelAndView mav = new ModelAndView();
		log.debug("*****CHARGEBACK MANAGER *****CreateByRole()");
		chargebackManagerForm.setFormParameterMap(request);
		Map searchParametersFrom = chargebackManagerForm.getMap();
		if (request.getParameter("isformreset") != null) {
			chargebackManagerForm.reset(request);
		}

		if (!errors.isEmpty()) {
			log.debug("FAILED");
			// saveMessages(request, errors);
			errors.saveMessages(request);
		}

		String role = request.getParameter("roleId");
		String[] row = role.split(",");
		String roleId = row[0];
		String roles = row[1];
		chargebackManagerForm.setRoleId(roleId);
		chargebackManagerForm.setRoles(roles);

		searchParametersFrom.put("roleId", roleId);

		mav.setViewName(ActionUrlMapping.CHARGEBACKMANAGERACTION.get("createByRole"));
		request.setAttribute("actionMessages", errors);
		request.setAttribute("chargebackManagerForm", chargebackManagerForm);
		request.setAttribute("chargebackTypes", chargebackManagerDelegate.getChargeTypes());
		return mav;

	}

	@RequestMapping(value = "/chargebackManager", method = { RequestMethod.GET, RequestMethod.POST }, params = {
			"action=saveCreateByRole" })
	public ModelAndView SaveCreateByRole(
			@ModelAttribute("chargebackManagerForm") ChargebackManagerForm chargebackManagerForm,
			HttpServletRequest request) throws Exception {
		ModelAndView mav = new ModelAndView();
		log.debug("*****CHARGEBACK MANAGER *****SaveCreateByRole()");
		chargebackManagerForm.setFormParameterMap(request);

		if (request.getParameter("isformreset") != null) {
			chargebackManagerForm.reset(request);
		}

		Map searchParametersFromForm = chargebackManagerForm.getMap();

		if (!errors.isEmpty()) {
			log.debug("FAILED"); // saveMessages(request, errors);
			errors.saveMessages(request);
		}

		searchParametersFromForm.put("typeId", chargebackManagerForm.getTypeId());
		searchParametersFromForm.put("authorize", chargebackManagerForm.getAuthorize());
		searchParametersFromForm.put("roleId", chargebackManagerForm.getRoleId());
		searchParametersFromForm.put("roles", chargebackManagerForm.getRoles());

		chargebackManagerDelegate.InsertCbkByRole(searchParametersFromForm);

		// Grtting Roles
		List allRoles = chargebackManagerDelegate.getRoles();
		chargebackManagerForm.setAllRoles(allRoles);

		ResultList searchResults = chargebackManagerDelegate.getAuthAmount(searchParametersFromForm);
		chargebackManagerForm.setSearchResults(searchResults.getList());

		mav.setViewName(ActionUrlMapping.CHARGEBACKMANAGERACTION.get("searchCbkRole"));
		request.setAttribute("actionMessages", errors);
		request.setAttribute("chargebackManagerForm", chargebackManagerForm);
		return mav;

	}

	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/editRole", method = { RequestMethod.GET, RequestMethod.POST }, params = {
			"action=editByRole" })
	public ModelAndView editByRole(@ModelAttribute("chargebackManagerForm") ChargebackManagerForm chargebackManagerForm,
			HttpServletRequest request) throws Exception {
		ModelAndView mav = new ModelAndView();
		chargebackManagerForm.setFormParameterMap(request);
		log.debug("*****CHARGEBACK MANAGER *****editByRole()");
		// If a message is required, save the specified key(s) into the request.

		boolean exceptionOccurred = false;
		if (!errors.isEmpty()) {
			log.debug("FAILED");
			errors.saveMessages(request);
		}

		Map searchParametersFrom = chargebackManagerForm.getMap();
		String typeId = (String) request.getParameter("selectedcbkType");

		String role = (String) request.getParameter("roleId");

		String[] row = role.split(",");
		String roleId = row[0];
		String roles = row[1];
		chargebackManagerForm.setRoleId(roleId);
		chargebackManagerForm.setRoles(roles);

		searchParametersFrom.put("roleId", roleId);
		searchParametersFrom.put("typeId", typeId);

		ChargebackManagerBO UserBODetails = chargebackManagerDelegate.getAuthRoleDetails(searchParametersFrom);
		chargebackManagerForm.populateForm(UserBODetails);

		mav.setViewName(ActionUrlMapping.CHARGEBACKMANAGERACTION.get("editByRoel"));
		request.setAttribute("actionMessages", errors);
		request.setAttribute("chargebackManagerForm", chargebackManagerForm);

		return mav;

	}

	@RequestMapping(value = "/editRole", method = { RequestMethod.GET, RequestMethod.POST }, params = {
			"action=saveEditRole" })
	public ModelAndView saveEditRole(
			@ModelAttribute("chargebackManagerForm") ChargebackManagerForm chargebackManagerForm,
			HttpServletRequest request) throws Exception {
		ModelAndView mav = new ModelAndView();
		chargebackManagerForm.setFormParameterMap(request);
		log.debug("*****CHARGEBACK MANAGER *****saveEditRole()");
		boolean exceptionOccurred = false;

		if (!errors.isEmpty()) {
			log.debug("FAILED");
			errors.saveMessages(request);
		}

		Map searchParametersFromForm = chargebackManagerForm.getMap();
		String typeId = request.getParameter("typeId");

		searchParametersFromForm.put("chargebackType", chargebackManagerForm.getChargebackType());
		searchParametersFromForm.put("authorize", chargebackManagerForm.getAuthorize());
		searchParametersFromForm.put("roles", chargebackManagerForm.getRoles());
		searchParametersFromForm.put("roleId", chargebackManagerForm.getRoleId());
		searchParametersFromForm.put("typeId", chargebackManagerForm.getTypeId());

		chargebackManagerDelegate.updateAuthByRole(searchParametersFromForm);

		// Grtting Roles
		List allRoles = chargebackManagerDelegate.getRoles();
		chargebackManagerForm.setAllRoles(allRoles);

		ResultList searchResults = chargebackManagerDelegate.getAuthAmount(searchParametersFromForm);
		chargebackManagerForm.setSearchResults(searchResults.getList());

		mav.setViewName(ActionUrlMapping.CHARGEBACKMANAGERACTION.get("searchCbkRole"));
		request.setAttribute("actionMessages", errors);
		request.setAttribute("chargebackManagerForm", chargebackManagerForm);
		return mav;

	}

	@RequestMapping(value = "/deleteAuthRole", method = { RequestMethod.GET, RequestMethod.POST }, params = {
			"action=deleteRole" })
	public ModelAndView deleteRole(@ModelAttribute("chargebackManagerForm") ChargebackManagerForm chargebackManagerForm,
			HttpServletRequest request) throws Exception {
		ModelAndView mav = new ModelAndView();
		log.debug("*****CHARGEBACK MANAGER *****deleteRole()");
		chargebackManagerForm.setFormParameterMap(request);
		Map searchParametersFromForm = chargebackManagerForm.getMap();

		String typeId = request.getParameter("typeId");
		String role = request.getParameter("roleId");

		String[] row = role.split(",");
		String roleId = row[0];
		String roles = row[1];
		chargebackManagerForm.setRoleId(roleId);
		chargebackManagerForm.setRoles(roles);

		searchParametersFromForm.put("roleId", roleId);
		searchParametersFromForm.put("typeId", typeId);

		chargebackManagerDelegate.deleteAuthRoleDetails(searchParametersFromForm);

		// Grtting Roles
		List allRoles = chargebackManagerDelegate.getRoles();
		chargebackManagerForm.setAllRoles(allRoles);

		ResultList searchResults = chargebackManagerDelegate.getAuthAmount(searchParametersFromForm);
		chargebackManagerForm.setSearchResults(searchResults.getList());
		// If a message is required, save the specified key(s) into the request.
		if (!errors.isEmpty()) {
			log.debug("FAILED");
			errors.saveMessages(request);
		}

		mav.setViewName(ActionUrlMapping.CHARGEBACKMANAGERACTION.get("searchCbkRole"));
		request.setAttribute("actionMessages", errors);
		request.setAttribute("chargebackManagerForm", chargebackManagerForm);
		return mav;

	}

	@RequestMapping(value = "/chargebackDefinition", method = { RequestMethod.GET, RequestMethod.POST }, params = {
			"action=chargeDef" })
	public ModelAndView chargeDef(@ModelAttribute("chargebackManagerForm") ChargebackManagerForm chargebackManagerForm,
			HttpServletRequest request) throws Exception {

		ModelAndView mav = new ModelAndView();

		if (request.getParameter("isformreset") != null) {
			chargebackManagerForm.reset(request);
		}

		String userType = null;
		if (request.getAttribute("userType") != null) {
			userType = (String) request.getAttribute("userType");
		}
		boolean exceptionOccurred = false;

		log.debug("***** CHARGEBACK MANAGER ****chargeDef()*");
		Map searchParametersFrom = chargebackManagerForm.getMap();

// If a message is required, save the specified key(s) into the request.
		if (!errors.isEmpty()) {
			log.debug("FAILED");
			errors.saveMessages(request);
		}

		ResultList searchResults = chargebackManagerDelegate.getChargeDefinition(searchParametersFrom);
		chargebackManagerForm.setCbkDefinition(searchResults.getList());

		PageAccessResolver resolver = new PageAccessResolver(request);
		if (resolver.hasAccess()) {
			mav.setViewName(ActionUrlMapping.CHARGEBACKMANAGERACTION.get("chargebackDef"));
			request.setAttribute("chargebackManagerForm", chargebackManagerForm);

		}

		request.setAttribute("actionMessages", errors);
		return mav;

	}

	@RequestMapping(value = "/updateChargeDefinition", method = { RequestMethod.GET, RequestMethod.POST }, params = {
			"action=updateChargeDef" })
	public ModelAndView updateChargeDef(
			@ModelAttribute("chargebackManagerForm") ChargebackManagerForm chargebackManagerForm,
			HttpServletRequest request) throws Exception {
		ModelAndView mav = new ModelAndView();
		chargebackManagerForm.setFormParameterMap(request);

		boolean exceptionOccurred = false;

		log.debug("***** CHARGEBACK MANAGER *****updateChargeDef()");
		if (!errors.isEmpty()) {
			log.debug("FAILED");
			errors.saveMessages(request);
		}

		List<ChargebackManagerBO> cbkDefList = chargebackManagerForm.getCbkDefinitionList();

		List cbkDefFianlList = new ArrayList();

		Map searchParametersFromForm = chargebackManagerForm.getMap();

		Map m = null;
		ChargebackManagerBO cbkMngrBO = null;

		for (int i = 0; i < cbkDefList.size(); i++) {

			m = new HashMap();
			cbkMngrBO = (ChargebackManagerBO) cbkDefList.get(i);

			m.put("typeId", cbkMngrBO.getTypeId());

			// UploadAp
			if (cbkMngrBO.getUploadAp() == null || cbkMngrBO.getUploadAp().equals("-1")) {
				m.put("uploadAp", -1);
			} else {
				m.put("uploadAp", 0);
			}
			// AccountRequired
			if (cbkMngrBO.getAccountReq() == null || cbkMngrBO.getAccountReq().equals("-1"))
				m.put("accountReq", -1);
			else
				m.put("accountReq", 0);

			// VendorReq
			if (cbkMngrBO.getVendorReq() == null)
				m.put("vendorReq", -1);
			else
				m.put("vendorReq", 0);

			// Credit
			if (cbkMngrBO.getCredit() == null)
				m.put("credit", -1);
			else
				m.put("credit", 0);

			// UploadFood
			if (cbkMngrBO.getUploadFood() == null)
				m.put("uploadFood", -1);
			else
				m.put("uploadFood", 0);

			// Selectable
			if (cbkMngrBO.getSelectable() == null)
				m.put("selectable", -1);
			else
				m.put("selectable", 0);
			cbkDefFianlList.add(m);
		}

		chargebackManagerDelegate.updateChargeDefinition(cbkDefFianlList);

		chargebackManagerForm.reset(request);
		ResultList searchResults = chargebackManagerDelegate.getChargeDefinition(m);
		// chargebackManagerForm.setSearchResults(searchResults.getList());
		chargebackManagerForm.setCbkDefinition(searchResults.getList());

		mav.setViewName(ActionUrlMapping.CHARGEBACKMANAGERACTION.get("chargebackDef"));
		request.setAttribute("actionMessages", errors);
		request.setAttribute("chargebackManagerForm", chargebackManagerForm);
		return mav;

	}

	@RequestMapping(value = "/chargebackManager", method = { RequestMethod.GET, RequestMethod.POST }, params = {
			"action=routeAppr" })
	public ModelAndView RouteAppr(@ModelAttribute("chargebackManagerForm") ChargebackManagerForm chargebackManagerForm,
			HttpServletRequest request) throws Exception {
		ModelAndView mav = new ModelAndView();

		chargebackManagerForm.setFormParameterMap(request);

		if (request.getParameter("isformreset") != null) {
			chargebackManagerForm.reset(request);
		}

		boolean exceptionOccurred = false;

		log.debug("*****CHARGEBACK MANAGER *****RouteAppr()");

		Map searchParametersFrom = chargebackManagerForm.getMap();

		if (!errors.isEmpty()) {
			log.debug("FAILED"); // saveMessages(request, errors);
			errors.saveMessages(request);
		}
		ResultList routeTypes = chargebackManagerDelegate.getRouteName(searchParametersFrom);
		chargebackManagerForm.setRouteTypes(routeTypes.getList());

		mav.setViewName(ActionUrlMapping.CHARGEBACKMANAGERACTION.get("routeAppr"));
		request.setAttribute("actionMessages", errors);
		request.setAttribute("chargebackManagerForm", chargebackManagerForm);
		return mav;

	}

	@RequestMapping(value = "/chargebackManager", method = { RequestMethod.GET, RequestMethod.POST }, params = {
			"action=routeApprResults" })
	public ModelAndView RouteApprResults(
			@ModelAttribute("chargebackManagerForm") ChargebackManagerForm chargebackManagerForm,
			HttpServletRequest request) throws Exception {
		ModelAndView mav = new ModelAndView();
		chargebackManagerForm.setFormParameterMap(request);

		Map searchParametersFromForm = chargebackManagerForm.getMap();
		boolean exceptionOccurred = false;
		if (!errors.isEmpty()) {
			log.debug("FAILED"); // saveMessages(request, errors);
			errors.saveMessages(request);
		}
		String chargebackRoute = request.getParameter("routeId");

		String[] row = chargebackRoute.split(",");
		String routeId = row[0];
		String routeName = row[1];
		chargebackManagerForm.setRouteId(routeId);
		chargebackManagerForm.setRouteName(routeName);

		log.debug("*****CHARGEBACK MANAGER *****RouteApprResults()");
		searchParametersFromForm.put("routeId", chargebackManagerForm.getRouteId());
		searchParametersFromForm.put("routeName", chargebackManagerForm.getRouteName());

		ResultList searchResults = chargebackManagerDelegate.getRoutingDetails(searchParametersFromForm);
		chargebackManagerForm.setSearchResults(searchResults.getList());
//Get All RouteTypes
		ResultList routeTypes = chargebackManagerDelegate.getRouteName(searchParametersFromForm);
		chargebackManagerForm.setRouteTypes(routeTypes.getList());

		mav.setViewName(ActionUrlMapping.CHARGEBACKMANAGERACTION.get("routeAppr"));
		request.setAttribute("actionMessages", errors);
		request.setAttribute("chargebackManagerForm", chargebackManagerForm);
		return mav;

	}

	@RequestMapping(value = "/chargebackManager", method = { RequestMethod.GET, RequestMethod.POST }, params = {
			"action=createRoutingAppr" })
	public ModelAndView CreateRoutingAppr(
			@ModelAttribute("chargebackManagerForm") ChargebackManagerForm chargebackManagerForm,
			HttpServletRequest request) throws Exception {
		ModelAndView mav = new ModelAndView();
		log.debug("***** CHARGEBACK MANAGER *****CreateRoutingAppr()");
		chargebackManagerForm.setFormParameterMap(request);
		Map searchParametersFrom = chargebackManagerForm.getMap();

		if (request.getParameter("isformreset") != null) {
			chargebackManagerForm.reset(request);
		}

		boolean exceptionOccurred = false;
		String chargebackRoute = request.getParameter("routeId");

		String[] row = chargebackRoute.split(",");
		String routeId = row[0];
		String routeName = row[1];
		chargebackManagerForm.setRouteId(routeId);
		chargebackManagerForm.setRouteName(routeName);

		if (!errors.isEmpty()) {
			log.debug("FAILED"); // saveMessages(request, errors);
			errors.saveMessages(request);
		}
//All Roles
		List roles = chargebackManagerDelegate.getAllRoles();
		chargebackManagerForm.setSearchResults(roles);

		mav.setViewName(ActionUrlMapping.CHARGEBACKMANAGERACTION.get("createRoutingAppr"));
		request.setAttribute("actionMessages", errors);
		request.setAttribute("chargebackManagerForm", chargebackManagerForm);
		return mav;

	}

	@RequestMapping(value = "/chargebackManager", method = { RequestMethod.GET, RequestMethod.POST }, params = {
			"action=saveCreateRouting" })
	public ModelAndView SaveCreateRouting(
			@ModelAttribute("chargebackManagerForm") ChargebackManagerForm chargebackManagerForm,
			HttpServletRequest request) throws Exception {
		ModelAndView mav = new ModelAndView();

		chargebackManagerForm.setFormParameterMap(request);

		if (request.getParameter("isformreset") != null) {
			chargebackManagerForm.reset(request);
		}

		boolean exceptionOccurred = false;

		log.debug("*****CHARGEBACK MANAGER *****SaveCreateRouting()");

		Map searchParametersForm = chargebackManagerForm.getMap();

		if (!errors.isEmpty()) {
			log.debug("FAILED"); // saveMessages(request, errors);
			errors.saveMessages(request);
		}

		searchParametersForm.put("routeId", chargebackManagerForm.getRouteId());
		searchParametersForm.put("stepNumber", chargebackManagerForm.getStepNumber());
		searchParametersForm.put("roleId", chargebackManagerForm.getRoleId());
		searchParametersForm.put("amountFloor", chargebackManagerForm.getAmountFloor());
		
		if (chargebackManagerForm.getNotify() == null)
			searchParametersForm.put("notify", "1");
		else
			searchParametersForm.put("notify", "-1");

		chargebackManagerDelegate.saveCreateRouting(searchParametersForm);

		ResultList routeTypes = chargebackManagerDelegate.getRouteName(searchParametersForm);
		chargebackManagerForm.setRouteTypes(routeTypes.getList());

		ResultList searchResults = chargebackManagerDelegate.getRoutingDetails(searchParametersForm);
		chargebackManagerForm.setSearchResults(searchResults.getList());
		mav.setViewName(ActionUrlMapping.CHARGEBACKMANAGERACTION.get("routeAppr"));
		request.setAttribute("actionMessages", errors);
		request.setAttribute("chargebackManagerForm", chargebackManagerForm);
		return mav;

	}

	@RequestMapping(value = "/chargebackManager", method = { RequestMethod.GET, RequestMethod.POST }, params = {
			"action=editRoutingAppr" })
	public ModelAndView EditRoutingAppr(
			@ModelAttribute("chargebackManagerForm") ChargebackManagerForm chargebackManagerForm,
			HttpServletRequest request) throws Exception {
		ModelAndView mav = new ModelAndView();

		chargebackManagerForm.setFormParameterMap(request);
		log.debug("***** CHARGEBACK MANAGER *****EditRoutingAppr()");
		Map searchParametersFromForm = chargebackManagerForm.getMap();

		String stepNumber = (String) request.getParameter("stepNumber");
		String chargebackRoute = request.getParameter("routeId");

		String[] row = chargebackRoute.split(",");
		String routeId = row[0];
		String routeName = row[1];
		chargebackManagerForm.setRouteId(routeId);
		chargebackManagerForm.setRouteName(routeName);
		searchParametersFromForm.put("routeId", routeId);
		searchParametersFromForm.put("stepNumber", stepNumber);

		ChargebackManagerBO editRoutingBODetails = chargebackManagerDelegate
				.getEditRoutingAppr(searchParametersFromForm);
		chargebackManagerForm.populateFormForEditRouting(editRoutingBODetails);
		boolean exceptionOccurred = false;

		if (!errors.isEmpty()) {
			log.debug("FAILED");
			errors.saveMessages(request);
		}
		List roles = chargebackManagerDelegate.getAllRoles();
		chargebackManagerForm.setSearchResults(roles);

		ResultList routeTypes = chargebackManagerDelegate.getRouteName(searchParametersFromForm);
		chargebackManagerForm.setRouteTypes(routeTypes.getList());

		mav.setViewName(ActionUrlMapping.CHARGEBACKMANAGERACTION.get("editRoutingAppr"));
		request.setAttribute("actionMessages", errors);
		request.setAttribute("chargebackManagerForm", chargebackManagerForm);
		return mav;

	}

	@RequestMapping(value = "/chargebackManager", method = { RequestMethod.GET, RequestMethod.POST }, params = {
			"action=updateRoutingAppr" })
	public ModelAndView UpdateRoutingAppr(
			@ModelAttribute("chargebackManagerForm") ChargebackManagerForm chargebackManagerForm,
			HttpServletRequest request) throws Exception {
		ModelAndView mav = new ModelAndView();

		chargebackManagerForm.setFormParameterMap(request);

		if (request.getParameter("isformreset") != null) {
			chargebackManagerForm.reset(request);
		}

		boolean exceptionOccurred = false;

		log.debug("*****CHARGEBACK MANAGER *****UpdateAmountByType()");

		Map searchParametersForm = chargebackManagerForm.getMap();

		if (!errors.isEmpty()) {
			log.debug("FAILED"); // saveMessages(request, errors);
			errors.saveMessages(request);
		}
		searchParametersForm.put("routeId", chargebackManagerForm.getRouteId());
		searchParametersForm.put("oldStepNumber", chargebackManagerForm.getOldStepNumber());
		searchParametersForm.put("stepNumber", chargebackManagerForm.getStepNumber());
		searchParametersForm.put("roleId", chargebackManagerForm.getRoleId());
		searchParametersForm.put("amountFloor", chargebackManagerForm.getAmountFloor());
		if (chargebackManagerForm.getNotify() == null)
			searchParametersForm.put("notify", "1");
		else
			searchParametersForm.put("notify", "-1");

		chargebackManagerDelegate.updateRouting(searchParametersForm);

		ResultList searchResults = chargebackManagerDelegate.getRoutingDetails(searchParametersForm);
		chargebackManagerForm.setSearchResults(searchResults.getList());

		ResultList routeTypes = chargebackManagerDelegate.getRouteName(searchParametersForm);
		chargebackManagerForm.setRouteTypes(routeTypes.getList());

		mav.setViewName(ActionUrlMapping.CHARGEBACKMANAGERACTION.get("routeAppr"));
		request.setAttribute("actionMessages", errors);
		request.setAttribute("chargebackManagerForm", chargebackManagerForm);
		return mav;
	}

	@RequestMapping(value = "/chargebackManager", method = { RequestMethod.GET, RequestMethod.POST }, params = {
			"action=deleteRoutingAppr" })
	public ModelAndView DeleteRoutingAppr(
			@ModelAttribute("chargebackManagerForm") ChargebackManagerForm chargebackManagerForm,
			HttpServletRequest request) throws Exception {
		ModelAndView mav = new ModelAndView();

		chargebackManagerForm.setFormParameterMap(request);

		Map searchParametersFromForm = chargebackManagerForm.getMap();

		// searchParametersFromForm.put("stepNumber",
		// chargebackManagerForm.getStepNumber());
		String stepNumber = (String) request.getParameter("stepNumber");
		String chargebackRoute = request.getParameter("routeId");

		String[] row = chargebackRoute.split(",");
		String routeId = row[0];
		String routeName = row[1];
		chargebackManagerForm.setRouteId(routeId);
		chargebackManagerForm.setRouteName(routeName);
		boolean exceptionOccurred = false;
		log.debug("*****CHARGEBACK MANAGER *****DeleteRoutingAppr()");

		if (!errors.isEmpty()) {
			log.debug("FAILED");
			// saveMessages(request, errors);
			errors.saveMessages(request);
		}
		searchParametersFromForm.put("routeId", routeId);
		searchParametersFromForm.put("stepNumber", stepNumber);
		chargebackManagerDelegate.deleteRouting(searchParametersFromForm);

		ResultList searchResults = chargebackManagerDelegate.getRoutingDetails(searchParametersFromForm);
		chargebackManagerForm.setSearchResults(searchResults.getList());

		ResultList routeTypes = chargebackManagerDelegate.getRouteName(searchParametersFromForm);
		chargebackManagerForm.setRouteTypes(routeTypes.getList());

		mav.setViewName(ActionUrlMapping.CHARGEBACKMANAGERACTION.get("routeAppr"));
		request.setAttribute("actionMessages", errors);
		request.setAttribute("chargebackManagerForm", chargebackManagerForm);
		return mav;

	}

	@RequestMapping(value = "/regionalAdministration", method = { RequestMethod.GET, RequestMethod.POST }, params = {
			"action=regionalAdmin" })
	public ModelAndView regionalAdmin(
			@ModelAttribute("chargebackManagerForm") ChargebackManagerForm chargebackManagerForm,
			HttpServletRequest request) throws Exception {
		ModelAndView mav = new ModelAndView();
		chargebackManagerForm.setFormParameterMap(request);
		log.debug("***** CHARGEBACK MANAGER *****regionalAdmin()");
		if (request.getParameter("isformreset") != null) {
			chargebackManagerForm.reset(request);
		}

		boolean exceptionOccurred = false;

		if (!errors.isEmpty()) {
			log.debug("FAILED");
			// saveMessages(request, errors);
			errors.saveMessages(request);
		}

		List allRoles = chargebackManagerDelegate.getRoles();
		chargebackManagerForm.setAllRoles(allRoles);
		mav.setViewName(ActionUrlMapping.CHARGEBACKMANAGERACTION.get("managerUserSearch"));
		request.setAttribute("actionMessages", errors);
		request.setAttribute("chargebackManagerForm", chargebackManagerForm);

		return mav;

	}

	@RequestMapping(value = "/managerSearchResults", method = { RequestMethod.GET, RequestMethod.POST })
	public ModelAndView execute(@ModelAttribute("chargebackManagerForm") ChargebackManagerForm chargebackManagerForm,
			HttpServletRequest request) throws Exception {

		ModelAndView mav = new ModelAndView();

		if (request.getParameter("isformreset") != null) {
			chargebackManagerForm.reset(request);
		}

		boolean exceptionOccurred = false;

		log.debug("***** CHARGEBACK Manager *****managerSearchResults***execute()");
		Map searchParametersFrom = chargebackManagerForm.getMap();
		// Define the display parameters
		int maxRows = 20;
		chargebackManagerForm.setDisplayCount(maxRows);

		if (chargebackManagerForm.isShowAll()) {
			searchParametersFrom.put("showAll", "true");
		} else {
			searchParametersFrom.put("rowStart", new Integer(chargebackManagerForm.getCurrentRecord()));
			searchParametersFrom.put("rowEnd", new Integer(chargebackManagerForm.getCurrentRecord() + maxRows - 1));
		}
		// If a message is required, save the specified key(s) into the request.
		if (!errors.isEmpty()) {
			log.debug("FAILED");
			// saveMessages(request, errors);
			errors.saveMessages(request);
		}
		String location = null;

		if (chargebackManagerForm.getLocation() != null) {
			location = chargebackManagerForm.getLocation();
		}
		if (request.getParameter("location") != null) {
			location = request.getParameter("location");
		}

		// Location
		if (chargebackManagerForm.getLocation() != null && chargebackManagerForm.getLocationNumber() != "") {
			if (("2").equals(chargebackManagerForm.getLocation()) && chargebackManagerForm.getLocationNumber() != "") {
				searchParametersFrom.put("location", chargebackManagerForm.getLocation());
				searchParametersFrom.put("locationNumber", chargebackManagerForm.getLocationNumber().substring(0, 2));
			}
		}

		// Roles
		if (chargebackManagerForm.getRoles() != null) {
			if (chargebackManagerForm.getRoles() != null && chargebackManagerForm.getRoles().equals("1")) {
				chargebackManagerForm.setRoleSelected("");
			}
			searchParametersFrom.put("roleSelected", chargebackManagerForm.getRoleSelected());
		}

		// userId - Originator
		if (chargebackManagerForm.getOriginator() != null && !chargebackManagerForm.getOriginator().isEmpty()) {
			searchParametersFrom.put("userId", chargebackManagerForm.getOriginator());
		}

		// Status
		searchParametersFrom.put("status", chargebackManagerForm.getStatus());
		if (chargebackManagerForm.getStatus() != null) {
			if (chargebackManagerForm.getStatus() != null && chargebackManagerForm.getStatus().equals("1")) {
				chargebackManagerForm.setStatusSelected("");
			}
			searchParametersFrom.put("statusSelected", chargebackManagerForm.getStatusSelected());
		}

		ResultList searchResults = null;
		if ((("".equals(chargebackManagerForm.getLocationNumber()) || chargebackManagerForm.getLocationNumber() == null)
				&& ("".equals(chargebackManagerForm.getRoleSelected())
						|| chargebackManagerForm.getRoleSelected() == null))
				&& ("".equals(chargebackManagerForm.getOriginator())
						|| chargebackManagerForm.getOriginator() == null)) {
			searchResults = chargebackManagerDelegate.allUsers(searchParametersFrom);
		} else if (((chargebackManagerForm.getLocationNumber().isEmpty()
				|| chargebackManagerForm.getLocationNumber() == null)
				&& (chargebackManagerForm.getRoleSelected().isEmpty()
						|| chargebackManagerForm.getRoleSelected() == null))
				&& chargebackManagerForm.getOriginator() != null) {
			searchResults = chargebackManagerDelegate.specificUserSearch(searchParametersFrom);
		} else if (((chargebackManagerForm.getLocationNumber().isEmpty()
				|| chargebackManagerForm.getLocationNumber() == null)
				&& (chargebackManagerForm.getOriginator() == null || chargebackManagerForm.getOriginator().isEmpty()))
				&& chargebackManagerForm.getRoleSelected() != null) {
			searchResults = chargebackManagerDelegate.specificRoleIdSearch(searchParametersFrom);
		} else {
			searchResults = chargebackManagerDelegate.specificUserResults(searchParametersFrom);
		}

		chargebackManagerForm.setSearchResults(searchResults.getList());
		chargebackManagerForm.setTotalRecords(searchResults.getTotalCount().intValue());

		PageAccessResolver resolver = new PageAccessResolver(request);
		if (resolver.hasAccess()) {
			mav.setViewName(ActionUrlMapping.CHARGEBACKMANAGERACTION.get("managerUsers"));
			request.setAttribute("chargebackManagerForm", chargebackManagerForm);
		}

		// Finish with
		request.setAttribute("actionMessages", errors);//

		return mav;
	}

	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/getmanagerUserDetails", method = { RequestMethod.GET, RequestMethod.POST }, params = {
			"action=managerUserDetails" })
	public ModelAndView managerUserDetails(
			@ModelAttribute("chargebackManagerForm") ChargebackManagerForm chargebackManagerForm,
			HttpServletRequest request) throws Exception {
		ModelAndView mav = new ModelAndView();
		HttpSession session = request.getSession();
		chargebackManagerForm.setFormParameterMap(request);
		log.debug("***** CHARGEBACK MANAGER ***managerUserDetails**");

// If a message is required, save the specified key(s) into the request.
		if (!errors.isEmpty()) {
			log.debug("FAILED");
			errors.saveMessages(request);
		}
		Map createParametersFromForm = chargebackManagerForm.getMap();

		List locations = chargebackManagerDelegate.getLocationsForCreateUser();
		chargebackManagerForm.setLocations(locations);

		List rolesId = chargebackManagerDelegate.getRolesForUser();
		chargebackManagerForm.setRolesId(rolesId);

		String userId = (String) request.getParameter("selectedUserId");

		ChargebackManagerBO UserBODetails = chargebackManagerDelegate.getUserDetails(userId);
		chargebackManagerForm.populate(UserBODetails);

		// Get the search results based on the parameters in the form
		ResultList searchResults = chargebackManagerDelegate.getUserRolesLocations(userId);

		List l = (List) searchResults.getList();// DELETE IT

		ChargebackManagerBO cbkbo = new ChargebackManagerBO();
		// DELETE IT
		for (int i = 0; i < l.size(); i++) {
			cbkbo = (ChargebackManagerBO) l.get(i);
		}

		// BUILD SEPERATE LISTS FOR MENUACCESS AND LOCATIONROLES
		Map map = new HashMap();
		map = SeperateRolesFromMenuAccess((List) searchResults.getList());

		List LocationRolesList = (List) map.get("LocRole");
		chargebackManagerForm.setLocationRoles(LocationRolesList);

		// createNewUserForm.setLocationRoles(searchResults.getList());

		List MenuAccessList = (List) map.get("MenuAccess");
		chargebackManagerForm.setMenuAccess(MenuAccessList);

		List rolesByUserForMenuList = chargebackManagerDelegate.getRolesByUserForMenu();
		chargebackManagerForm.setRolesByUserForMenuList(rolesByUserForMenuList);

		mav.setViewName(ActionUrlMapping.CHARGEBACKMANAGERACTION.get("managerUserDetails"));
		request.setAttribute("actionMessages", errors);
		request.setAttribute("chargebackManagerForm", chargebackManagerForm);
		return mav;

	}

	public Map SeperateRolesFromMenuAccess(List resultList) {
		Map m = new HashMap();
		List MenuAccessList = new ArrayList();
		List LocRolesList = new ArrayList();

		for (int i = 0; i < resultList.size(); i++) {
			ChargebackManagerBO cbkbo = new ChargebackManagerBO();
			cbkbo = (ChargebackManagerBO) resultList.get(i);
			if (cbkbo.getDistLocNumber().equals("999") || cbkbo.getDistLocNumber().equals("888")) {
				MenuAccessList.add(cbkbo.getDistRoles());
			} else {
				LocRolesList.add(cbkbo);

			}
		}
		m.put("MenuAccess", MenuAccessList);
		m.put("LocRole", LocRolesList);

		return m;
	}
	
	/**
	 * 
	 * @param chargebackManagerForm
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */

	@RequestMapping(value = "/workWithApproveChargebacks", method = { RequestMethod.GET, RequestMethod.POST }, params = {
			"action=forwardSel" })
	public ModelAndView forwardSel(@ModelAttribute("chargebackManagerForm") ChargebackManagerForm chargebackManagerForm,
			HttpServletRequest request, HttpServletResponse response) throws Exception {
		chargebackManagerForm.setFormParameterMap(request);
		ModelAndView mav = new ModelAndView();
		log.debug("***** WORK WITH CHARGEBACKS  APPROVE ***forwardSel()*");

		try {
			String invoiceNumber = request.getParameter("invoiceNumber");
			String locationNumber = request.getParameter("locationNumber");
			String originalApprover = request.getParameter("originalApprover");

			HttpSession session = request.getSession();
			String SmUserId = (String) session.getAttribute("SmUserId");

			//String maxStepNumber = null;
			String stepNumber = null;
			String typeId = null;
			String approver = null;

			String creatorId = null;
			if (request.getParameter("creatorId") != null) {
				creatorId = request.getParameter("creatorId");
			}
			String app = null;
			if (request.getParameter("app") != null) {
				approver = request.getParameter("app");

			}
			
			if (request.getParameter("typeId") != null) {
				typeId = request.getParameter("typeId");
			}
			
			stepNumber = chargebackSearchDelegate.getMinStepNumberWithInvoiceAmount(invoiceNumber,locationNumber,typeId);
			//maxStepNumber = chargebackSearchDelegate.getMaxStepNumberWithInvoiceAmount(invoiceNumber, locationNumber,typeId);


			ChargebackBO cbkBo = new ChargebackBO();
			// Call the common method to return the list
			cbkBo.setInvoiceNumber(invoiceNumber);
			cbkBo.setLocationNumber(locationNumber);
			cbkBo.setApproverId(SmUserId);
			cbkBo.setStepNumber(stepNumber);
			cbkBo.setApprovalDate(new Date());
			cbkBo.setNextAproverId(approver);

			// cbkBo.setInterInstr(interInstr);
			// chargebackSearchDelegate.updateChargebackDenyReason(cbkBo);

			chargebackSearchDelegate.updateChargebackApprover(cbkBo);

			// Perform the APPROVE (INSERT)
			chargebackSearchDelegate.approveChargebacks(cbkBo);

			// AFTER APPROVE PULL THE AVAILABLE CHARGEBACKS

			Map<String, Comparable> searchParametersFromForm = chargebackManagerForm.getMap();
			searchParametersFromForm.put("userId", SmUserId);

			// Define the display parameters
			int maxRows = 20;
			chargebackManagerForm.setDisplayCount(maxRows);

			if (chargebackManagerForm.isShowAll()) {
				searchParametersFromForm.put("showAll", "true");
			} else {
				searchParametersFromForm.put("rowStart", new Integer(chargebackManagerForm.getCurrentRecord()));
				searchParametersFromForm.put("rowEnd",
						new Integer(chargebackManagerForm.getCurrentRecord() + maxRows - 1));
			}
			
			ResultList searchResults = chargebackManagerDelegate.getChargebacks(searchParametersFromForm);

			// Populate the 'searchResults' property in the ActionForm
			chargebackManagerForm.setSearchResults(searchResults.getList());
			chargebackManagerForm.setTotalRecords(searchResults.getTotalCount().intValue());

			messages.saveMessages(request);

			PageAccessResolver resolver = new PageAccessResolver(request);
			if (resolver.hasAccess()) {
				mav.setViewName(ActionUrlMapping.CHARGEBACKMANAGERACTION.get("workWithChargebackResults"));
				request.setAttribute("actionMessages", errors);
				request.setAttribute("chargebackManagerForm", chargebackManagerForm);
				return mav;
			}
			} catch (Exception e) {
				e.printStackTrace();
				mav.setViewName(ActionUrlMapping.GLOBAL.get(Constants.ACTION_FAILURE));
				log.error("Exception in execute:" + e);
			}
			mav.setViewName(ActionUrlMapping.CHARGEBACKMANAGERACTION.get("other"));
			request.setAttribute("actionMessages", messages);
			request.setAttribute("chargebackManagerForm", chargebackManagerForm);
			return mav;

	}

	
	
	
	@RequestMapping(value = "/getWorkWithChargebackDetails", method = { RequestMethod.GET, RequestMethod.POST })
	public ModelAndView details(@ModelAttribute("chargebackManagerForm")ChargebackManagerForm chargebackManagerForm,
			HttpServletRequest request) throws Exception {
		ModelAndView mav = new ModelAndView();
		log.debug("***** WORKWITH CHARGEBACK DETAIL-  details()*****");
		chargebackManagerForm.setFormParameterMap(request);
		boolean exceptionOccurred = false;
		String invoiceNumber = null;
		String vendorId = null;
		List<ChargebackManagerBO> fileNames = null;
		HttpSession session = request.getSession();
		String SmUserId = (String) session.getAttribute("SmUserId");
		boolean isEditable = false;
		String editableInvoiceStatus = null;
		String maxStepForInvoice = null;
		String typeId = null;
		String roleIdNextApprover = null;
		String stepNumber = null;
		String originalApprover = null;
		try {

			if (request.getParameter("invoiceNbr") != null) {
				invoiceNumber = request.getParameter("invoiceNbr");
			}

			if (request.getParameter("vendorId") != null) {
				vendorId = request.getParameter("vendorId");
			}

			if (request.getParameter("origApprover") != null) {
				originalApprover = request.getParameter("origApprover");
			}
			System.out.println("--originalApprover---"+originalApprover);
			chargebackManagerForm.setOriginalApprover(originalApprover);
			chargebackManagerForm.setMaxStepForInvoice(chargebackManagerDelegate.getMaxStepNumberForInvoice(invoiceNumber));

			String locationNumber = request.getParameter("locationNumber");
			Map<String, Comparable> updateParametersFromForm = chargebackManagerForm.getMap();
			updateParametersFromForm.put("locationNumber", locationNumber);
			updateParametersFromForm.put("vendorId", vendorId);
			updateParametersFromForm.put("invoiceNumber", invoiceNumber);

			// Get the ChargebackType list
			List<ChargebackManagerBO> chargebackTypes = chargebackManagerDelegate.getChargebackTypes();
			chargebackManagerForm.setChargebackTypes(chargebackTypes);

			// Get the Reasons list
			List<ChargebackManagerBO> reasons = chargebackManagerDelegate.getReasons();
			chargebackManagerForm.setReasons(reasons);

			// Get the Product group list
			List<ChargebackManagerBO> productGroup = chargebackManagerDelegate.getProductGroup();
			chargebackManagerForm.setProductGroups(productGroup);
			// Get the vendor informaton
			ChargebackManagerBO vendorInfo = chargebackManagerDelegate.getChargebackVendor(updateParametersFromForm);
			if (vendorInfo != null) {
				chargebackManagerForm.populateFormFromObjectVendor(chargebackManagerForm, vendorInfo);
			}

			ChargebackManagerBO cbkBo = chargebackManagerDelegate.getChargebackDetailInfo(updateParametersFromForm);
			chargebackManagerForm.populateFormFromWorkWithObject(cbkBo);
			updateParametersFromForm.put("locationNumber", cbkBo.getLocationNumber());
			// Get the search results based on the parameters in the form
			ResultList searchResults = chargebackManagerDelegate.getCbkDetTable(updateParametersFromForm);
			// Populate the 'searchResults' property in the ActionForm
			// chargebackManagerForm.setDetailResults(searchResults.getList());
			chargebackManagerForm.setGlItems(searchResults.getList());
			// Get the search results based on the parameters in the form
			ResultList distibutionResults = chargebackManagerDelegate
					.getChargebackDistribution(updateParametersFromForm);
			chargebackManagerForm.setSlItems(distibutionResults.getList());

			stepNumber = chargebackManagerDelegate.getMinStepNumberWithInvoiceAmount(invoiceNumber,
					cbkBo.getLocationNumber(), cbkBo.getTypeId().toString());

			chargebackManagerForm.setStepNumber(stepNumber);


			// showing approval history
			ResultList approvalHistory = chargebackManagerDelegate.getApprovalHistory(invoiceNumber);

			chargebackManagerForm.setApprovalHistoryList(approvalHistory.getList());

			// Attachement code

			fileNames = chargebackManagerDelegate.getAttachmentName(chargebackManagerForm.getInvoiceNumber());
			for (ChargebackManagerBO fileName : fileNames) {

				chargebackManagerForm.setAttachmentName(String.valueOf(fileName.getAttachmentName()));
				chargebackManagerForm.setAttachmentType(fileName.getAttachmentType());
			}

			// Check the eligibilit of approver
			if (SmUserId != null && cbkBo.getTypeId() != null) {
				roleIdNextApprover = chargebackManagerDelegate.getRoleIdForNextApprover(invoiceNumber,
						cbkBo.getTypeId().toString(), cbkBo.getLocationNumber(), SmUserId);
				log.debug("role id of next approver" + roleIdNextApprover);
			}

			if ((cbkBo.getApprover() != null && !cbkBo.getApprover().equals(SmUserId) && roleIdNextApprover == null)) {
				chargebackManagerForm.setNotAnApprover("notAnApprover");
				log.debug("******User is not an approver*******");
			} else {
				chargebackManagerForm.setNotAnApprover("");

				log.debug("******User is approver*******");
			}

			// Check the eligiblity of edit option

			// Get the user roles based on decide he is admin or not
			String adminUser = chargebackManagerDelegate.getAdminUser(SmUserId, "-5");

			// Get approval status
			ResultList approverStatusResults = chargebackManagerDelegate.getChargebackApprovalStatus(invoiceNumber,
					SmUserId);
			List approverStatusList = (List) approverStatusResults.getList();// DELETE IT
			ChargebackManagerBO cbkApproverStatusBO = new ChargebackManagerBO();
			// DELETE IT
			for (int i = 0; i < approverStatusList.size(); i++) {
				cbkApproverStatusBO = (ChargebackManagerBO) approverStatusList.get(i);
			}

			boolean isApproved;

			if (approverStatusList.size() == 0) {
				// not received any approval as of now
				isApproved = false;

			} else {
				// has at least one approval
				isApproved = true;

			}


			// Role ID -1 is admin
			if (adminUser != null) {
				isEditable = true;
				log.debug("--********Admin Editable*******--");
			}
			// Creator of the Chargeback
			else if (cbkBo.getCreatorId().equals(SmUserId)) {

				if (isApproved) {
					isEditable = false;
					log.debug("--********Creator not Editable*******--" + cbkBo.getCreatorId()
							+ " default user id" + SmUserId);
				} else {
					isEditable = true;
					log.debug("--********Creator Editable*******--");
				}

			} // Approver of the Chargeback
			else if (cbkBo.getApprover() != null && cbkBo.getApprover().equals(SmUserId)) {
				isEditable = true;
				log.debug("--********Approver Editable*******--");
			} //Another user has same role logged in user 
			else if (roleIdNextApprover != null) {
				isEditable = true;
				log.debug("--******User has same role******--");
	
			}else {
				isEditable = false;
				log.debug("--********others not Editable*******--");
			}
			
			
			
			editableInvoiceStatus = chargebackManagerDelegate.getInvoiceEditableStatus(invoiceNumber);

			if (!(isEditable && editableInvoiceStatus != null)) {
				chargebackManagerForm.setNotEditable("notEditable");
			} else {
				chargebackManagerForm.setNotEditable("");
			}

		} catch (Exception e) {
			exceptionOccurred = true;
			e.printStackTrace();
			mav.setViewName(ActionUrlMapping.GLOBAL.get(Constants.ACTION_FAILURE));
			log.error("Exception in execute:" + e);
		}

		PageAccessResolver resolver = new PageAccessResolver(request);
		if (resolver.hasAccess() && !exceptionOccurred) {
			mav.setViewName(ActionUrlMapping.CHARGEBACKMANAGERACTION.get("workWithCbkDetails"));
			request.setAttribute("actionMessages", messages);
			// return mapping.findForward("success");
			return mav;
		}
		mav.setViewName(ActionUrlMapping.CHARGEBACKDETAILSACTIONS.get("other"));
		// return mapping.findForward("other");
		request.setAttribute("actionMessages", messages);
		request.setAttribute("chargebackManagerForm", chargebackManagerForm);
		return mav;

	}
}
