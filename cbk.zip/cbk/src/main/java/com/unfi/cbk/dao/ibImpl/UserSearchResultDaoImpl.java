package com.unfi.cbk.dao.ibImpl;

import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.orm.ibatis.SqlMapClientTemplate;
import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;

import com.unfi.cbk.beans.ResultList;
import com.unfi.cbk.dao.UserSearchResultDao;
import com.unfi.cbk.exceptions.DataAccessException;

/**
 * The UserSearchResultDaoImpl class implements the generic UserSearchResultDao
 * interface.
 * 
 * @author vpil001
 *
 */

public class UserSearchResultDaoImpl extends SqlMapClientDaoSupport implements UserSearchResultDao {

	private static Logger log = Logger.getLogger(UserSearchResultDaoImpl.class);

	public UserSearchResultDaoImpl(SqlMapClientTemplate sqlMapTemplate) {
		this.setSqlMapClientTemplate(sqlMapTemplate);
	}

	@Override
	public ResultList allUsers(Map map) throws DataAccessException {
		// TODO Auto-generated method stub
		ResultList rL = new ResultList();

		try {
			System.out.println("------userResultsDaoImpl.java-------allUsers()------");
			rL.setList((List) getSqlMapClientTemplate().queryForList("UserSearchResult.allUsers", map));
			System.out.println("------------UsersResultsDaoImpl.java--ResultList size----" + rL.getList().size());
			if (rL.getList().size() == 0) {
				rL.setTotalCount(new Integer(0));
			} else if (map.get("showAll") != null && ((String) map.get("showAll")).equals("true")) {
				rL.setTotalCount(new Integer(rL.getList().size()));
			} else {
				rL.setTotalCount(
						(Integer) getSqlMapClientTemplate().queryForObject("UserSearchResult.allUsersCount", map));
			}

		} catch (Exception e) {
			log.error("Error in allUsers() " + e);
			e.printStackTrace();
			throw new DataAccessException(e);
		}

		return rL;
	}

	@Override
	public ResultList specificUserResults(Map map) throws DataAccessException {
		// TODO Auto-generated method stub
		ResultList rL = new ResultList();

		try {

			System.out.println("------userResultsDaoImpl.java-------specificUserResults()------");
			rL.setList((List) getSqlMapClientTemplate().queryForList("UserSearchResult.specificUserResults", map));
			System.out.println("------------UsersResultsDaoImpl.java--specificUserResults()--ResultList size----" + rL.getList().size());
			if (rL.getList().size() == 0) {
				rL.setTotalCount(new Integer(0));
			} else if (map.get("showAll") != null && ((String) map.get("showAll")).equals("true")) {
				rL.setTotalCount(new Integer(rL.getList().size()));
			} else {
				rL.setTotalCount(
						(Integer) getSqlMapClientTemplate().queryForObject("UserSearchResult.specificUserResultsCount", map));
			}

		} catch (Exception e) {
			log.error("Error in specificUserResults() " + e);
			e.printStackTrace();
			throw new DataAccessException(e);
		}

		return rL;
	}
	
	
	@Override
	public ResultList specificUserSearch(Map map) throws DataAccessException {
		// TODO Auto-generated method stub
		ResultList rL = new ResultList();

		try {

			System.out.println("------userResultsDaoImpl.java-------specificUserSearch()------");
			rL.setList((List) getSqlMapClientTemplate().queryForList("UserSearchResult.specificUserSearch", map));
			System.out.println("------------UsersResultsDaoImpl.java--specificUserSearch()--ResultList size----" + rL.getList().size());
			if (rL.getList().size() == 0) {
				rL.setTotalCount(new Integer(0));
			} else  {
				rL.setTotalCount(new Integer(rL.getList().size()));
			} 

		} catch (Exception e) {
			log.error("Error in specificUserSearch() " + e);
			e.printStackTrace();
			throw new DataAccessException(e);
		}

		return rL;
	}
	
	@Override
	public ResultList specificRoleIdSearch(Map map) throws DataAccessException {
		// TODO Auto-generated method stub
		ResultList rL = new ResultList();

		try {

			System.out.println("------userResultsDaoImpl.java-------specificRoleIdSearch()------");
			rL.setList((List) getSqlMapClientTemplate().queryForList("UserSearchResult.specificRoleIdSearch", map));
			System.out.println("------------UsersResultsDaoImpl.java--specificRoleIdSearch()--ResultList size----" + rL.getList().size());
			if (rL.getList().size() == 0) {
				rL.setTotalCount(new Integer(0));
			} else if (map.get("showAll") != null && ((String) map.get("showAll")).equals("true")) {
				rL.setTotalCount(new Integer(rL.getList().size()));
			} else {
				rL.setTotalCount(
						(Integer) getSqlMapClientTemplate().queryForObject("UserSearchResult.specificRoleIdSearchCount", map));
			}


		} catch (Exception e) {
			log.error("Error in specificRoleIdSearch() " + e);
			e.printStackTrace();
			throw new DataAccessException(e);
		}

		return rL;
	}
	
	@Override
	public ResultList userResultsByRole(Map map) throws DataAccessException {
		// TODO Auto-generated method stub
		ResultList rL = new ResultList();

		try {

			System.out.println("------UsersResultsDaoImpl.java-------UserResultsByRole()------");
			rL.setList((List) getSqlMapClientTemplate().queryForList("UserSearchResult.userResultsByRole", map));
			System.out.println("------------UsersResultsDaoImpl.java--ResultList size----" + rL.getList().size());
			if (rL.getList().size() == 0) {
				rL.setTotalCount(new Integer(0));
			}

		} catch (Exception e) {
			log.error("Error in userResultsByRole() " + e);
			e.printStackTrace();
			throw new DataAccessException(e);
		}

		return rL;
	}

	@Override
	public ResultList userResultsByUser(Map map) throws DataAccessException {
		// TODO Auto-generated method stub
		ResultList rL = new ResultList();
		System.out.println("@@@DAO Impl" + map.get("roleSelected"));
		try {

			System.out.println("------getUsersResultsDaoImpl.java-------UserResultsByUser()------");
			rL.setList((List) getSqlMapClientTemplate().queryForList("UserSearchResult.userResultsByUser", map));
			System.out.println("------------getUsersResultsDaoImpl.java--ResultList size----" + rL.getList().size());
			if (rL.getList().size() == 0) {
				rL.setTotalCount(new Integer(0));
			}

		} catch (Exception e) {
			log.error("Error in userResultsByUser() " + e);
			e.printStackTrace();
			throw new DataAccessException(e);
		}

		return rL;
	}

	@Override
	public ResultList userResultsByLocation(Map map) throws DataAccessException {
		// TODO Auto-generated method stub
		ResultList rL = new ResultList();

		try {

			System.out.println("------getUsersResultsDaoImpl.java-------userResultsByLocation()------");
			rL.setList((List) getSqlMapClientTemplate().queryForList("UserSearchResult.userResultsByLocation", map));
			System.out.println("------------getUsersResultsDaoImpl.java--ResultList size----" + rL.getList().size());
			if (rL.getList().size() == 0) {
				rL.setTotalCount(new Integer(0));
			}

		} catch (Exception e) {
			log.error("Error in userResultsByLocation() " + e);
			e.printStackTrace();
			throw new DataAccessException(e);
		}

		return rL;
	}

}