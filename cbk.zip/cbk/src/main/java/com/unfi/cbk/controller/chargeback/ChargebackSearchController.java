package com.unfi.cbk.controller.chargeback;

import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.servlet.ModelAndView;

import com.unfi.cbk.beans.ResultList;
import com.unfi.cbk.bo.ChargebackBO;
import com.unfi.cbk.delegates.ChargebackSearchDelegate;
import com.unfi.cbk.exceptions.DataAccessException;
import com.unfi.cbk.forms.ChargebackSearchForm;
import com.unfi.cbk.util.ActionMessages;
import com.unfi.cbk.util.ActionUrlMapping;
import com.unfi.cbk.util.Constants;
import com.unfi.cbk.util.DateFunctions;

/**
 * The NewSearchAction class is the struts action called for the search criteria
 * entry page. The action sets the user data in the request, sets any values
 * needed for the form, and forwards to the JSP specific to the userType.
 *
 * @author vpil001
 * @since 1.0
 */
@Controller("newSearchAction_chargeback")
@Scope(value = WebApplicationContext.SCOPE_REQUEST, proxyMode = ScopedProxyMode.TARGET_CLASS)
public class ChargebackSearchController {// extends Action {
	static Logger log = Logger.getLogger(ChargebackSearchController.class);
	@Autowired
	ActionMessages errors;
	@Autowired
	private ChargebackSearchDelegate chargebackSearchDelegate;

	// Externalize this value
	@Value("${cbk.autoGrowCollectionLimit:100000}")
	private int autoGrowCollectionLimit;

	@InitBinder
	public void initBinder(WebDataBinder dataBinder) {
		dataBinder.setAutoGrowCollectionLimit(autoGrowCollectionLimit);
	}

	/**
	 * 
	 * @param chargebackSearchForm
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/newChargebackSearch", method = { RequestMethod.GET, RequestMethod.POST })
	public ModelAndView execute(@ModelAttribute("chargebackSearchForm") ChargebackSearchForm chargebackSearchForm,
			HttpServletRequest request, HttpServletResponse response) throws Exception {
		log.debug("***** CHARGEBACK SEARCH *****-NewSearchAction.java-- execute()---");
		ModelAndView mav = new ModelAndView();
		chargebackSearchForm.setFormParameterMap(request);
		Map<String, Comparable> searchParametersFromForm = chargebackSearchForm.getMap();

		HttpSession session = request.getSession();
		String SmUserId = (String) session.getAttribute("SmUserId");

		if (request.getParameter("isformreset") != null) {
			chargebackSearchForm.reset();
		}
		log.debug("***** CHARGEBACK SEARCH *****");

		boolean Approver = false;

		// Define the display parameters
		int maxRows = 20;
		chargebackSearchForm.setDisplayCount(maxRows);

		if (chargebackSearchForm.isShowAll()) {
			searchParametersFromForm.put("showAll", "true");
		} else {
			searchParametersFromForm.put("rowStart", new Integer(chargebackSearchForm.getCurrentRecord()));
			searchParametersFromForm.put("rowEnd", new Integer(chargebackSearchForm.getCurrentRecord() + maxRows - 1));
		}

		// NOT AN APPROVER ROLES- ROLE_ID =9, 18
		ResultList userAssignedRoles = chargebackSearchDelegate.getUserAssignedRoles(SmUserId);

		// ChargebackBO cbkBO = new ChargebackBO();
		if (userAssignedRoles.getList().size() > 0) {
			Approver = true;
		}

		if (Approver) {
			String searchCBK = (String) request.getParameter("searchCBK");
			log.debug("-------searchCBK------" + searchCBK);

			if (searchCBK != null) {

				// Get the ChargebackType list
				List chargebackTypes = chargebackSearchDelegate.getChargebackTypes();
				chargebackSearchForm.setChargebackTypes(chargebackTypes);

				mav.setViewName(ActionUrlMapping.CHARGEBACKNEWSEARCHACTION.get(Constants.ACTION_SUCCESS));
				request.setAttribute("actionMessages", errors);
				request.setAttribute("chargebackSearchForm", chargebackSearchForm);
			} else {
				searchParametersFromForm.put("userId", SmUserId);
				// Available Chargebacks List
				ResultList searchResults = chargebackSearchDelegate.getAvailableChargebacks(searchParametersFromForm);

				// Populate the 'searchResults' property in the ActionForm
				chargebackSearchForm.setSearchResults(searchResults.getList());
				chargebackSearchForm.setTotalRecords(searchResults.getTotalCount().intValue());

				mav.setViewName(ActionUrlMapping.AVAILABLECHARGEBACKACTION.get(Constants.ACTION_SUCCESS));
				request.setAttribute("actionMessages", errors);
				request.setAttribute("chargebackSearchForm", chargebackSearchForm);
			}
		} else {
			List chargebackTypes = chargebackSearchDelegate.getChargebackTypes();
			chargebackSearchForm.setChargebackTypes(chargebackTypes);

			mav.setViewName(ActionUrlMapping.CHARGEBACKNEWSEARCHACTION.get(Constants.ACTION_SUCCESS));
			request.setAttribute("actionMessages", errors);
			request.setAttribute("chargebackSearchForm", chargebackSearchForm);
		}
		return mav;

	}

	/**
	 * 
	 * @param chargebackSearchForm
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */

	@RequestMapping(value = "/approveChargebacks", method = { RequestMethod.GET, RequestMethod.POST }, params = {
			"action=approve" })
	public ModelAndView approve(@ModelAttribute("chargebackSearchForm") ChargebackSearchForm chargebackSearchForm,
			HttpServletRequest request, HttpServletResponse response) throws Exception {
		chargebackSearchForm.setFormParameterMap(request);
		ModelAndView mav = new ModelAndView();
		log.debug("***** SELECTED CHARGEBACKS APPROVE *****");

		try {
			String invoiceNumber = request.getParameter("invoiceNumber");
			String locationNumber = request.getParameter("locationNumber");
			String originalApprover = request.getParameter("originalApprover");

			HttpSession session = request.getSession();
			String SmUserId = (String) session.getAttribute("SmUserId");

			String maxStepNumber = null;
			// String currentStepNumber = null;
			String stepNumber = null;
			String netAmount = null;
			String actionType = null;
			String typeId = null;
			boolean reachedMaxStep = true;
			String approved = "false";
			String approver = null;

			String creatorId = null;
			if (request.getParameter("creatorId") != null) {
				creatorId = request.getParameter("creatorId");
			}
			String app = null;
			if (request.getParameter("app") != null) {
				approver = request.getParameter("app");

			}
			if (request.getParameter("stepNumber") != null) {
				stepNumber = request.getParameter("stepNumber");
			} else {
				stepNumber = "10";
			}

			if (request.getParameter("typeId") != null) {
				typeId = request.getParameter("typeId");
			}

			if (request.getParameter("netAmount") != null) {
				netAmount = request.getParameter("netAmount");
			}

			maxStepNumber = chargebackSearchDelegate.getMaxStepNumberWithInvoiceAmount(invoiceNumber, locationNumber,typeId);

			if (maxStepNumber.equals(stepNumber)) {
				approved = "true";
				chargebackSearchForm.setApproved(approved);
				approver = "No further approvals";
			}

			ChargebackBO cbkBo = new ChargebackBO();
			// Call the common method to return the list
			cbkBo.setInvoiceNumber(invoiceNumber);
			cbkBo.setLocationNumber(locationNumber);
			cbkBo.setApproverId(SmUserId);
			cbkBo.setStepNumber(stepNumber);
			//cbkBo.setApprovalDate(new Date());
			cbkBo.setApprovalDate(DateFunctions.adjustCurrentDateByDaysNoFormat(0));

			cbkBo.setNextAproverId(approver);

			// cbkBo.setInterInstr(interInstr);
			// chargebackSearchDelegate.updateChargebackDenyReason(cbkBo);

			chargebackSearchDelegate.updateChargebackApprover(cbkBo);

			// Perform the APPROVE (INSERT)
			chargebackSearchDelegate.approveChargebacks(cbkBo);

			// AFTER APPROVE PULL THE AVAILABLE CHARGEBACKS

			Map<String, Comparable> searchParametersFromForm = chargebackSearchForm.getMap();
			searchParametersFromForm.put("userId", SmUserId);

			// Define the display parameters
			int maxRows = 20;
			chargebackSearchForm.setDisplayCount(maxRows);

			if (chargebackSearchForm.isShowAll()) {
				searchParametersFromForm.put("showAll", "true");
			} else {
				searchParametersFromForm.put("rowStart", new Integer(chargebackSearchForm.getCurrentRecord()));
				searchParametersFromForm.put("rowEnd",
						new Integer(chargebackSearchForm.getCurrentRecord() + maxRows - 1));
			}
			ResultList searchResults = chargebackSearchDelegate.getAvailableChargebacks(searchParametersFromForm);

			// Populate the 'searchResults' property in the ActionForm
			chargebackSearchForm.setSearchResults(searchResults.getList());
			chargebackSearchForm.setTotalRecords(searchResults.getTotalCount().intValue());
			// email code
			/*
			 * if (stepNumber.equals(maxStepNumber)){ CreateNewUserBO UserBODetails =
			 * chargebackSearchDelegate.getUserDetails(creatorId); // Send email only when
			 * user finally confirmed on the approver and notification if
			 * (UserBODetails.getUseremailId() != null) {
			 * UserBODetails.setUseremailId(TEST_EMAIL); //// need to remove this line when
			 * we are at actual environment. chargebackMailer.finalApproverSendEmail(cbkBo,
			 * UserBODetails.getUseremailId(), SmUserId); } } else if
			 * (!cbkBo.getNextApprover().equals("") && cbkBo.getNextApprover() != null) {
			 * CreateNewUserBO UserBODetails =
			 * chargebackSearchDelegate.getUserDetails(cbkBo.getNextApprover()); // Send
			 * email only when user finally confirmed on the approver and notification if
			 * (UserBODetails.getUseremailId() != null) {
			 * UserBODetails.setUseremailId(TEST_EMAIL); // need to remove this line when we
			 * are at actual environment. chargebackMailer.nextApproverSendEmail(cbkBo,
			 * UserBODetails.getUseremailId(), SmUserId);
			 * 
			 * } }
			 */

		} catch (Exception e) {
			e.printStackTrace();
			mav.setViewName(ActionUrlMapping.GLOBAL.get(Constants.ACTION_FAILURE));
			log.error("Exception in execute:" + e);
		}

		mav.setViewName(ActionUrlMapping.AVAILABLECHARGEBACKACTION.get(Constants.ACTION_SUCCESS));
		request.setAttribute("actionMessages", errors);
		request.setAttribute("chargebackSearchForm", chargebackSearchForm);
		return mav;

	}

	/**
	 * 
	 * @param chargebackSearchForm
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */

	@RequestMapping(value = "/denyChargebacks", method = { RequestMethod.GET, RequestMethod.POST }, params = {
			"action=deny" })
	public ModelAndView deny(@ModelAttribute("chargebackSearchForm") ChargebackSearchForm chargebackSearchForm,
			HttpServletRequest request, HttpServletResponse response) throws Exception {
		chargebackSearchForm.setFormParameterMap(request);
		ModelAndView mav = new ModelAndView();
		log.debug("***** SELECTED CHARGEBACKS DENY *****");
		String invoiceNumber = request.getParameter("invoiceNumber");
		String locationNumber = request.getParameter("locationNumber");
		HttpSession session = request.getSession();
		String SmUserId = (String) session.getAttribute("SmUserId");

		try {
			String denyReason = null;
			if (request.getParameter("denyReason") != null) {
				denyReason = request.getParameter("denyReason");

			}

			ChargebackBO cbkBo = new ChargebackBO();
			// Call the common method to return the list
			cbkBo.setInvoiceNumber(invoiceNumber);
			cbkBo.setLocationNumber(locationNumber);
			//cbkBo.setInterInstr(denyReason);
			cbkBo.setNextAproverId(null);
			//cbkBo.setCancelled(-1);
			chargebackSearchDelegate.updateChargebackDenyReason(cbkBo);
			// Perform the DENY (UDPDATE)
			// chargebackSearchDelegate.updateChargebackApprover(cbkBo);

			// AFTER DENY PULL THE AVAILABLE CHARGEBACKS

			Map<String, Comparable> searchParametersFromForm = chargebackSearchForm.getMap();
			searchParametersFromForm.put("userId", SmUserId);

			// Define the display parameters
			int maxRows = 20;
			chargebackSearchForm.setDisplayCount(maxRows);

			if (chargebackSearchForm.isShowAll()) {
				searchParametersFromForm.put("showAll", "true");
			} else {
				searchParametersFromForm.put("rowStart", new Integer(chargebackSearchForm.getCurrentRecord()));
				searchParametersFromForm.put("rowEnd",
						new Integer(chargebackSearchForm.getCurrentRecord() + maxRows - 1));
			}
			ResultList searchResults = chargebackSearchDelegate.getAvailableChargebacks(searchParametersFromForm);

			// Populate the 'searchResults' property in the ActionForm
			chargebackSearchForm.setSearchResults(searchResults.getList());
			chargebackSearchForm.setTotalRecords(searchResults.getTotalCount().intValue());

		} catch (Exception e) {
			e.printStackTrace();
			mav.setViewName(ActionUrlMapping.GLOBAL.get(Constants.ACTION_FAILURE));
			log.error("Exception in execute:" + e);
		}
		// Finish with
		mav.setViewName(ActionUrlMapping.AVAILABLECHARGEBACKACTION.get(Constants.ACTION_SUCCESS));
		request.setAttribute("actionMessages", errors);
		request.setAttribute("chargebackSearchForm", chargebackSearchForm);
		return mav;
	}

	@RequestMapping(value = "/maxStepNumberInvoice", method = { RequestMethod.GET,
			RequestMethod.POST }, consumes = "application/json", params = { "action=maxStepNumberInvoiceNumber" })
	public @ResponseBody ResponseEntity<?> processAJAXRequestforMaxStep(
			@RequestParam("invoiceNumber") String invoiceNumber, @RequestParam("locationNumber") String locationNumber,	@RequestParam("typeId") String typeId, @RequestParam("stepNumber") String stepNumber) 
	{

		log.debug("---in side current Step number ajax--"+stepNumber);

		//
		boolean validate = true;
		if (invoiceNumber != null && locationNumber != null && typeId != null && stepNumber != null) 
			{

			// VALIDATE FROM DATABASE
			String maxStepNumber;
			try {
				maxStepNumber = chargebackSearchDelegate.getMaxStepNumberWithInvoiceAmount(invoiceNumber, locationNumber,typeId);
				if (maxStepNumber.equals(stepNumber)) {
					log.debug("----reached max step ----");
					
					validate = false;
				}

			} catch (DataAccessException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
		return ResponseEntity.ok(validate);
	}

}