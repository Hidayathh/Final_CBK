package com.unfi.cbk.forms;

import org.apache.log4j.Logger;

public class ChargebackInterfaceForm extends SortablePageableActionForm {

	static Logger log = Logger.getLogger(ChargebackInterfaceForm.class);
	private String file;

	public String getFile() {
		return file;
	}

	public void setFile(String file) {
		this.file = file;
	}

}
