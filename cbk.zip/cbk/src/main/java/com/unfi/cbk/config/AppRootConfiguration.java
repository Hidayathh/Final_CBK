/**
 * 
 */
package com.unfi.cbk.config;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;

import org.apache.catalina.connector.Connector;
import org.apache.tomcat.util.descriptor.web.ContextResource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.web.embedded.tomcat.TomcatServletWebServerFactory;
import org.springframework.boot.web.embedded.tomcat.TomcatWebServer;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.boot.web.servlet.ServletContextInitializer;
import org.springframework.boot.web.servlet.ServletRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.ImportResource;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.context.support.ResourceBundleMessageSource;
import org.springframework.core.env.Environment;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.web.accept.ContentNegotiationManager;
import org.springframework.web.context.request.RequestContextListener;
import org.springframework.web.filter.RequestContextFilter;
import org.springframework.web.servlet.ViewResolver;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.springframework.web.servlet.view.ContentNegotiatingViewResolver;
import org.springframework.web.servlet.view.JstlView;
import org.springframework.web.servlet.view.UrlBasedViewResolver;
import org.springframework.web.servlet.view.tiles3.TilesConfigurer;
import org.springframework.web.servlet.view.tiles3.TilesViewResolver;

import com.unfi.cbk.filter.ChargebackFilter;
import com.unfi.cbk.utilcore.Setup;

/**
 * 
 * @author yhp6y2l
 *
 */
@Configuration
@PropertySources({ @PropertySource("classpath:cbkApplication.properties"), @PropertySource("classpath:server.properties"),
		@PropertySource("classpath:ldap.properties"), 
		@PropertySource("classpath:log4j.properties"), 
		@PropertySource("classpath:com/unfi/cbk/resources/ApplicationResources.properties"),
		@PropertySource("classpath:commons-logging.properties")
})
@ImportResource("classpath:/config/spring-beans.xml")
@EnableTransactionManagement
public class AppRootConfiguration implements WebMvcConfigurer {

	private static Logger logger = LoggerFactory.getLogger(AppRootConfiguration.class.getName());

	@Autowired
	private CSRFTokenFilter csrfTokenFilter;
	
	@Autowired
	private Environment environment;

	@Override
	public void addInterceptors(InterceptorRegistry registry) {
		registry.addInterceptor(csrfTokenFilter);// .excludePathPatterns(AppWebSecurityConfig.skipStaticResource);
	}

	@Bean
	public RequestContextListener requestContextListener() {

		return new RequestContextListener();
	}

	@Bean
	public RequestContextFilter requestContextFilterr() {

		return new RequestContextFilter();
	}

	@Bean
	public void addToSystemProperties() {
		
		System.setProperty("dbschemaname", environment.getProperty("db.schema.name"));
		System.setProperty("dbschemaname2", environment.getProperty("db.schema.name2"));
		System.setProperty("server.servlet.session.cookie.secure", environment.getProperty("server.servlet.session.cookie.secure"));
	}


	/*
	 * PropertySourcesPlaceHolderConfigurer Bean only required for @Value("{}")
	 * annotations. Remove this bean if you are not using @Value annotations for
	 * injecting properties.
	 */
	@Bean
	public static PropertySourcesPlaceholderConfigurer propertySourcesPlaceholderConfigurer() {
		return new PropertySourcesPlaceholderConfigurer();
	}

	@Bean("messageSource")
	public ResourceBundleMessageSource messageSource() {
		ResourceBundleMessageSource messageSource = new ResourceBundleMessageSource();

		messageSource.setBasename("com/unfi/cbk/resources/ApplicationResources");
		messageSource.addBasenames("cbkApplication");
		return messageSource;
	}

	@Bean
	public FilterRegistrationBean<ChargebackFilter> chargebackFilter() {
		FilterRegistrationBean<ChargebackFilter> registrationBean = new FilterRegistrationBean<>();

		registrationBean.setFilter(new ChargebackFilter());
		registrationBean.addUrlPatterns("/*");

		return registrationBean;
	}

	@Bean
	public ServletRegistrationBean<Setup> setup() {
		ServletRegistrationBean<Setup> servlet = new ServletRegistrationBean<>(new Setup(), "/Setup");
		servlet.setLoadOnStartup(1);
		servlet.setName("Setup");
		return servlet;
	}



	/**
	 * This method is used to register the context init params This method is used
	 * when the application is deployed to external container. This means if the app
	 * is not deployed to embedded tomcat server. For embedded tomcat server use the
	 * application.properties file setup.
	 * 
	 * 
	 * server.context-parameters.* only works for embedded servers, so to configure
	 * context-parameters on Java EE server is necessary to include a @Bean of type
	 * ServletContextInitializer like the following:
	 * 
	 * 
	 * @return
	 */
	@Bean
	public ServletContextInitializer contextInitializer() {
		return new ServletContextInitializer() {

			@Override
			public void onStartup(ServletContext servletContext) throws ServletException {

				servletContext.setInitParameter("javax.servlet.jsp.jstl.fmt.localizationContext",
						"com.unfi.cbk.resources.ApplicationResources");

			}

		};
	}

	/**
	 * Configure TilesConfigurer.
	 */
	@Bean
	public TilesConfigurer tilesConfigurer() {
		TilesConfigurer tilesConfigurer = new TilesConfigurer();
		tilesConfigurer.setDefinitions(new String[] { "classpath:META-INF/resources/WEB-INF/forwardDefinition.xml" });
		tilesConfigurer.setCheckRefresh(true);
		return tilesConfigurer;
	}

	/**
	 * This method is used to create tiles view resolver which have view resolver
	 * first priority for resolve response view
	 */
	private TilesViewResolver tilesViewResolver() {
		TilesViewResolver resolver = new TilesViewResolver();
		resolver.clearCache();
		resolver.setCache(false);
		resolver.setCacheLimit(1024);
		resolver.setOrder(0);
		return resolver;
	}

	/**
	 * This method is used to create simple jsp view resolver which have third
	 * priority for resolve response views
	 */
	private UrlBasedViewResolver urlBasedViewResolver() {
		UrlBasedViewResolver resolver = new UrlBasedViewResolver();
		resolver.setPrefix("");
		resolver.setSuffix(".jsp");
		resolver.setViewClass(JstlView.class);
		resolver.setCache(false);
		resolver.setCacheLimit(1024);
		resolver.setOrder(1);
		return resolver;
	}

	/**
	 * This method is used setup multiple view resolver for applications. This is a
	 * bean register to application.
	 */
	@Bean
	public ViewResolver viewResolver(ContentNegotiationManager manager) {
		List<ViewResolver> viewResolvers = new ArrayList<ViewResolver>();

		viewResolvers.add(tilesViewResolver());
		viewResolvers.add(urlBasedViewResolver());
		ContentNegotiatingViewResolver resolver = new ContentNegotiatingViewResolver();
		resolver.setViewResolvers(viewResolvers);
		resolver.setContentNegotiationManager(manager);
		return resolver;
	}
	@Bean
	@ConfigurationProperties(prefix = "datasource.map")
	 public Map<String, String> getAllSVHarborDBFuncs() {
	    return new HashMap<>();
	  }

	@Autowired
	private WebServerProperties serverProperties;

	private Connector createSslConnector(Connector connector) {

		try {

			Map<String, String> dbFuncsMap = getAllSVHarborDBFuncs();

			if (serverProperties != null) {
				Map<String, String> map = serverProperties.getConnector();

				if (map != null) {

					for (Entry<String, String> entrySet : map.entrySet()) {

						String dbFuncValue = dbFuncsMap.get(entrySet.getValue());
						logger.info("Before : key= " + entrySet.getKey() + " , value= " + entrySet.getValue());
						if (dbFuncValue != null) {
							connector.setProperty(entrySet.getKey(), dbFuncValue);
							logger.info("After : key= " + entrySet.getKey() + " , value= " + dbFuncValue);
						} else {
							connector.setProperty(entrySet.getKey(), entrySet.getValue());
						}

					}
				}
			}

			return connector;
		} catch (Exception ex) {
			ex.getStackTrace();
			throw new IllegalStateException(
					"can't access keystore: [" + "keystore" + "] or truststore: [" + "keystore" + "]", ex);
		}
	}



	private boolean isActiveProfileLocal() {

		boolean isLocalEnv = false;

		String[] profiles = environment.getActiveProfiles();
		List<String> profileList = null;
		if (profiles != null && profiles.length != 0) {
			profileList = Arrays.asList(profiles);
		}

		if (profileList != null && profileList.contains("local")) {
			isLocalEnv = true;
		}
		return isLocalEnv;
	}

	@Bean
	public TomcatServletWebServerFactory tomcatFactory() {

		TomcatServletWebServerFactory factory = null;

		try {

			Map<String, String> dbFuncsMap = getAllSVHarborDBFuncs();
			factory = new TomcatServletWebServerFactory() {
				@Override
				protected TomcatWebServer getTomcatWebServer(org.apache.catalina.startup.Tomcat tomcat) {
					tomcat.enableNaming();

					// This check is written to skip connector configuration in local env
					if (!isActiveProfileLocal()) {
						Connector connector = tomcat.getConnector();

						tomcat.setConnector(createSslConnector(connector));

					}

					return super.getTomcatWebServer(tomcat);
				}

				@Override
				protected void postProcessContext(org.apache.catalina.Context context) {

					if (serverProperties != null) {

						List<Map<String, String>> resourceList = serverProperties.getResource();

						if (resourceList != null) {

							for (Map<String, String> map : resourceList) {
								ContextResource contextResource = new ContextResource();

								String tempValue = map.get("name");
								if (tempValue != null) {
									contextResource.setName(tempValue);
								}
								tempValue = map.get("auth");
								if (tempValue != null) {
									contextResource.setAuth(tempValue);
								}

								tempValue = map.get("scope");
								if (tempValue != null) {
									contextResource.setScope(tempValue);
								}

								tempValue = map.get("type");

								if (tempValue != null) {
									contextResource.setType(tempValue);
								}

								for (Entry<String, String> entrySet : map.entrySet()) {

									String dbFuncValue = dbFuncsMap.get(entrySet.getValue());
									if (dbFuncValue != null) {
										contextResource.setProperty(entrySet.getKey(), dbFuncValue);

									} else {
										contextResource.setProperty(entrySet.getKey(), entrySet.getValue());
									}
									
									logger.info("key= " + entrySet.getKey() + " , value= " + dbFuncValue);
								}

								context.getNamingResources().addResource(contextResource);
							}

						}

					}
				}
			};
		} catch (Exception e) {
			e.printStackTrace();
		}

		logger.info("-----configuration is completed----..");
		return factory;
	}

}
