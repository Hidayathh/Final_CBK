/*
 * Created on Oct 12, 2005
 *
 */
package com.unfi.cbk.bo;

/**
 * @author hoskn0
 *
 *         To change the template for this generated type comment go to
 *         Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class VendorBO {
	private java.lang.String vendorId;
	private java.lang.String vendorName;
	private java.lang.String vendorGroup;
	private java.lang.String vendorStatus;
	private java.lang.String bankInstCode;
	private java.lang.String vendorClass;
	private java.lang.String termCode;
	private java.lang.String ediStatCode;
	private java.lang.String vendorLegalName;
	private java.lang.String federalTaxId;
	private java.lang.String vendorSearchName;

	// Lockdown/Correspondence Info
	private java.lang.String locCode;
	private java.lang.String contact;
	private java.lang.String emailAddress;
	private java.lang.String address;
	private java.lang.String address2;
	private java.lang.String city;
	private java.lang.String stateCode;
	private java.lang.String zipCode;
	private java.lang.String country;
	private java.lang.String countryCode;
	private java.lang.String phonePrefix;
	private java.lang.String phoneNumber;
	private java.lang.String phoneExt;
	private java.lang.String faxPrefix;
	private java.lang.String faxNumber;
	private java.lang.String faxExt;

	// EDI Info
	private java.lang.String ediLocCode;
	private java.lang.String ediContact;
	private java.lang.String ediEmailAddress;
	private java.lang.String ediAddress;
	private java.lang.String ediAddress2;
	private java.lang.String ediCity;
	private java.lang.String ediStateCode;
	private java.lang.String ediZipCode;
	private java.lang.String ediCountry;
	private java.lang.String ediCountryCode;
	private java.lang.String ediPhonePrefix;
	private java.lang.String ediPhoneNumber;
	private java.lang.String ediPhoneExt;
	private java.lang.String ediFaxPrefix;
	private java.lang.String ediFaxNumber;
	private java.lang.String ediFaxExt;
	private java.lang.String tradingPartner;
	private java.lang.String tradingPartner2;
	private java.lang.String tradingPartner3;

	// Remit Address Info
	private java.lang.String remitAddress;
	private java.lang.String remitAddress2;
	private java.lang.String remitCity;
	private java.lang.String remitStateCode;
	private java.lang.String remitZipCode;
	private java.lang.String remitCountry;
	private java.lang.String remitCountryCode;
	private String corrLock;
	
	
	public String getCorrLock() {
		return corrLock;
	}

	public void setCorrLock(String corrLock) {
		this.corrLock = corrLock;
	}

	/**
	 * @return
	 */
	public java.lang.String getAddress() {
		return address;
	}

	/**
	 * @return
	 */
	public java.lang.String getAddress2() {
		return address2;
	}

	/**
	 * @return
	 */
	public java.lang.String getCity() {
		return city;
	}

	/**
	 * @return
	 */
	public java.lang.String getContact() {
		return contact;
	}

	/**
	 * @return
	 */
	public java.lang.String getCountry() {
		return country;
	}

	/**
	 * @return
	 */
	public java.lang.String getEdiStatCode() {
		return ediStatCode;
	}

	/**
	 * @return
	 */
	public java.lang.String getEmailAddress() {
		return emailAddress;
	}

	/**
	 * @return
	 */
	public java.lang.String getFaxNumber() {
		return faxNumber;
	}

	/**
	 * @return
	 */
	public java.lang.String getLocCode() {
		return locCode;
	}

	/**
	 * @return
	 */
	public java.lang.String getPhoneNumber() {
		return phoneNumber;
	}

	/**
	 * @return
	 */
	public java.lang.String getStateCode() {
		return stateCode;
	}

	/**
	 * @return
	 */
	public java.lang.String getVendorGroup() {
		return vendorGroup;
	}

	/**
	 * @return
	 */
	public java.lang.String getVendorId() {
		return vendorId;
	}

	/**
	 * @return
	 */
	public java.lang.String getVendorName() {
		return vendorName;
	}

	/**
	 * @return
	 */
	public java.lang.String getZipCode() {
		return zipCode;
	}

	/**
	 * @param string
	 */
	public void setAddress(java.lang.String string) {
		address = string;
	}

	/**
	 * @param string
	 */
	public void setAddress2(java.lang.String string) {
		address2 = string;
	}

	/**
	 * @param string
	 */
	public void setCity(java.lang.String string) {
		city = string;
	}

	/**
	 * @param string
	 */
	public void setContact(java.lang.String string) {
		contact = string;
	}

	/**
	 * @param string
	 */
	public void setCountry(java.lang.String string) {
		country = string;
	}

	/**
	 * @param string
	 */
	public void setEdiStatCode(java.lang.String string) {
		ediStatCode = string;
	}

	/**
	 * @param string
	 */
	public void setEmailAddress(java.lang.String string) {
		emailAddress = string;
	}

	/**
	 * @param string
	 */
	public void setFaxNumber(java.lang.String string) {
		faxNumber = string;
	}

	/**
	 * @param string
	 */
	public void setLocCode(java.lang.String string) {
		locCode = string;
	}

	/**
	 * @param string
	 */
	public void setPhoneNumber(java.lang.String string) {
		phoneNumber = string;
	}

	/**
	 * @param string
	 */
	public void setStateCode(java.lang.String string) {
		stateCode = string;
	}

	/**
	 * @param string
	 */
	public void setVendorGroup(java.lang.String string) {
		vendorGroup = string;
	}

	/**
	 * @param string
	 */
	public void setVendorId(java.lang.String string) {
		vendorId = string;
	}

	/**
	 * @param string
	 */
	public void setVendorName(java.lang.String string) {
		vendorName = string;
	}

	/**
	 * @param string
	 */
	public void setZipCode(java.lang.String string) {
		zipCode = string;
	}

	/**
	 * @return
	 */
	public java.lang.String getBankInstCode() {
		return bankInstCode;
	}

	/**
	 * @return
	 */
	public java.lang.String getTermCode() {
		return termCode;
	}

	/**
	 * @return
	 */
	public java.lang.String getVendorClass() {
		return vendorClass;
	}

	/**
	 * @param string
	 */
	public void setBankInstCode(java.lang.String string) {
		bankInstCode = string;
	}

	/**
	 * @param string
	 */
	public void setTermCode(java.lang.String string) {
		termCode = string;
	}

	/**
	 * @param string
	 */
	public void setVendorClass(java.lang.String string) {
		vendorClass = string;
	}

	/**
	 * @return
	 */
	public java.lang.String getVendorStatus() {
		return vendorStatus;
	}

	/**
	 * @param string
	 */
	public void setVendorStatus(java.lang.String string) {
		vendorStatus = string;
	}

	/**
	 * @return
	 */
	public java.lang.String getFaxPrefix() {
		return faxPrefix;
	}

	/**
	 * @return
	 */
	public java.lang.String getPhonePrefix() {
		return phonePrefix;
	}

	/**
	 * @param string
	 */
	public void setFaxPrefix(java.lang.String string) {
		faxPrefix = string;
	}

	/**
	 * @param string
	 */
	public void setPhonePrefix(java.lang.String string) {
		phonePrefix = string;
	}

	/**
	 * @return
	 */
	public java.lang.String getFormattedPhoneNbr() {
		StringBuffer fullPhoneNbr = new StringBuffer();
		if (getPhoneNumber() != null && !getPhoneNumber().equals("")) {
			fullPhoneNbr.append(getPhonePrefix() == null ? "" : Integer.valueOf(getPhonePrefix().trim()).toString());
			fullPhoneNbr.append("-");
			fullPhoneNbr.append(getPhoneNumber() == null ? "" : getPhoneNumber().trim());
		}
		return fullPhoneNbr.toString();
	}

	public java.lang.String getFormattedFaxNbr() {
		StringBuffer faxNbr = new StringBuffer();
		if (getFaxNumber() != null && !getFaxNumber().equals("")) {
			faxNbr.append(getFaxPrefix() == null ? "" : Integer.valueOf(getFaxPrefix().trim()).toString());
			faxNbr.append("-");
			faxNbr.append(getFaxNumber() == null ? "" : getFaxNumber().trim());
		}
		return faxNbr.toString();
	}

	public boolean isEdiVendor() {
		boolean isEdiVendor = false;

		if (getEdiStatCode() != null && getEdiStatCode().trim().equals("Y")) {
			isEdiVendor = true;

		}

		return isEdiVendor;
	}

	public java.lang.String getRemitAddress() {
		return remitAddress;
	}

	public java.lang.String getRemitAddress2() {
		return remitAddress2;
	}

	public java.lang.String getRemitCity() {
		return remitCity;
	}

	public java.lang.String getRemitStateCode() {
		return remitStateCode;
	}

	public java.lang.String getRemitZipCode() {
		return remitZipCode;
	}

	public java.lang.String getRemitCountry() {
		return remitCountry;
	}

	public void setRemitAddress(java.lang.String string) {
		remitAddress = string;
	}

	public void setRemitAddress2(java.lang.String string) {
		remitAddress2 = string;
	}

	public void setRemitCity(java.lang.String string) {
		remitCity = string;
	}

	public void setRemitCountry(java.lang.String string) {
		remitCountry = string;
	}

	public void setRemitStateCode(java.lang.String string) {
		remitStateCode = string;
	}

	public void setRemitZipCode(java.lang.String string) {
		remitZipCode = string;
	}

	/**
	 * @return
	 */
	public java.lang.String getVendorLegalName() {
		return vendorLegalName;
	}

	/**
	 * @param string
	 */
	public void setVendorLegalName(java.lang.String string) {
		vendorLegalName = string;
	}

	/**
	 * @return
	 */
	public java.lang.String getFederalTaxId() {
		return federalTaxId;
	}

	/**
	 * @param string
	 */
	public void setFederalTaxId(java.lang.String string) {
		federalTaxId = string;
	}

	/**
	 * @return
	 */
	public java.lang.String getVendorSearchName() {
		return vendorSearchName;
	}

	/**
	 * @param string
	 */
	public void setVendorSearchName(java.lang.String string) {
		vendorSearchName = string;
	}

	/**
	 * @return
	 */
	public java.lang.String getEdiAddress() {
		return ediAddress;
	}

	/**
	 * @return
	 */
	public java.lang.String getEdiAddress2() {
		return ediAddress2;
	}

	/**
	 * @return
	 */
	public java.lang.String getEdiCity() {
		return ediCity;
	}

	/**
	 * @return
	 */
	public java.lang.String getEdiContact() {
		return ediContact;
	}

	/**
	 * @return
	 */
	public java.lang.String getEdiCountry() {
		return ediCountry;
	}

	/**
	 * @return
	 */
	public java.lang.String getEdiEmailAddress() {
		return ediEmailAddress;
	}

	/**
	 * @return
	 */
	public java.lang.String getEdiFaxNumber() {
		return ediFaxNumber;
	}

	/**
	 * @return
	 */
	public java.lang.String getEdiFaxPrefix() {
		return ediFaxPrefix;
	}

	/**
	 * @return
	 */
	public java.lang.String getEdiPhoneNumber() {
		return ediPhoneNumber;
	}

	/**
	 * @return
	 */
	public java.lang.String getEdiPhonePrefix() {
		return ediPhonePrefix;
	}

	/**
	 * @return
	 */
	public java.lang.String getEdiStateCode() {
		return ediStateCode;
	}

	/**
	 * @return
	 */
	public java.lang.String getEdiZipCode() {
		return ediZipCode;
	}

	/**
	 * @return
	 */
	public java.lang.String getTradingPartner() {
		return tradingPartner;
	}

	/**
	 * @param string
	 */
	public void setEdiAddress(java.lang.String string) {
		ediAddress = string;
	}

	/**
	 * @param string
	 */
	public void setEdiAddress2(java.lang.String string) {
		ediAddress2 = string;
	}

	/**
	 * @param string
	 */
	public void setEdiCity(java.lang.String string) {
		ediCity = string;
	}

	/**
	 * @param string
	 */
	public void setEdiContact(java.lang.String string) {
		ediContact = string;
	}

	/**
	 * @param string
	 */
	public void setEdiCountry(java.lang.String string) {
		ediCountry = string;
	}

	/**
	 * @param string
	 */
	public void setEdiEmailAddress(java.lang.String string) {
		ediEmailAddress = string;
	}

	/**
	 * @param string
	 */
	public void setEdiFaxNumber(java.lang.String string) {
		ediFaxNumber = string;
	}

	/**
	 * @param string
	 */
	public void setEdiFaxPrefix(java.lang.String string) {
		ediFaxPrefix = string;
	}

	/**
	 * @param string
	 */
	public void setEdiPhoneNumber(java.lang.String string) {
		ediPhoneNumber = string;
	}

	/**
	 * @param string
	 */
	public void setEdiPhonePrefix(java.lang.String string) {
		ediPhonePrefix = string;
	}

	/**
	 * @param string
	 */
	public void setEdiStateCode(java.lang.String string) {
		ediStateCode = string;
	}

	/**
	 * @param string
	 */
	public void setEdiZipCode(java.lang.String string) {
		ediZipCode = string;
	}

	/**
	 * @param string
	 */
	public void setTradingPartner(java.lang.String string) {
		tradingPartner = string;
	}

	/**
	 * @return
	 */
	public java.lang.String getEdiLocCode() {
		return ediLocCode;
	}

	/**
	 * @param string
	 */
	public void setEdiLocCode(java.lang.String string) {
		ediLocCode = string;
	}

	/**
	 * @return
	 */
	public java.lang.String getEdiFaxExt() {
		return ediFaxExt;
	}

	/**
	 * @return
	 */
	public java.lang.String getEdiPhoneExt() {
		return ediPhoneExt;
	}

	/**
	 * @return
	 */
	public java.lang.String getFaxExt() {
		return faxExt;
	}

	/**
	 * @return
	 */
	public java.lang.String getPhoneExt() {
		return phoneExt;
	}

	/**
	 * @param string
	 */
	public void setEdiFaxExt(java.lang.String string) {
		ediFaxExt = string;
	}

	/**
	 * @param string
	 */
	public void setEdiPhoneExt(java.lang.String string) {
		ediPhoneExt = string;
	}

	/**
	 * @param string
	 */
	public void setFaxExt(java.lang.String string) {
		faxExt = string;
	}

	/**
	 * @param string
	 */
	public void setPhoneExt(java.lang.String string) {
		phoneExt = string;
	}

	/**
	 * @return
	 */
	public java.lang.String getCountryCode() {
		return countryCode;
	}

	/**
	 * @return
	 */
	public java.lang.String getEdiCountryCode() {
		return ediCountryCode;
	}

	/**
	 * @return
	 */
	public java.lang.String getRemitCountryCode() {
		return remitCountryCode;
	}

	/**
	 * @param string
	 */
	public void setCountryCode(java.lang.String string) {
		countryCode = string;
	}

	/**
	 * @param string
	 */
	public void setEdiCountryCode(java.lang.String string) {
		ediCountryCode = string;
	}

	/**
	 * @param string
	 */
	public void setRemitCountryCode(java.lang.String string) {
		remitCountryCode = string;
	}

	/**
	 * @return
	 */
	public java.lang.String getTradingPartner2() {
		return tradingPartner2;
	}

	/**
	 * @return
	 */
	public java.lang.String getTradingPartner3() {
		return tradingPartner3;
	}

	/**
	 * @param string
	 */
	public void setTradingPartner2(java.lang.String string) {
		tradingPartner2 = string;
	}

	/**
	 * @param string
	 */
	public void setTradingPartner3(java.lang.String string) {
		tradingPartner3 = string;
	}

}
