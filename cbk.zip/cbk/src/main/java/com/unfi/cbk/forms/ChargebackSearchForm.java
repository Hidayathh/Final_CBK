package com.unfi.cbk.forms;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;

import com.unfi.cbk.bo.ChargebackBO;
import com.unfi.cbk.util.ActionMessages;
import com.unfi.cbk.util.Constants;
import com.unfi.cbk.util.Validations;

/**
 * The ChargebackSearchForm class is the struts action form used to search for
 * documents.
 *
 * @author vpil001
 * @since 1.0
 * 
 */
@Component
public class ChargebackSearchForm extends SortablePageableActionForm {
	static Logger log = Logger.getLogger(ChargebackSearchForm.class);

	// Page-specific properties not part of Map
	private List chargebacks;
	private String[] chargebackSelections = new String[] {};
	private List searchResults;
	private Integer maxMonths;
	private String originator;
	private String nextApprover;
	private String vendorId;
	private String locationNumber;
	private String fromDate;
	private String toDate;
	private String invoiceFrom;
	private String invoiceTo;
	private String amountFrom;
	private String amountTo;
	private String APStatus;
	private String Status;
	private String Type;

	private String maxStepNumber;

	private String approved;
	private String originalApprover;

	private String reasonForDeny;

	private String resultCount;
	private String approver;
	
	
	public String getApprover() {
		return approver;
	}

	public void setApprover(String approver) {
		this.approver = approver;
	}

	public String getResultCount() {
		return resultCount;
	}

	public void setResultCount(String resultCount) {
		this.resultCount = resultCount;
	}

	public String getReasonForDeny() {
		return reasonForDeny;
	}

	public void setReasonForDeny(String reasonForDeny) {
		this.reasonForDeny = reasonForDeny;
	}

	public String getOriginalApprover() {
		return originalApprover;
	}

	public void setOriginalApprover(String originalApprover) {
		this.originalApprover = originalApprover;
	}

	public String getApproved() {
		return approved;
	}

	public void setApproved(String approved) {
		this.approved = approved;
	}

	private List chargebackTypes;

	private String[] selectedItems = null;

	public String[] getSelectedItems() {
		return selectedItems;
	}

	public String getMaxStepNumber() {
		return maxStepNumber;
	}

	public void setMaxStepNumber(String maxStepNumber) {
		this.maxStepNumber = maxStepNumber;
	}

	public void setSelectedItems(String[] selectedItems) {
		this.selectedItems = selectedItems;
	}

	public List getChargebackTypes() {
		return chargebackTypes;
	}

	public void setChargebackTypes(List chargebackTypes) {
		System.out.println("--------chargebackTypes----List---" + chargebackTypes);
		this.chargebackTypes = chargebackTypes;
	}

	public void setLocationNumber(String locationNumber) {
		this.locationNumber = locationNumber;
	}

	public String getLocationNumber() {
		return locationNumber;
	}

	public void setAmountFrom(String amountFrom) {
		this.amountFrom = amountFrom;
	}

	public String getAmountFrom() {
		return amountFrom;
	}

	public void setAmountTo(String amountTo) {
		this.amountTo = amountTo;
	}

	public String getAmountTo() {
		return amountTo;
	}

	public void setInvoiceFrom(String invoiceFrom) {
		this.invoiceFrom = invoiceFrom;
	}

	public String getInvoiceFrom() {
		return invoiceFrom;
	}

	public void setInvoiceTo(String invoiceTo) {
		this.invoiceTo = invoiceTo;
	}

	public String getInvoiceTo() {
		return invoiceTo;
	}

	public String getOriginator() {
		return originator;
	}

	public void setOriginator(String originator) {
		this.originator = originator;
	}

	public String getNextApprover() {
		return nextApprover;
	}

	public void setNextApprover(String nextApprover) {
		this.nextApprover = nextApprover;
	}

	public String getVendorId() {
		return vendorId;
	}

	public void setVendorId(String vendorId) {
		this.vendorId = vendorId;
	}

	public String getFromDate() {
		return fromDate;
	}

	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}

	public String getToDate() {
		return toDate;
	}

	public void setToDate(String toDate) {
		this.toDate = toDate;
	}

	public String getAPStatus() {
		return APStatus;
	}

	public void setAPStatus(String aPStatus) {
		APStatus = aPStatus;
	}

	public String getStatus() {
		return Status;
	}

	public void setStatus(String status) {
		Status = status;
	}

	public String getType() {
		return Type;
	}

	public void setType(String type) {
		Type = type;
	}

	// Externalize this value
	@Value("${cbk.autoGrowCollectionLimit:100000}")
	private int autoGrowCollectionLimit;

	@InitBinder
	public void initBinder(WebDataBinder dataBinder) {
		dataBinder.setAutoGrowCollectionLimit(autoGrowCollectionLimit);
	}

	public List getSearchResults() {
		return this.searchResults;
	}

	public void setSearchResults(List list) {
		this.searchResults = list;
	}

	public ChargebackBO[] getChargeback() {
		if (chargebacks == null) {
			chargebacks = new ArrayList();
		}
		ChargebackBO[] r = new ChargebackBO[chargebacks.size()];
		for (int i = 0; i < chargebacks.size(); i++) {
			r[i] = (ChargebackBO) chargebacks.get(i);
		}
		return r;
	}

	public void setChargeback(ChargebackBO[] r) {
		chargebacks = Arrays.asList(r);
	}

	public ChargebackBO getChargeback(int i) {
		if (chargebacks == null) {
			chargebacks = new ArrayList();
		}
		for (int j = chargebacks.size(); j <= i; j++) {
			chargebacks.add(j, new ChargebackBO());
		}
		return (ChargebackBO) chargebacks.get(i);
	}

	public void setChargeback(int i, ChargebackBO doc) {
		if (chargebacks == null) {
			chargebacks = new ArrayList();
		}
		chargebacks.add(i, doc);
	}

	public List getChargebacks() {
		return chargebacks;
	}

	public void setChargebacks(List doc) {
		chargebacks = doc;
	}

	public String[] getChargebackSelections() {
		return chargebackSelections;
	}

	public void setChargebackSelections(String[] strings) {
		chargebackSelections = strings;
	}

	public List getSelectedResults() {
		List l = null;
		if (chargebackSelections != null) {
			l = new ArrayList();
			for (int i = 0; i < chargebackSelections.length; i++) {
				int j = Integer.parseInt(chargebackSelections[i]);
				l.add(chargebacks.get(j));
			}
		}
		return l;
	}


	/*
	 * (non-Javadoc)
	 * 
	 * @see org.apache.struts.action.ActionForm#reset(org.apache.struts.action.
	 * ActionMapping, javax.servlet.http.HttpServletRequest)
	 */
	public void reset() {

		setValue("dateCriteria", "1");
		setValue("searchBy", "docnum");
		setSortBy("invoiceNumber");
		setSortOrder("asc");
		setShowAll(false);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.apache.struts.action.ActionForm#validate(org.apache.struts.action.
	 * ActionMapping, javax.servlet.http.HttpServletRequest)
	 */
	public ActionMessages validate(HttpServletRequest request, ActionMessages errors) {
		// ActionMessages errors = new ActionMessages();
		String user = request.getRemoteUser();
		Validations validations = new Validations();

		try {
			

			if (!request.isUserInRole(Constants.BROKER_ROLE) && getString("dateCriteria") != null
					&& getString("dateCriteria").equals("manual")) {
				// Verify the entered dates meet the following criteria:
				// (1) The from date is less than the to date.
				// (2) Neither date goes back farther than the specified
				// number of years (as defined in the Resource Bundle
				// under label.dateCriteria.spanMaxYears
				// (3) Neither date is in the future

				// Verify condition (1)
				if (!validations.isValidDateRange(getString("fromDate"), getString("toDate"))) {
					// The from date is greater than the to date - invalid.
					errors.add("fromDate", "errors.dateRange", null);
				}


				if (!validations.isValidTimePeriodMonths(getString("fromDate"), getString("toDate"),
						maxMonths.intValue())) {
					// One of the dates is more than the max specified months ago - invalid
					errors.add("fromDate", "errors.datePriorMonths", new String[] { maxMonths.toString() });
				}

				if (!validations.isNot30PlusDaysInFuture(getString("fromDate"), getString("toDate"))) {
					errors.add("fromDate", "errors.dateFuture", null);
				}
			}

		} catch (Exception e) {
			log.error("Exception in ChargebackSearchForm.validate()" + e);
		}

		return errors;
	}

	/**
	 * @return
	 */
	public Integer getMaxMonths() {
		return maxMonths;
	}

	/**
	 * @param integer
	 */
	public void setMaxMonths(Integer integer) {
		maxMonths = integer;
	}

}