package com.unfi.cbk.dao.ibImpl;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.orm.ibatis.SqlMapClientTemplate;
import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;

import com.unfi.cbk.beans.ResultList;
import com.unfi.cbk.bo.ChargebackReportBO;
import com.unfi.cbk.dao.ChargebackReportDao;
import com.unfi.cbk.exceptions.DataAccessException;

/**
 * The ChargebackExportDaoImpl class handles the call to the database to get the
 * results of the chargebacks search based on the form values.
 *
 * @author vpil001
 * @since 1.0
 */

public class ChargebackReportDaoImpl extends SqlMapClientDaoSupport implements ChargebackReportDao {

	private static Logger log = Logger.getLogger(ChargebackReportDaoImpl.class);
	protected static Date BAD_DATE = null;

	public ChargebackReportDaoImpl(SqlMapClientTemplate sqlMapTemplate) {
		this.setSqlMapClientTemplate(sqlMapTemplate);
	}

	public List getReasonCode() throws DataAccessException {
		List l = null;
		try {
			// HashMap map = new HashMap();
			l = (List) getSqlMapClientTemplate().queryForList("ChargebackReport.getReasonCode");
			System.out.println("------------ChargebackReportDaoImpl.java-getReasonCode---List size----" + l.size());

		} catch (Exception e) {
			e.printStackTrace();
			log.error(e);
			throw new DataAccessException(e);
		}
		System.out.println(l);
		return l;
	}

	@Override
	public List getChargebackReportList(Map map) throws DataAccessException {
		// TODO Auto-generated method stub
		List finalList = new ArrayList();
		
		try {
			for (int i = 1; i <= 9; i++) {
				List<ChargebackReportBO> list = new ArrayList<ChargebackReportBO>();
				map.put("typeId", String.valueOf(i));
				System.out.println("------ChargebackReportDaoImpl.java-------getChargebackReportList()------");
				list =(List) getSqlMapClientTemplate().queryForList("ChargebackReport.getChargebackReportList", map);
				System.out.println("------------ChargebackReportDaoImpl.java--ResultList size----" + list.size());
				finalList.add(list);
			}
			/*
			 * if (list.size() == 0) { list.setTotalCount(new Integer(0)); }
			 */
			// createEexcel(list);
			//System.out.println("List " + list.size());

		} catch (Exception e) {
			e.printStackTrace();
			log.error("Error in getChargebackReportList() ......" + e);
			e.printStackTrace();
			throw new DataAccessException(e);
		}
		return finalList;

	}

	/*
	 * private void createEexcel(List<ResultList> list) throws IOException {
	 * 
	 * XSSFWorkbook wb = new XSSFWorkbook();
	 * 
	 * for(int i=1;i<list.size();i++) {
	 * 
	 * 
	 * 
	 * final String[] header= { "DOCUMENT",
	 * "Location","DOCUMENT_DATE","VENDOR_NUMBER","VENDOR_NAME","TYPE_DESCRIPTION",
	 * "CREATOR","BRIEF_DESCRIPTION","REASON_CODE",
	 * "PRODUCT_GROUP_CODE","AMOUNT","DIST_LOCATION_NUMBAR","STATE","ACCOUNT_NUMBER"
	 * ,"DISTRIBUTION_AMOUNT","DUE_DATE"};
	 * 
	 * // Create a blank sheet with sheet name 'My First ExcelSheet'. XSSFSheet
	 * sheet = wb.createSheet("sheet"+i); // Create an array object and initialize
	 * the data. int rowNum = 0; Row row = sheet.createRow(0);
	 * 
	 * 
	 * for(int j = 0; j < header.length; j++) { Cell cell = row.createCell(j);
	 * cell.setCellValue(header[j]);
	 * 
	 * }
	 * 
	 * 
	 * ResultList rL = list.get(i); for (int k = 0; k < 1; k++) { int colCount=0;
	 * ChargebackReportBO reportBO = (ChargebackReportBO) rL.getList().get(k);
	 * 
	 * // create new row row = sheet.createRow(++rowNum); // for(int l=0;l<15;l++) {
	 * 
	 * Cell cell = row.createCell(++colCount);
	 * cell.setCellValue(reportBO.getDocumentNumber());
	 * cell.setCellValue(reportBO.getLocationNumber());
	 * cell.setCellValue(reportBO.getVendorNumber());
	 * cell.setCellValue(reportBO.getVendorName());
	 * cell.setCellValue(reportBO.getTypeDescription());
	 * cell.setCellValue(reportBO.getCreator());
	 * cell.setCellValue(reportBO.getBriefDecription());
	 * cell.setCellValue(reportBO.getReasonCode());
	 * cell.setCellValue(reportBO.getProductGroupCode());
	 * cell.setCellValue(reportBO.getAmount());
	 * cell.setCellValue(reportBO.getDistLocNumber());
	 * cell.setCellValue(reportBO.getState());
	 * cell.setCellValue(reportBO.getAccNumber());
	 * cell.setCellValue(reportBO.getDistributionAmount());
	 * cell.setCellValue(reportBO.getDueDate()); } // Writing sheet data // }
	 * 
	 * 
	 * 
	 * FileOutputStream outputStream = new
	 * FileOutputStream("C://System//test.xlsx"); wb.write(outputStream); // wb.wri
	 * 
	 * 
	 * if(!outputStream.canRead()){ outputStream.setReadable(true); }
	 * 
	 * 
	 * // Create rows and iterate them.
	 * 
	 * 
	 * 
	 * // Create cells in each row, iterate them and set the cell value.
	 * 
	 * } }
	 */

}