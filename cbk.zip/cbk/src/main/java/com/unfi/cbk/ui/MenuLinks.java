package com.unfi.cbk.ui;

import java.util.Vector;

import org.apache.log4j.Logger;

public class MenuLinks {
	static Logger log = Logger.getLogger(MenuLinks.class);
	private Vector links;
	private Link rootLink;

	public Link getLink(String ID) {
		Link link = null;
		String mainID = ID;
		// try to get the child link
		if (ID.equals("0")) {
			return this.getRootLink();

		}

		link = this.getRootLink().getChild(ID);

		System.out.println("MenuLinks.java---- Now returning--------- " + link.getAlt() + " from getLink(" + ID + ")");
		return link;

	}

	// toplinks are considered the quicklinks and
	// the left side menu links
	public Link getTopLink(String ID) {
		Link link = null;

		if (ID.equals("0")) {
			return this.getRootLink();
		}

		if (ID.indexOf("-") > 0) {
			// remove any child IDs from the main ID
			ID = ID.substring(0, ID.indexOf("-"));
		}

		link = this.getRootLink().getChild(ID);
		if (link == null) {
			log.debug("No link found from getTopLink(" + ID + ")");
		} else {
			// log.debug("Now returning " + link.getAlt() +" from getTopLink("+ID+")");
		}

		return link;

	}

	public Vector getTopLinks() {
		Vector allTopLinks = (Vector) this.getRootLink().getChilderen();
		Vector displayTheseTopLinks = new Vector();

		try {
			for (int i = 0; i < allTopLinks.size(); i++) {
				Link topLink = (Link) allTopLinks.elementAt(i);

				if (topLink.getType().toLowerCase().equals("header")) {
					displayTheseTopLinks.add(topLink);

				}

			}

		} catch (Exception e) {
			// Ignore
			log.error("Exception in getTopLinks():" + e);

		} finally {
			return displayTheseTopLinks;

		}

	}

	/*
	 * this is the root of all links the homepage of the application
	 */
	public Link getRootLink() {
		if (this.rootLink == null) {
			// just return the home link
			for (int i = 0; i < links.size(); i++) {
				if (((Link) links.get(i)).getID().equals("0")) {
					this.rootLink = (Link) links.get(i);

				}
			}
			// log.debug("Now returning " + rootLink.getAlt() +" from getRootLink()");
		}

		return rootLink;

	}

	public Link getErrorLink() {
		// just return the error link
		Link error = new Link();
		for (int i = 0; i < links.size(); i++) {
			if (((Link) links.get(i)).getID().equals("000")) {
				error = (Link) links.get(i);

			}
		}
		// log.debug("Now returning " + error.getText() +" from getErrorLink()");
		return error;

	}

	public void addChild(Link link) {
		if (links == null) {
			links = new Vector();

		}
		// log.debug("Now adding a link to the collection: "+ link.getText());

		links.addElement(link);

	}

	public int getSize() {
		if (links != null) {
			return links.size();

		}
		return 0;

	}

	public String toString() {
		StringBuffer bufer = new StringBuffer();
		try {
			bufer.append("\n--- Links ---\n");
			bufer.append(this.getSize() + " links found\n");
			if (links != null) {
				for (int i = 0; i < links.size(); i++) {
					Link link = (Link) links.get(i);
					bufer.append(link.toString()).append("\n\n");

				}

			} else {
				log.debug("No links have been added to the collection!");

			}

		} catch (Exception e) {
			log.error("Unable to set the links to strings" + e);
			// e.printStackTrace();

		}
		return bufer.toString();

	}

	public Vector getLinks() {
		return links;

	}

	public void setLinks(Vector vector) {
		links = vector;

	}

}