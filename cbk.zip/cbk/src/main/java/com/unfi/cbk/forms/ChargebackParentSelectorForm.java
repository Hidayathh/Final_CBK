package com.unfi.cbk.forms;

import java.util.List;

/**
 * The RequestSourceForm class is the struts action form used for the request
 * source maintenance section. It extends the ValidatorActionForm class in order
 * to utilize built-in struts validation and implements Pageable in order to
 * work with the VCR buttons.
 *
 * @author yhp6y2l
 * @version 1.0
 */
public class ChargebackParentSelectorForm {
	private Integer results = null;

	private List searchResults = null;
	private String selectedResult = null;

	public Integer getResults() {
		return results;
	}

	public void setResults(Integer results) {
		this.results = results;
	}

	public List getSearchResults() {
		return searchResults;
	}

	public void setSearchResults(List searchResults) {
		this.searchResults = searchResults;
	}

	public String getSelectedResult() {
		return selectedResult;
	}

	public void setSelectedResult(String selectedResult) {
		this.selectedResult = selectedResult;
	}

}
