package com.unfi.cbk.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.unfi.cbk.beans.UserDataBean;
import com.unfi.cbk.dao.ChargebackCommonDao;
import com.unfi.cbk.forms.ParentSearchSelectorForm;
import com.unfi.cbk.util.ActionMessages;
import com.unfi.cbk.util.ActionUrlMapping;
import com.unfi.cbk.util.Constants;
/**
 * The action method that will be called is automatically determined based upon
 * the value of the parameter (specified in struts-config.xml) that is passed
 * in.
 * <p>
 * The action method will then sets the user data in the request, sets any
 * values needed, and forwards to the appropriate action mapping.
 *
 * @author
 * @version 1.0
 */

@Controller
public class ParentSearchController {

	static Logger log = Logger.getLogger(ParentSearchController.class);
	private ChargebackCommonDao chargebackCommonDao;

	public ParentSearchController(@Autowired ChargebackCommonDao dao) {
		this.chargebackCommonDao = dao;
	}

	@Autowired
	ActionMessages errors;

	/**
	 * The open() method displays the Vendor Selector pop up.
	 * 
	 * @param mapping  The ActionMapping used to select this instance
	 * @param form     The ActionForm bean for this request
	 * @param request  The HTTP request we are processing
	 * @param response The HTTP response we are creating
	 * @return an ActionForward instance describing where and how control should be
	 *         forwarded, or null if the response has already been completed.
	 * @throws Exception if an exception occurs
	 */
	@RequestMapping(value = "/parentSearchSelector", method = { RequestMethod.GET,
			RequestMethod.POST }, params = { "action=open" })
	public ModelAndView open(@ModelAttribute ParentSearchSelectorForm parentSearchSelectorForm,
			HttpServletRequest request, HttpServletResponse response) throws Exception {
		ModelAndView mav = new ModelAndView();
		boolean exceptionOccurred = false;

		try {
			UserDataBean userBean = new UserDataBean(request);

		} catch (Exception e) {
			exceptionOccurred = true;
			mav.setViewName(ActionUrlMapping.GLOBAL.get(Constants.ACTION_FAILURE));
			log.error("Exception in execute:" + e);
			// Only add the general error if no other errors are present
			if (errors.isEmpty()) {
				errors.add("error", "errors.general");
			}
		}

		if (!exceptionOccurred) {
			// forward = mapping.findForward("open");
			mav.setViewName(ActionUrlMapping.PARENTSEARCHSELECTORACTIONS.get("open"));
		}

		// If a message is required, save the specified key(s) into the request.
		if (!errors.isEmpty()) {
			log.debug("FAILED");
			mav.setViewName(ActionUrlMapping.GLOBAL.get(Constants.ACTION_FAILURE));
		}

		request.setAttribute("actionMessages", errors);
		request.setAttribute("parentSearchSelectorForm", parentSearchSelectorForm);
		return mav;
	}

	/**
	 * The search() method get the values from the database.
	 * 
	 * @param mapping  The ActionMapping used to select this instance
	 * @param form     The ActionForm bean for this request
	 * @param request  The HTTP request we are processing
	 * @param response The HTTP response we are creating
	 * @return an ActionForward instance describing where and how control should be
	 *         forwarded, or null if the response has already been completed.
	 * @throws Exception if an exception occurs
	 */
	@RequestMapping(value = "/parentSearchSelector", method = { RequestMethod.GET,
			RequestMethod.POST }, params = { "action=search" })
	public ModelAndView search(@ModelAttribute ParentSearchSelectorForm parentSearchSelectorForm,
			HttpServletRequest request, HttpServletResponse response) throws Exception {
		ModelAndView mav = new ModelAndView();
		ActionMessages errors = new ActionMessages();
		boolean exceptionOccurred = false;

		try {

			// Get the list of vendors and put them into the bean for the JSP page
			List searchResults = chargebackCommonDao.doParentSearch(
					parentSearchSelectorForm.getParentNumber(),
					parentSearchSelectorForm.getParentName());
			parentSearchSelectorForm.setSearchResults(searchResults);
			parentSearchSelectorForm.setResults(new Integer(searchResults.size()));

		} catch (Exception e) {
			// Determine the error, log it, and put an error message in ActionErrors
			exceptionOccurred = true;
			// forward = mapping.findForward("failure");
			mav.setViewName(ActionUrlMapping.GLOBAL.get(Constants.ACTION_FAILURE));

			log.error("Exception in execute:" + e);

			// Only add the general error if no other errors are present
			if (errors.isEmpty()) {
				errors.add("error", "errors.general");
			}
		}

		if (!exceptionOccurred) {
			// forward = mapping.findForward("open");
			mav.setViewName(ActionUrlMapping.PARENTSEARCHSELECTORACTIONS.get("open"));
		}

		// If a message is required, save the specified key(s) into the request.
		if (!errors.isEmpty()) {
			log.debug("FAILED");
			mav.setViewName(ActionUrlMapping.GLOBAL.get(Constants.ACTION_FAILURE));
		}

		request.setAttribute("actionMessages", errors);
		request.setAttribute("parentSearchSelectorForm", parentSearchSelectorForm);
		return mav;
	}

}
