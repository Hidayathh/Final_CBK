package com.unfi.cbk.bo;

import java.util.Date;

import com.unfi.cbk.util.DateFunctions;

/**
 * The Chargeback class is a means for representing a single result when
 * searching for Chargebacks.
 * <p>
 * Each property represents a column in the display table.
 *
 * @author vpil001
 * @since 1.0
 */

public class LawsonExportBO {

	/*
	 * CBK
	 */

	public LawsonExportBO() {

	}

	public LawsonExportBO(String invoiceNumber) {
		this.invoiceNumber = invoiceNumber;
	}

	private Integer uploadAp; 
	private Integer accountReq; 
	private Integer vendorReq; 
	private Integer credit; 
	private Integer uploadFood; 
	private Integer selectable;
	
	private Date oldDueDate;
	
	public Date getOldDueDate() {
		return oldDueDate;
	}

	public void setOldDueDate(Date oldDueDate) {
		this.oldDueDate = oldDueDate;
	}

	private Date updatedDueDate;
	public Date getUpdatedDueDate() {
		return updatedDueDate;
	}

	public void setUpdatedDueDate(Date updatedDueDate) {
		this.updatedDueDate = updatedDueDate;
	}
	
	public String getUpdatedDueDateString() {
		String s = null;
		if (updatedDueDate != null) {
			s = DateFunctions.formatDate(updatedDueDate);
		}
		return s;
	}
	
	public String getOldDueDateString() {
		String s = null;
		if (oldDueDate != null) {
			s = DateFunctions.formatDate(oldDueDate);
		}
		return s;
	}
	
	
	
	private String chargebackType;
	private String approvalRouting;
	
	public String getApprovalRouting() {
		return approvalRouting;
	}

	public void setApprovalRouting(String approvalRouting) {
		this.approvalRouting = approvalRouting;
	}
	
	public String getChargebackType() {
		return chargebackType;
	}

	public void setChargebackType(String chargebackType) {
		this.chargebackType = chargebackType;
	}


	public Integer getUploadAp() {
		return uploadAp;
	}

	public void setUploadAp(Integer uploadAp) {
		this.uploadAp = uploadAp;
	}

	public Integer getAccountReq() {
		return accountReq;
	}

	public void setAccountReq(Integer accountReq) {
		this.accountReq = accountReq;
	}

	public Integer getVendorReq() {
		return vendorReq;
	}

	public void setVendorReq(Integer vendorReq) {
		this.vendorReq = vendorReq;
	}

	public Integer getCredit() {
		return credit;
	}

	public void setCredit(Integer credit) {
		this.credit = credit;
	}

	public Integer getUploadFood() {
		return uploadFood;
	}

	public void setUploadFood(Integer uploadFood) {
		this.uploadFood = uploadFood;
	}

	public Integer getSelectable() {
		return selectable;
	}

	public void setSelectable(Integer selectable) {
		this.selectable = selectable;
	}
	
		
	
	private String vendorNumber;
	public String getVendorNumber() {
		return vendorNumber;
	}

	public void setVendorNumber(String vendorNumber) {
		this.vendorNumber = vendorNumber;
	}

	public String getrName() {
		return rName;
	}

	public void setrName(String rName) {
		this.rName = rName;
	}

	public String getAccNumber() {
		return accNumber;
	}

	public void setAccNumber(String accNumber) {
		this.accNumber = accNumber;
	}

	public String getAmount() {
		return amount;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}

	private String rName;
	
	private String accNumber;
	private String amount;

	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}

	public String getExportedDate() {
		return exportedDate;
	}

	public void setExportedDate(String exportedDate) {
		this.exportedDate = exportedDate;
	}

	public String getExportedId() {
		return exportedId;
	}

	public void setExportedId(String exportedId) {
		this.exportedId = exportedId;
	}

	public String getExportedAmount() {
		return exportedAmount;
	}

	public void setExportedAmount(String exportedAmount) {
		this.exportedAmount = exportedAmount;
	}

	public String getParentName() {
		return parentName;
	}

	public void setParentName(String parentName) {
		this.parentName = parentName;
	}

	public String getStateCode() {
		return stateCode;
	}

	public void setStateCode(String stateCode) {
		this.stateCode = stateCode;
	}

	public String getExporterName() {
		return exporterName;
	}

	public void setExporterName(String exporterName) {
		this.exporterName = exporterName;
	}

	private String time;
	private String exportedDate;
	private String exportedId;
	private String exportedAmount;

	private String parentName;
	private String stateCode;

	private String exporterName;

	private String companyCode;
	private String invoiceNumber;
	private String locationNumber;
	private String locationName;
	private Date invoiceDate;
	private String vendorId;
	private String netAmount;
	private String chargebackTotal;

	private String roles;
	private String openingForms;
	private String description;
	private String originator;
	private String approver;
	private String fin;
	private String ca;
	private int documentNumber;
	private Integer typeId;
	private String typeName;
	private Integer memberCount;
	private String documentEncKey;
	private Date checkDate;
	private Date bankClearDate;
	private Date dueDate;
	private Date lastApprovalDate;
	public Date getLastApprovalDate() {
		return lastApprovalDate;
	}

	public void setLastApprovalDate(Date lastApprovalDate) {
		this.lastApprovalDate = lastApprovalDate;
	}

	public String getUpdateDetailValue() {
		return updateDetailValue;
	}

	public void setUpdateDetailValue(String updateDetailValue) {
		this.updateDetailValue = updateDetailValue;
	}

	private String updateDetailValue;
	private String docType;
	private String mimeType;
	private String notFound;
	private String creatorId;
	private String originalApprover;
	private String dcNumber;
	private Integer itemNumber;
	private Integer itemPack;
	private String itemSize;
	private String itemDesc;
	private String itemUpc;
	private String itemSlot;
	private String division;
	private String region;
	private String subFund;
	private String subFundNumber;
	private Integer itemQuantity;
	private Double itemPrice;
	private Double extension;
	
	public String getNextApprover() {
		return nextApprover;
	}

	public void setNextApprover(String nextApprover) {
		this.nextApprover = nextApprover;
	}

	private String nextApprover;

	private String accountNumber;
	private String distLocNumber;
	private String productGrp;
	private Double distributionAmt;
	private String vendorInvoice;

	private Integer attachment;
	private Integer barCode;
	private String shortDesc;
	private Integer exported;
	private Integer cancelled;
	private Integer inProcess;
	private String nextAproverId;
	private String interInstr;
	private String referenceNumber;

	private String Total;

	private String stepNumber;
	
	private String TotalAccruals;
	private boolean isNew;
	private String vendor;

	private String routeName;
	
	private String chargebackReason;
	
	public String getChargebackReason() {
		return chargebackReason;
	}

	public void setChargebackReason(String chargebackReason) {
		this.chargebackReason = chargebackReason;
	}

	public String geteDICode() {
		return eDICode;
	}

	public void seteDICode(String eDICode) {
		this.eDICode = eDICode;
	}

	public String getBalanceSheet() {
		return balanceSheet;
	}

	public void setBalanceSheet(String balanceSheet) {
		this.balanceSheet = balanceSheet;
	}

	public String getActive() {
		return active;
	}

	public void setActive(String active) {
		this.active = active;
	}

	public String getAuthorizationAmount() {
		return authorizationAmount;
	}

	public void setAuthorizationAmount(String authorizationAmount) {
		this.authorizationAmount = authorizationAmount;
	}

	public String getByType() {
		return byType;
	}

	public void setByType(String byType) {
		this.byType = byType;
	}

	private String eDICode;
	private String balanceSheet;
	private String active;

	
	private String authorizationAmount;
	private String byType;

	public String getTotalAccruals() {
		return TotalAccruals;
	}

	public void setTotalAccruals(String totalAccruals) {
		TotalAccruals = totalAccruals;
	}

	public boolean isNew() {
		return isNew;
	}

	public void setNew(boolean isNew) {
		this.isNew = isNew;
	}

	public String getVendor() {
		return vendor;
	}

	public void setVendor(String vendor) {
		this.vendor = vendor;
	}

	public String getRouteName() {
		return routeName;
	}

	public void setRouteName(String routeName) {
		this.routeName = routeName;
	}

	




	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getOpeningForms() {
		return openingForms;
	}

	public void setOpeningForms(String openingForms) {
		this.openingForms = openingForms;
	}

	public String getRoles() {
		return roles;
	}

	public void setRoles(String roles) {
		this.roles = roles;
	}

	public String getOriginalApprover() {
		return originalApprover;
	}

	public void setOriginalApprover(String originalApprover) {
		this.originalApprover = originalApprover;
	}

	public Date getApprovalDate() {
		return approvalDate;
	}

	public void setApprovalDate(Date approvalDate) {
		this.approvalDate = approvalDate;
	}

	private Date approvalDate;

	public String getChargebackTotal() {
		return chargebackTotal;
	}

	public void setChargebackTotal(String chargebackTotal) {
		this.chargebackTotal = chargebackTotal;
	}

	public String getTotal() {
		return Total;
	}

	public void setTotal(String total) {
		Total = total;
	}

	public String getStepNumber() {
		return stepNumber;
	}

	public void setStepNumber(String stepNumber) {
		this.stepNumber = stepNumber;
	}

	public String getRouteId() {
		return routeId;
	}

	public void setRouteId(String routeId) {
		this.routeId = routeId;
	}

	public String getApproverName() {
		return approverName;
	}

	public void setApproverName(String approverName) {
		this.approverName = approverName;
	}

	private String productGrpCode;

	// private String roleId;
	private String role;
	private String routeId;

	private Integer roleId;
	private String roleDesc;
	private String defForm;
	private String approverId;
	private String approverName;
	private Integer lineNumber;
	private String productCode;
	private String reasonAcctNumber;
	private String reasonCode;
	private String prdGrpCode;
	private String vendorName;

	private String subFundsForChargeback;

	public String getSubFundsForChargeback() {
		return subFundsForChargeback;
	}

	public void setSubFundsForChargeback(String subFundsForChargeback) {
		this.subFundsForChargeback = subFundsForChargeback;
	}

	public Double getExtension() {
		return extension;
	}

	public void setExtension(Double extension) {
		this.extension = extension;
	}

	public String getVendorName() {
		return vendorName;
	}

	public void setVendorName(String vendorName) {
		this.vendorName = vendorName;
	}

	public String getVendorAddr1() {
		return vendorAddr1;
	}

	public void setVendorAddr1(String vendorAddr1) {
		this.vendorAddr1 = vendorAddr1;
	}

	public String getVendorAddr2() {
		return vendorAddr2;
	}

	public void setVendorAddr2(String vendorAddr2) {
		this.vendorAddr2 = vendorAddr2;
	}

	public String getVendorCity() {
		return vendorCity;
	}

	public void setVendorCity(String vendorCity) {
		this.vendorCity = vendorCity;
	}

	public String getVendorState() {
		return vendorState;
	}

	public void setVendorState(String vendorState) {
		this.vendorState = vendorState;
	}

	public String getVendorPostCode() {
		return vendorPostCode;
	}

	public void setVendorPostCode(String vendorPostCode) {
		this.vendorPostCode = vendorPostCode;
	}

	private String vendorAddr1;
	private String vendorAddr2;
	private String vendorCity;
	private String vendorState;
	private String vendorPostCode;

	public String getReferenceNumber() {
		return referenceNumber;
	}

	public void setReferenceNumber(String referenceNumber) {
		this.referenceNumber = referenceNumber;
	}

	public String getSubFund() {
		return subFund;
	}

	public void setSubFund(String subFund) {
		this.subFund = subFund;
	}

	public String getSubFundNumber() {
		return subFundNumber;
	}

	public void setSubFundNumber(String subFundNumber) {
		this.subFundNumber = subFundNumber;
	}

	public String getReasonAcctNumber() {
		return reasonAcctNumber;
	}

	public void setReasonAcctNumber(String reasonAcctNumber) {
		this.reasonAcctNumber = reasonAcctNumber;
	}

	public String getLocationName() {
		return locationName;
	}

	public void setLocationName(String locationName) {
		this.locationName = locationName;
	}

	public Integer getLineNumber() {
		return lineNumber;
	}

	public void setLineNumber(Integer lineNumber) {
		this.lineNumber = lineNumber;
	}

	public String getProductCode() {
		return productCode;
	}

	public void setProductCode(String productCode) {
		this.productCode = productCode;
	}

	/*
	 * public String getRoleId() { return roleId; }
	 * 
	 * public void setRoleId(String roleId) { this.roleId = roleId; }
	 */
	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public Integer getRoleId() {
		return roleId;
	}

	public void setRoleId(Integer roleId) {
		this.roleId = roleId;
	}

	public String getRoleDesc() {
		return roleDesc;
	}

	public void setRoleDesc(String roleDesc) {
		this.roleDesc = roleDesc;
	}

	public String getDefForm() {
		return defForm;
	}

	public void setDefForm(String defForm) {
		this.defForm = defForm;
	}

	public String getApproverId() {
		return approverId;
	}

	public void setApproverId(String approverId) {
		this.approverId = approverId;
	}

	public Date getCheckDate() {
		return checkDate;
	}

	public void setCheckDate(Date checkDate) {
		this.checkDate = checkDate;
	}

	public String getVendorInvoice() {
		return vendorInvoice;
	}

	public void setVendorInvoice(String vendorInvoice) {
		this.vendorInvoice = vendorInvoice;
	}

	public Integer getAttachment() {
		return attachment;
	}

	public void setAttachment(Integer attachment) {
		this.attachment = attachment;
	}

	public Integer getBarCode() {
		return barCode;
	}

	public void setBarCode(Integer barCode) {
		this.barCode = barCode;
	}

	public String getShortDesc() {
		return shortDesc;
	}

	public void setShortDesc(String shortDesc) {
		this.shortDesc = shortDesc;
	}

	public Integer getExported() {
		return exported;
	}

	public void setExported(Integer exported) {
		this.exported = exported;
	}

	public Integer getCancelled() {
		return cancelled;
	}

	public void setCancelled(Integer cancelled) {
		this.cancelled = cancelled;
	}

	public Integer getInProcess() {
		return inProcess;
	}

	public void setInProcess(Integer inProcess) {
		this.inProcess = inProcess;
	}

	public String getNextAproverId() {
		return nextAproverId;
	}

	public void setNextAproverId(String nextAproverId) {
		this.nextAproverId = nextAproverId;
	}

	public String getInterInstr() {
		return interInstr;
	}

	public void setInterInstr(String interInstr) {
		this.interInstr = interInstr;
	}

	public String getProductGrpCode() {
		return productGrpCode;
	}

	public void setProductGrpCode(String productGrpCode) {
		this.productGrpCode = productGrpCode;
	}

	public String getCompanyCode() {
		return companyCode;
	}

	public void setCompanyCode(String companyCode) {
		this.companyCode = companyCode;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getDistLocNumber() {
		return distLocNumber;
	}

	public void setDistLocNumber(String distLocNumber) {
		this.distLocNumber = distLocNumber;
	}

	public String getProductGrp() {
		return productGrp;
	}

	public void setProductGrp(String productGrp) {
		this.productGrp = productGrp;
	}

	public Double getDistributionAmt() {
		return distributionAmt;
	}

	public void setDistributionAmt(Double distributionAmt) {
		this.distributionAmt = distributionAmt;
	}

	public String getDocType() {
		return docType;
	}

	public void setDocType(String docType) {
		this.docType = docType;
	}

	public String getDcNumber() {
		return dcNumber;
	}

	public void setDcNumber(String dcNumber) {
		this.dcNumber = dcNumber;
	}

	public Integer getItemNumber() {
		return itemNumber;
	}

	public void setItemNumber(Integer itemNumber) {
		this.itemNumber = itemNumber;
	}

	public Integer getItemPack() {
		return itemPack;
	}

	public void setItemPack(Integer itemPack) {
		this.itemPack = itemPack;
	}

	public String getItemSize() {
		return itemSize;
	}

	public void setItemSize(String itemSize) {
		this.itemSize = itemSize;
	}

	public String getItemDesc() {
		return itemDesc;
	}

	public void setItemDesc(String itemDesc) {
		this.itemDesc = itemDesc;
	}

	public String getItemUpc() {
		return itemUpc;
	}

	public void setItemUpc(String itemUpc) {
		this.itemUpc = itemUpc;
	}

	public String getItemSlot() {
		return itemSlot;
	}

	public void setItemSlot(String itemSlot) {
		this.itemSlot = itemSlot;
	}

	public String getDivision() {
		return division;
	}

	public void setDivision(String division) {
		this.division = division;
	}

	public String getRegion() {
		return region;
	}

	public void setRegion(String region) {
		this.region = region;
	}

	public Integer getItemQuantity() {
		return itemQuantity;
	}

	public void setItemQuantity(Integer itemQuantity) {
		this.itemQuantity = itemQuantity;
	}

	public Double getItemPrice() {
		return itemPrice;
	}

	public void setItemPrice(Double itemPrice) {
		this.itemPrice = itemPrice;
	}

	public String getCreatorId() {
		return creatorId;
	}

	public void setCreatorId(String creatorId) {
		this.creatorId = creatorId;
	}

	public String getReasonCode() {
		return reasonCode;
	}

	public void setReasonCode(String reasonCode) {
		this.reasonCode = reasonCode;
	}

	public String getPrdGrpCode() {
		return prdGrpCode;
	}

	public void setPrdGrpCode(String prdGrpCode) {
		this.prdGrpCode = prdGrpCode;
	}

	public Integer getTypeId() {
		return typeId;
	}

	public void setTypeId(Integer typeId) {
		this.typeId = typeId;
	}

	public String getTypeName() {
		return typeName;
	}

	public void setTypeName(String typeName) {
		this.typeName = typeName;
	}

	public Integer getMemberCount() {
		return memberCount;
	}

	public void setMemberCount(Integer memberCount) {
		this.memberCount = memberCount;
	}

	public String getInvoiceNumber() {
		return invoiceNumber;
	}

	public void setInvoiceNumber(String invoiceNumber) {
		this.invoiceNumber = invoiceNumber;
	}

	public String getLocationNumber() {
		return locationNumber;
	}

	public void setLocationNumber(String locationNumber) {
		this.locationNumber = locationNumber;
	}

	public String getVendorId() {
		return vendorId;
	}

	public void setVendorId(String vendorId) {
		this.vendorId = vendorId;
	}

	public int getDocumentNumber() {
		return documentNumber;
	}

	public void setDocumentNumber(int documentNumber) {
		this.documentNumber = documentNumber;
	}

	public Date getInvoiceDate() {
		return invoiceDate;
	}

	public void setInvoiceDate(Date invoiceDate) {
		this.invoiceDate = invoiceDate;
	}
	
	

	/*
	 * public String getVendor() { return vendor; }
	 * 
	 * public void setVendor(String vendor) { this.vendor = vendor; }
	 */

	public String getNetAmount() {
		return netAmount;
	}

	public void setNetAmount(String netAmount) {
		this.netAmount = netAmount;
	}

	public String getOriginator() {
		return originator;
	}

	public void setOriginator(String originator) {
		this.originator = originator;
	}

	public String getApprover() {
		return approver;
	}

	public void setApprover(String approver) {
		this.approver = approver;
	}

	public String getFin() {
		return fin;
	}

	public void setFin(String fin) {
		this.fin = fin;
	}

	public String getCa() {
		return ca;
	}

	public void setCa(String ca) {
		this.ca = ca;
	}

	public String getNotFound() {
		return notFound;
	}

	public void setNotFound(String notFound) {
		this.notFound = notFound;
	}

	public String getLastApprovalDateString() {
		String s = null;
		if (lastApprovalDate != null) {
			s = DateFunctions.formatDate(lastApprovalDate);
		}
		return s;
	}

	public void setLastApprovalDateString(String s) {
		if (s != null && s.trim().length() > 0) {
			lastApprovalDate = DateFunctions.stringToDate(s);
		}
	}
	
	
	
	public String getInvoiceDateString() {
		String s = null;
		if (invoiceDate != null) {
			s = DateFunctions.formatDate(invoiceDate);
		}
		return s;
	}

	public void setInvoiceDateString(String s) {
		if (s != null && s.trim().length() > 0) {
			invoiceDate = DateFunctions.stringToDate(s);
		}
	}
	private String maxAmount;

	public String getMaxAmount() {
		return maxAmount;
	}

	public void setMaxAmount(String maxAmount) {
		this.maxAmount = maxAmount;
	}

	/**
	 * Get documentEncKey
	 * 
	 * @return String
	 */
	public String getDocumentEncKey() {
		return documentEncKey;
	}

	/**
	 * Set documentEncKey
	 * 
	 * @param string <code>String</code> to set
	 */
	public void setDocumentEncKey(String string) {
		documentEncKey = string;
	}

	public String getCheckDateString() {
		String s = null;
		if (checkDate != null) {
			s = DateFunctions.formatDate(checkDate);
		}
		return s;
	}

	public void setCheckDateString(String s) {
		if (s != null && s.trim().length() > 0) {
			checkDate = DateFunctions.stringToDate(s);
		}
	}

	/**
	 * @return
	 */
	public Date getBankClearDate() {
		return bankClearDate;
	}

	/**
	 * @param date
	 */
	public void setBankClearDate(Date date) {
		bankClearDate = date;
	}

	public String getBankClearDateString() {
		String s = null;
		if (bankClearDate != null) {
			s = DateFunctions.formatDate(bankClearDate);
		}
		return s;
	}

	/**
	 * @return
	 */
	public String getMimeType() {
		return mimeType;
	}

	/**
	 * @param string
	 */
	public void setMimeType(String string) {
		mimeType = string;
	}

	/**
	 * @return
	 */
	public Date getDueDate() {
		return dueDate;
	}

	/**
	 * @param date
	 */
	public void setDueDate(Date date) {
		dueDate = date;
	}

	public String getDueDateString() {
		String s = null;
		if (dueDate != null) {
			s = DateFunctions.formatDate(dueDate);
		}
		return s;
	}
}
