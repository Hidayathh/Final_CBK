/*
 * Created on Nov 01, 2005
 */
package com.unfi.cbk.bo;

import java.io.InputStream;

/**
 * The Attachment class is a way of representing a single result when listing
 * attachment.
 * 
 * Each field corresponds to a column in the display table.
 * 
 * @author yhp6y2l
 * @version 1.0
 */
public class Attachment {

	private AttachmentType attachmentType;
	private int compressedFlag;
	private InputStream content = null;
	private int id;
	private String filename = null;
	private String mimeType = null;
	private String path = null;
	private int requestId;

	public void setAttachmentType(AttachmentType type) {
		attachmentType = type;
	}

	public AttachmentType getAttachmentType() {
		return attachmentType;
	}

	public int getCompressedFlag() {
		return compressedFlag;
	}

	public void setCompressedFlag(int i) {
		compressedFlag = i;
	}

	public InputStream getContent() {
		return content;
	}

	public void setContent(InputStream bs) {
		content = bs;
	}

	public String getFilename() {
		return filename;
	}

	public void setFilename(String string) {
		filename = string;
	}

	public int getId() {
		return id;
	}

	public void setId(int i) {
		id = i;
	}

	public String getMimeType() {
		return mimeType;
	}

	public void setMimeType(String string) {
		mimeType = string;
	}

	public String getPath() {
		return path;
	}

	public void setPath(String string) {
		path = string;
	}

	public int getRequestId() {
		return requestId;
	}

	public void setRequestId(int i) {
		requestId = i;
	}

}
