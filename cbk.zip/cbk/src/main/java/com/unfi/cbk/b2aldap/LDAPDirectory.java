package com.unfi.cbk.b2aldap;

import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Vector;

import javax.naming.AuthenticationException;
import javax.naming.Name;
import javax.naming.NameAlreadyBoundException;
import javax.naming.NameNotFoundException;
import javax.naming.NameParser;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.AttributeModificationException;
import javax.naming.directory.BasicAttribute;
import javax.naming.directory.BasicAttributes;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;
import javax.naming.directory.ModificationItem;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;

public class LDAPDirectory {

	private DirContext theContext;
	private NameParser nameParser;
	private String host;
	private int port;
	private int ldapVersion;
	private int limit;
	private int timeout;

	public LDAPDirectory() {
		theContext = null;
		nameParser = null;
		host = null;
		limit = 0;
		timeout = 0;
	}

	private BasicAttribute convertValues(String name, Object values[]) {
		BasicAttribute att = new BasicAttribute(name);
		for (int i = 0; i < values.length; i++)
			att.add(values[i]);

		return att;
	}

	private BasicAttributes convertHashtable(Hashtable hTable) {
		BasicAttributes atts = new BasicAttributes();
		BasicAttribute at;
		for (Enumeration e = hTable.keys(); e.hasMoreElements(); atts.put(at)) {
			String key = (String) e.nextElement();
			Object values[] = (Object[]) hTable.get(key);
			at = convertValues(key, values);
		}

		return atts;
	}

	public void connect(String host, int port, int ldapVersion, String userName, String password) throws Exception {
		this.host = host;
		this.port = port;
		this.ldapVersion = ldapVersion;

		try {
			Hashtable env = new Hashtable(11);
			env.put("java.naming.ldap.version", String.valueOf(ldapVersion));
			env.put("java.naming.factory.initial", "com.sun.jndi.ldap.LdapCtxFactory");
			env.put("java.naming.provider.url", "ldap://" + host + ":" + port);
			env.put("java.naming.security.authentication", "simple");
			env.put("java.naming.security.protocol", "ssl");
			// env.put("javax.net.ssl.trustStore", trustStore);
			// env.put("javax.net.ssl.keyStorePassword", keyStorePassword);
			env.put("java.naming.security.principal", userName);
			env.put("java.naming.security.credentials", password);
			theContext = new InitialDirContext(env);

		} catch (NamingException e) {
			String tMsg = "Unable to connect to LDAP server.";
			throw new Exception(tMsg);
		}
	}

	public void disconnect() throws Exception {
		if (theContext != null)
			try {
				theContext.close();
				theContext = null;
			} catch (NamingException e) {
				String tMsg = "Unable while disconnecting from LDAP server.";
				throw new Exception(tMsg);
			}
	}

	public boolean isValidPassword(String userName, String password) throws Exception {
		if (password.length() == 0)
			return false;
		DirContext tContext = null;
		boolean rc = false;
		Hashtable env = new Hashtable(11);
		env.put("java.naming.ldap.version", String.valueOf(ldapVersion));
		env.put("java.naming.factory.initial", "com.sun.jndi.ldap.LdapCtxFactory");
		env.put("java.naming.provider.url", "ldap://" + host + ":" + port);
		env.put("java.naming.security.authentication", "simple");
		env.put("java.naming.security.principal", userName);
		env.put("java.naming.security.credentials", password);
		try {
			tContext = new InitialDirContext(env);
			tContext = null;
			rc = true;
		} catch (AuthenticationException authenticationexception) {
		} catch (NamingException e) {
			String tMsg = "Unable to authenticate user in LDAP.";
			throw new Exception(tMsg);
		}
		return rc;
	}

	public Name convertToName(String dn) throws Exception {
		Name ret;
		try {
			if (nameParser == null)
				nameParser = theContext.getNameParser("");
			ret = nameParser.parse(dn);
		} catch (NamingException e) {
			String tMsg = e.toString();
			throw new Exception(tMsg);
		}
		return ret;
	}

	public boolean existObject(String dn) throws Exception {
		boolean rc = false;
		try {
			theContext.getAttributes(dn, new String[0]);
			rc = true;
		} catch (NameNotFoundException namenotfoundexception) {
		} catch (NamingException e) {
			String tMsg = "Unable to check for object in LDAP.  Error: " + e.toString();
			throw new Exception(tMsg);
		}
		return rc;
	}

	public boolean existAttributeInObject(String dn, String attribName, String attribValue) throws Exception {
		String tObjectPath = "";
		boolean rc = false;
		String tObjectName;
		try {
			Name tDNName = convertToName(dn);
			tObjectName = tDNName.get(tDNName.size() - 1);
			for (int x = tDNName.size() - 2; x >= 0; x--) {
				if (tObjectPath.length() > 0)
					tObjectPath = tObjectPath + ",";
				tObjectPath = tObjectPath + tDNName.get(x);
			}

		} catch (Exception e) {
			return false;
		}
		NamingEnumeration results = null;
		try {
			String filter = "(&(" + tObjectName + ")(" + attribName + "=" + attribValue + "))";
			results = search(tObjectPath, filter, new String[0], 1);
			if (results != null && results.hasMoreElements())
				rc = true;
		} catch (NameNotFoundException namenotfoundexception) {
		} catch (NamingException e) {
			String tMsg = "LDAP search failed.  Error: " + e.toString();
			throw new Exception(tMsg);
		} finally {
			if (results != null)
				try {
					results.close();
				} catch (Exception ignore) {
				}
		}
		return rc;
	}

	public void addObject(String dn, Hashtable attribs) throws Exception {
		try {
			javax.naming.directory.Attributes ats = convertHashtable(attribs);
			theContext.createSubcontext(dn, ats);
		} catch (NameAlreadyBoundException e) {
			String tMsg = "Unable to add object \"" + dn + "\" to LDAP.  Error: Object already exists.";
			throw new Exception(tMsg);
		} catch (NamingException e) {
			String tMsg = "Unable to add object \"" + dn + "\" to LDAP.  Error: " + e.toString();
			throw new Exception(tMsg);
		}
	}

	public void updateObject(String dn, Hashtable attribs) throws Exception {
		try {
			javax.naming.directory.Attributes ats = convertHashtable(attribs);
			theContext.modifyAttributes(dn, 2, ats);
		} catch (AttributeModificationException e) {
			String tMsg = "Unable to complete the update of object \"" + dn
					+ "\" in LDAP.  Some changes may not have been saved.";
			throw new Exception(tMsg);
		} catch (NamingException e) {
			String tMsg = "Unable to update object \"" + dn + "\" in LDAP.  Error: " + e.toString();
			throw new Exception(tMsg);
		}
	}

	public void deleteObject(String dn) throws Exception {
		try {
			theContext.destroySubcontext(dn);
		} catch (NamingException e) {
			String tMsg = "Unable to delete object \"" + dn + "\" from LDAP.  Error: " + e.toString();
			throw new Exception(tMsg);
		}
	}

	public void renameObject(String oldDN, String newDN) throws Exception {
		try {
			theContext.rename(oldDN, newDN);
		} catch (NameAlreadyBoundException e) {
			String tMsg = "Unable to rename object \"" + oldDN + "\" to \"" + newDN
					+ "\" in LDAP.  An object with the new name already exists.  Error: " + e.toString();
			throw new Exception(tMsg);
		} catch (NamingException e) {
			String tMsg = "Unable to rename object \"" + oldDN + "\" to \"" + newDN + "\" in LDAP.  Error: "
					+ e.toString();
			throw new Exception(tMsg);
		}
	}

	private void modifyObject(String dn, int mod_type, String attr, Object values[]) throws Exception {
		ModificationItem mods[] = new ModificationItem[1];
		BasicAttribute mod1;
		if (values == null)
			mod1 = new BasicAttribute(attr);
		else
			mod1 = convertValues(attr, values);
		mods[0] = new ModificationItem(mod_type, mod1);
		theContext.modifyAttributes(dn, mods);
	}

	public void addAttribute(String dn, String attr, Object values[]) throws Exception {
		try {
			modifyObject(dn, 1, attr, values);
		} catch (NamingException e) {
			String tMsg = "Unable to add \"" + attr + "\" attribute for " + dn + " in LDAP.  Error: " + e.toString();
			throw new Exception(tMsg);
		}
	}

	public void updateAttribute(String dn, String attr, Object values[]) throws Exception {
		try {
			modifyObject(dn, 2, attr, values);
		} catch (NamingException e) {
			String tMsg = "Unable to update \"" + attr + "\" attribute for " + dn + " in LDAP.  Error: " + e.toString();
			throw new Exception(tMsg);
		}
	}

	public void deleteAttribute(String dn, String attr, Object values[]) throws Exception {
		try {
			modifyObject(dn, 3, attr, values);
		} catch (NamingException e) {
			String tMsg = "Unable to delete \"" + attr + "\" attribute for " + dn + " in LDAP.  Error: " + e.toString();
			throw new Exception(tMsg);
		}
	}

	private NamingEnumeration search(String dn, String filter, String attribs[], int type) throws NamingException {
		SearchControls constraints = new SearchControls();
		constraints.setSearchScope(type);
		constraints.setCountLimit(limit);
		constraints.setTimeLimit(timeout);
		constraints.setReturningAttributes(attribs);
		NamingEnumeration results = theContext.search(dn, filter, constraints);
		return results;
	}

	public Vector search(String dn, String filter, boolean one_level) throws Exception {
		NamingEnumeration results = null;
		Vector tmp = new Vector();
		try {
			int scope = one_level ? 1 : 2;
			for (results = search(dn, filter, new String[0], scope); results != null && results.hasMoreElements();) {
				SearchResult srchResult = (SearchResult) results.next();
				String name = srchResult.getName().trim();
				if (name.length() == 0)
					tmp.addElement(dn);
				else
					tmp.addElement(name + "," + dn);
			}

		} catch (NameNotFoundException namenotfoundexception) {
		} catch (NamingException e) {
			String tMsg = "LDAP search failed.  Error: " + e.toString();
			throw new Exception(tMsg);
		} finally {
			if (results != null)
				try {
					results.close();
				} catch (Exception ignore) {
				}
		}
		return tmp.isEmpty() ? null : tmp;
	}

	public Vector search(String dn, String filter, String attribs[], boolean one_level) throws Exception {
		NamingEnumeration results = null;
		NamingEnumeration ae = null;
		Vector retVect = new Vector();
		try {
			int scope = one_level ? 1 : 2;
			Vector tVect;
			for (results = search(dn, filter, attribs, scope); results != null && results.hasMoreElements(); retVect
					.addElement(tVect)) {
				String attrID = null;
				Hashtable hTable = new Hashtable();
				tVect = new Vector();
				SearchResult srchResult = (SearchResult) results.next();
				String name = srchResult.getName().trim();
				if (name.length() == 0)
					tVect.addElement(dn);
				else
					tVect.addElement(name + "," + dn);
				BasicAttributes attrs = (BasicAttributes) srchResult.getAttributes();
				Object valuesA[];
				for (ae = attrs.getAll(); ae.hasMoreElements(); hTable.put(attrID, ((Object) (valuesA)))) {
					BasicAttribute attr = (BasicAttribute) ae.next();
					attrID = attr.getID().toLowerCase();
					valuesA = new Object[attr.size()];
					int i = 0;
					for (Enumeration vals = attr.getAll(); vals.hasMoreElements();) {
						Object tmp = vals.nextElement();
						valuesA[i] = tmp;
						i++;
					}

				}

				try {
					ae.close();
				} catch (Exception exception) {
				}
				ae = null;
				tVect.addElement(hTable);
			}

		} catch (NameNotFoundException namenotfoundexception) {
		} catch (NamingException e) {
			String tMsg = "LDAP search failed.  Error: " + e.toString();
			throw new Exception(tMsg);
		} finally {
			if (ae != null)
				try {
					ae.close();
				} catch (Exception exception2) {
				}
			if (results != null)
				try {
					results.close();
				} catch (Exception ignore) {
				}
		}
		return retVect.isEmpty() ? null : retVect;
	}

	public Hashtable read(String dn, String attribs[]) throws Exception {
		NamingEnumeration results = null;
		NamingEnumeration ae = null;
		Object tmp = null;
		Hashtable hTable = new Hashtable();

		try {
			String attrID = null;
			results = search(dn, "(objectclass=*)", attribs, 0);
			if (results != null && results.hasMoreElements()) {
				SearchResult srchResult = (SearchResult) results.next();
				BasicAttributes attrs = (BasicAttributes) srchResult.getAttributes();
				Object valuesA[];
				for (ae = attrs.getAll(); ae.hasMoreElements(); hTable.put(attrID, ((Object) (valuesA)))) {
					BasicAttribute attr = (BasicAttribute) ae.next();
					attrID = attr.getID().toLowerCase();
					valuesA = new Object[attr.size()];
					int i = 0;
					for (Enumeration vals = attr.getAll(); vals.hasMoreElements();) {
						tmp = vals.nextElement();
						valuesA[i] = tmp;
						i++;
					}

				}

			}
		} catch (NameNotFoundException namenotfoundexception) {
		} catch (NamingException e) {
			String tMsg = "Unable to read LDAP attributes.  Error: " + e.toString();
			throw new Exception(tMsg);
		} finally {
			if (ae != null)
				try {
					ae.close();
				} catch (Exception exception1) {
				}
			if (results != null)
				try {
					results.close();
				} catch (Exception ignore) {
				}
		}
		return hTable.isEmpty() ? null : hTable;
	}

	public static void main(String arguments[]) throws Exception {
		
	}

	// CO 14091 - Start
	public Hashtable read(String dn, String filter, String attribs[], int scope) throws Exception {
		NamingEnumeration results = null;
		NamingEnumeration ae = null;
		Object tmp = null;
		Hashtable hTable = new Hashtable();

		try {
			String attrID = null;
			results = search(dn, filter, attribs, scope);
			if (results != null && results.hasMoreElements()) {
				SearchResult srchResult = (SearchResult) results.next();
				BasicAttributes attrs = (BasicAttributes) srchResult.getAttributes();
				Object valuesA[];
				for (ae = attrs.getAll(); ae.hasMoreElements(); hTable.put(attrID, ((Object) (valuesA)))) {
					BasicAttribute attr = (BasicAttribute) ae.next();
					attrID = attr.getID().toLowerCase();
					valuesA = new Object[attr.size()];
					int i = 0;
					for (Enumeration vals = attr.getAll(); vals.hasMoreElements();) {
						tmp = vals.nextElement();
						valuesA[i] = tmp;
						i++;
					}
				}
			}
		} catch (NameNotFoundException namenotfoundexception) {
		} catch (NamingException e) {
			String tMsg = "Unable to read LDAP attributes.  Error: " + e.toString();
			throw new Exception(tMsg);
		} finally {
			if (ae != null)
				try {
					ae.close();
				} catch (Exception exception1) {
				}
			if (results != null)
				try {
					results.close();
				} catch (Exception ignore) {
				}
		}
		return hTable.isEmpty() ? null : hTable;
	}
	// CO 14091 - End

}
