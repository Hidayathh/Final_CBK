package com.unfi.cbk.utilcore;

import java.io.IOException;
import java.io.InputStream;

import org.apache.commons.digester3.Digester;
import org.apache.commons.digester3.binder.DigesterLoader;
import org.apache.commons.digester3.xmlrules.FromXmlRulesModule;
import org.apache.log4j.Logger;
//import org.xml.sax.SAXException;

/**
 * The DigestXML class is used to translate XML files into objects.
 * 
 * @author yhp6y2l
 *
 */

public class DigestXML {
	static Logger log = Logger.getLogger(DigestXML.class);

	/**
	 * Creates an Object out of an XML file. The method takes an XML file and an
	 * XML-based rules file and transforms the XML file into a Java object based on
	 * the rules provided.
	 * <p>
	 * The Apache Jakarta Commons Digester is the source for this process.
	 * 
	 * @return an <code>Object</code> representing the XML file.
	 * @param file  the XML file to transform
	 * @param rules the XML rules file to use
	 * @since 1.0
	 */
	public Object createObject(String rulefile, String digesterFile) {

		DigesterLoader digesterLoader = DigesterLoader.newLoader(new FromXmlRulesModule() {

			@Override
			protected void loadRules() {
				// loadXMLRules( getClass(
				// ).getResource("/com/svharbor/dataxfer/config/menuRules.xml"));
				// loadXMLRules( getClass(
				// ).getResource("/com/svharbor/dataxfer/config/menuRules.xml"));
				loadXMLRules(getClass().getResource(rulefile));

			}
		});

		Digester digester = digesterLoader.newDigester();

		// Push a reference to the plays List on to the Stack
		// Object object= new Object();
		// digester.push(object);

		Object root = null;
		// Parse the XML document

		InputStream input = this.getClass().getResourceAsStream(digesterFile);
		System.out.println("----digesterFile----" + digesterFile);

		if (input == null) {
			input = DigestXML.class.getClassLoader().getResourceAsStream(digesterFile);
		}

		try {
			root = (Object) digester.parse(input);
		} catch (Exception e) {
			e.printStackTrace();
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
		} finally {
			if (input != null) {
				try {
					input.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
				input = null;
			}
		}

		return root;
	}
}