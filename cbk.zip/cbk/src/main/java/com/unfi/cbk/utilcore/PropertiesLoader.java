/*
 * Created on Oct 13, 2005
 * 
 */
package com.unfi.cbk.utilcore;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

//import org.apache.log4j.Logger;
/**
 * 
 * @author yhp6y2l
 *
 */
public class PropertiesLoader {
	// private static Logger log = Logger.getLogger(PropertiesLoader.class);
	/**
	 * 
	 */
	public Properties load(String filename) {
		Properties props = new Properties();
		InputStream is = getClass().getClassLoader().getResourceAsStream(filename);
		if (is == null) {
			if (!filename.startsWith("/")) {
				is = getClass().getClassLoader().getResourceAsStream("/" + filename);
			}
		}
		if (is != null) {
			// log.debug("Loading properties from " + filename);
			try {
				props.load(is);
				// log.debug("Properties have been loaded");
			} catch (IOException e) {
				// System.out.println("Cannot open " + filename);
				// e.printStackTrace();
				// log.error("Cannot open " + filename + " " + e);
			}
		}
		return props;
	}
}
