/*
 * Created on Oct 25, 2005
 *
 * To change the template for this generated file go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
package com.unfi.cbk.exceptions;

/**
 * 
 * @author yhp6y2l
 *
 */
public class CbkFileServiceException extends CbkServiceException {

	/**
	 * @param message
	 */
	public CbkFileServiceException(String message) {
		super(message);
	}

	/**
	 * 
	 */
	public CbkFileServiceException() {
		this("Exception in file service.");
	}

	/**
	 * @param message
	 * @param cause
	 */
	public CbkFileServiceException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * @param cause
	 */
	public CbkFileServiceException(Throwable cause) {
		super("Formatter Exception:", cause);
	}

}
