package com.unfi.cbk.controller;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

@RestController 
public class LogoutController {
	
	@Autowired
	private Environment environment;

	@RequestMapping(value = "/logoutAction", method = { RequestMethod.GET, RequestMethod.POST })
	public ModelAndView logout(HttpServletRequest request, HttpServletResponse response) throws Exception {
		request.getSession().invalidate();
		 Cookie rememberMeCookie = new Cookie("remember-me", "");
		 rememberMeCookie.setMaxAge(0);
		 response.addCookie(rememberMeCookie);
		ModelAndView mav = new ModelAndView();
		mav.setViewName("redirect:" + environment.getProperty("logut.URL"));

		return mav;
	}
}
