package com.unfi.cbk.delegates;

import java.util.List;
import java.util.Map;

import com.unfi.cbk.bo.ChargebackBO;
import com.unfi.cbk.dao.ChargebackCreateDao;
import com.unfi.cbk.exceptions.DataAccessException;

/**
 * @author yhp6y2l
 * @version 3.3
 */

public class ChargebackCreateDelegate {

	private ChargebackCreateDao chargebackCreateDao;

	public ChargebackCreateDelegate(ChargebackCreateDao chargebackCreateDao) {
		this.chargebackCreateDao = chargebackCreateDao;
	}

	public List<ChargebackBO> getSubFunds() throws DataAccessException {
		List<ChargebackBO> l = chargebackCreateDao.getSubFunds();

		return l;
	}
	
	public List getItemInfo(Map params) throws DataAccessException {

		System.out.println("----------ChargebackCreateDelegate.java----getItemInfo()-----");
		List l= chargebackCreateDao.getItemInfo(params);
		return l;
	}
	
	public List validateRegionWithoutDivision(Map params) throws DataAccessException {

		System.out.println("----------ChargebackCreateDelegate.java----validateRegionWithoutDivision()-----");
		List l= chargebackCreateDao.validateRegionWithoutDivision(params);
		return l;
	}
	
	public List validateRegionWithDivision(Map params) throws DataAccessException {

		System.out.println("----------ChargebackCreateDelegate.java----validateRegionWithDivision()-----");
		List l= chargebackCreateDao.validateRegionWithDivision(params);
		return l;
	}
	

}
