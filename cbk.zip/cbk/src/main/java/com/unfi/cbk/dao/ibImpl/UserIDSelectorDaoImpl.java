package com.unfi.cbk.dao.ibImpl;

import java.util.HashMap;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.orm.ibatis.SqlMapClientTemplate;
import org.springframework.orm.ibatis.support.SqlMapClientDaoSupport;

import com.unfi.cbk.dao.UserIDSelectorDao;
import com.unfi.cbk.exceptions.DataAccessException;

/**
 * The UserIDSelectorDaoImpl class implements the generic UserIDSelectorDao
 * interface.
 * 
 * @author yhp6y2l
 *
 */
public class UserIDSelectorDaoImpl extends SqlMapClientDaoSupport implements UserIDSelectorDao {

	static Logger log = Logger.getLogger(UserIDSelectorDaoImpl.class);

	/**
	 * @param sqlMapTemplate
	 */
	public UserIDSelectorDaoImpl(SqlMapClientTemplate sqlMapTemplate) {
		this.setSqlMapClientTemplate(sqlMapTemplate);

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.unfi.cbk.dao./* (non-Javadoc)
	 * 
	 * @see com.unfi.cbk.dao.UserIDSelectorDao#doUserIDSearch(java.lang.String,
	 * java.lang.String)
	 */

	public List doUserIDSearch(String userID, String userName) throws DataAccessException {

		List l = null;

		try {
			System.out.println(
					"--------UserIDSelectorDaoImpl.java-------doUserIDSearch()---" + userID + ":::" + userName);
			HashMap map = new HashMap();
			map.put("userID", userID.replace('*', '%'));
			map.put("userName", userName.replace('*', '%').toUpperCase());

			l = getSqlMapClientTemplate().queryForList("UserIDSelector.doUserIDSearch", map);
		} catch (Exception e) {
			throw new DataAccessException(e);
		}

		return l;
	}

}
