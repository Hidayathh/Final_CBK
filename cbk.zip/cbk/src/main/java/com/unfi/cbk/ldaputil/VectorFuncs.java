/*
 * VectorFuncs.java
 *
 * Created on April 18, 2001, 11:45 AM
 */
package com.unfi.cbk.ldaputil;

import java.util.Vector;

/**
 * This class provides general-purpose functions for manipulating Vector objects
 * 
 * @author: yhp6y2l
 */
public class VectorFuncs {
	// Suppresses default constructor, ensuring non-instantiability.
	private VectorFuncs() {
	}

	/**
	 * Swaps x[a] with x[b].
	 */
	private static void swap(Object x[], int a, int b) {
		Object t = x[a];
		x[a] = x[b];
		x[b] = t;
	}

	private static void mergeSort(Object src[], Object dest[], int low, int high) {
		int length = high - low;

		// Insertion sort on smallest arrays
		if (length < 7) {
			for (int i = low; i < high; i++) {
				for (int j = i; j > low && ((CompareTo) dest[j - 1]).compareTo((CompareTo) dest[j]) > 0; j--) {

					swap(dest, j, j - 1);
				}
			}
			return;
		}

		// Recursively sort halves of dest into src
		int mid = (low + high) / 2;
		mergeSort(dest, src, low, mid);
		mergeSort(dest, src, mid, high);

		// If list is already sorted, just copy from src to dest. This is an
		// optimization that results in faster sorts for nearly ordered lists.
		if (((CompareTo) src[mid - 1]).compareTo((CompareTo) src[mid]) <= 0) {
			System.arraycopy(src, low, dest, low, length);
			return;
		}

		// Merge sorted halves (now in src) into dest
		for (int i = low, p = low, q = mid; i < high; i++) {
			if (q >= high || p < mid && ((CompareTo) src[p]).compareTo(src[q]) <= 0) {
				dest[i] = src[p++];
			} else {
				dest[i] = src[q++];
			}
		}
	}

	private static void mergeSort(Object src[], Object dest[], int low, int high, Comparer c) {
		int length = high - low;

		// Insertion sort on smallest arrays
		if (length < 7) {
			for (int i = low; i < high; i++) {
				for (int j = i; j > low && c.compare(dest[j - 1], dest[j]) > 0; j--) {
					swap(dest, j, j - 1);
				}
			}
			return;
		}

		// Recursively sort halves of dest into src
		int mid = (low + high) / 2;
		mergeSort(dest, src, low, mid, c);
		mergeSort(dest, src, mid, high, c);

		// If list is already sorted, just copy from src to dest. This is an
		// optimization that results in faster sorts for nearly ordered lists.
		if (c.compare(src[mid - 1], src[mid]) <= 0) {
			System.arraycopy(src, low, dest, low, length);
			return;
		}

		// Merge sorted halves (now in src) into dest
		for (int i = low, p = low, q = mid; i < high; i++) {
			if (q >= high || p < mid && c.compare(src[p], src[q]) <= 0)
				dest[i] = src[p++];
			else
				dest[i] = src[q++];
		}
	}

	private static void sort(Object[] a) {
		Object aux[] = (Object[]) a.clone();
		mergeSort(aux, a, 0, a.length);
	}

	private static void sort(Object[] a, Comparer c) {
		Object aux[] = (Object[]) a.clone();

		if (c == null) {
			mergeSort(aux, a, 0, a.length);
		} else {
			mergeSort(aux, a, 0, a.length, c);
		}
	}

	public static void sort(Vector vector) {
		final int vectorSize = vector.size();
		Object a[] = new Object[vectorSize];

		// Copy the vector into an array.
		vector.copyInto(a);

		// Sort the array.
		sort(a);

		// Copy the array back into the vector.
		for (int index = 0; index < vectorSize; index++) {
			vector.setElementAt(a[index], index);
		}
	}

	public static void sort(Vector vector, Comparer c) {
		final int vectorSize = vector.size();
		Object a[] = new Object[vectorSize];

		// Copy the vector into an array.
		vector.copyInto(a);

		sort(a, c);

		// Copy the array back into the vector.
		for (int index = 0; index < vectorSize; index++) {
			vector.setElementAt(a[index], index);
		}
	}
}
