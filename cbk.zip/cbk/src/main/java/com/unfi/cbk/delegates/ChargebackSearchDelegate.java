package com.unfi.cbk.delegates;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.unfi.cbk.beans.ResultList;
import com.unfi.cbk.bo.ChargebackBO;
import com.unfi.cbk.bo.CreateNewUserBO;
import com.unfi.cbk.dao.ChargebackCommonDao;
import com.unfi.cbk.dao.ChargebackSearchDao;
import com.unfi.cbk.exceptions.DataAccessException;
import com.unfi.cbk.util.DateFunctions;

/**
 * @author yhp6y2l
 * @version 3.3
 */

public class ChargebackSearchDelegate {

	private ChargebackSearchDao chargebackSearchDao;
	private ChargebackCommonDao chargebackCommonDao;

	public ChargebackSearchDelegate(ChargebackSearchDao chargebackSearchDao, ChargebackCommonDao chargebackCommonDao) {
		this.chargebackSearchDao = chargebackSearchDao;
		this.chargebackCommonDao = chargebackCommonDao;
	}

	public ResultList getChargebacks(Map params) throws DataAccessException {

		// Set up the date range of the search
		this.calculateSearchDates(params);
		ResultList rL = chargebackSearchDao.getChargebacks(params);

		// Only keep the fromDate and toDate parameters in the map if the user
		// entered a manual date selection.
		String dateCriteria = (String) params.get("dateCriteria");
		if (dateCriteria != null && !dateCriteria.equals("manual")) {
			params.remove("fromDate");
			params.remove("toDate");
		}

		return rL;
	}

	public ChargebackBO getChargebackDetail(Map params) throws DataAccessException {
		return chargebackSearchDao.getChargebackDetail(params);
	}

	public ResultList getCbkDetTable(Map params) throws DataAccessException {
		ResultList rL = chargebackSearchDao.getCbkDetTable(params);
		return rL;
	}
	
	public ResultList getCbkDetTableInfo(Map params) throws DataAccessException {
		ResultList rL = chargebackSearchDao.getCbkDetTableInfo(params);
		return rL;
	}

	public ChargebackBO getChargebackInfo(Map params) throws DataAccessException {
		return chargebackSearchDao.getChargebackInfo(params);
	}

	public ResultList getChargebackDistribution(Map params) throws DataAccessException {
		ResultList rL = chargebackSearchDao.getChargebackDistribution(params);
		return rL;
	}

	public ResultList getApproverRoles(Map params) throws DataAccessException {
		ResultList rL = chargebackSearchDao.getApproverRoles(params);
		return rL;
	}

	public void updateChargeback(ChargebackBO chargeBack, boolean isNew) throws DataAccessException {
		if (isNew) {
			chargebackSearchDao.createChargeback(chargeBack);
		} else {
			chargebackSearchDao.updateChargeback(chargeBack);
		}
	}

	public void createCbkDistribution(List distributionList) throws DataAccessException {
		chargebackSearchDao.createCbkDistribution(distributionList);
	}
	
	public void createCbkDistributionSingleRecord(ChargebackBO chargeBack) throws DataAccessException {
		chargebackSearchDao.createCbkDistributionSingleRecord(chargeBack);
	}

	public void deleteCbkDistribution(Map params) throws DataAccessException {
		chargebackSearchDao.deleteCbkDistribution(params);
	}

	public void createCbkItem(List itemList) throws DataAccessException {
		chargebackSearchDao.createCbkItem(itemList);
	}
	
	public void createCbkItemSingleRecord(ChargebackBO chargeBack) throws DataAccessException {
		chargebackSearchDao.createCbkItemSingleRecord(chargeBack);
	}

	public void deleteCbkItem(Map params) throws DataAccessException {
		chargebackSearchDao.deleteCbkItem(params);
	}

	public ChargebackBO getChargeback(Map params) throws DataAccessException {
		return chargebackSearchDao.getChargeback(params);
	}

	public ResultList getAvailableChargebacks(Map params) throws DataAccessException {
		ResultList rL = chargebackSearchDao.getAvailableChargebacks(params);
		return rL;
	}

	public List<ChargebackBO> getChargebackTypes() throws DataAccessException {
		List<ChargebackBO> l = chargebackSearchDao.getChargebackTypes();

		return l;
	}

	public String getApproverStepsUp(String typeId, String chargebackTotal, String stepNumber)
			throws DataAccessException {
		String nextStepNumber = chargebackSearchDao.getApproverStepsUp(typeId,stepNumber);
		return nextStepNumber;
	}

	public String  getApproverStepsDown(String typeId, String chargebackTotal, String stepNumber)
			throws DataAccessException {
		
		String nextStepNumber = chargebackSearchDao.getApproverStepsDown(typeId,stepNumber);
		return nextStepNumber;
	}

	public List<ChargebackBO> getReasons() throws DataAccessException {
		List<ChargebackBO> l = chargebackSearchDao.getReasons();

		return l;
	}

	public List<ChargebackBO> getProductGroup() throws DataAccessException {
		List<ChargebackBO> l = chargebackSearchDao.getProductGroup();

		return l;
	}

	public ChargebackBO getChargebackVendor(Map params) throws DataAccessException {
		return chargebackSearchDao.getChargebackVendor(params);
	}

	public void approveChargebacks(ChargebackBO cbkBo) throws DataAccessException {
		chargebackSearchDao.approveChargebacks(cbkBo);
	}

	public void denyChargebacks(ChargebackBO cbkBo) throws DataAccessException {
		chargebackSearchDao.denyChargebacks(cbkBo);
	}

	public ResultList locationNumberValidator(Map params) throws DataAccessException {
		ResultList rL = chargebackSearchDao.locationNumberValidator(params);
		return rL;
	}

	public ResultList vendorNumberValidator(String vendor) throws DataAccessException {
		ResultList rL = chargebackSearchDao.vendorNumberValidator(vendor);
		return rL;
	}

	public ResultList originatorValidator(Map params) throws DataAccessException {
		ResultList rL = chargebackSearchDao.originatorValidator(params);
		return rL;
	}

	public ResultList nextApproverValidator(Map params) throws DataAccessException {
		ResultList rL = chargebackSearchDao.nextApproverValidator(params);
		return rL;
	}

	public ResultList invoiceNumberValidator(Map params) throws DataAccessException {
		ResultList rL = chargebackSearchDao.invoiceNumberValidator(params);
		return rL;
	}



	private void calculateSearchDates(Map params) {
		// Determine the dates to use
		String dateCriteria = (String) params.get("dateCriteria");
		String fromDate = (String) params.get("fromDate");
		String toDate = (String) params.get("toDate");
		String from = "";
		String to = "";

		if ((dateCriteria != null) && (!dateCriteria.equals(""))) {
			if (dateCriteria.equals("3")) {
				// Use the dates provided
				from = DateFunctions.formatYear(fromDate);
				params.put("fromDate", from);
				params.put("searchFromDate", DateFunctions.formatDate(from));
				to = DateFunctions.formatYear(toDate);
				params.put("toDate", to);
				params.put("searchToDate", DateFunctions.formatDate(to));
			} else {
				String dateCriteriaDays = null;

				if (dateCriteria.equalsIgnoreCase("1")) {
					dateCriteriaDays = "30";
				} else if (dateCriteria.equalsIgnoreCase("2")) {
					dateCriteriaDays = "60";
				}

				from = DateFunctions.adjustCurrentDate(-(Integer.parseInt(dateCriteriaDays)));
				to = DateFunctions.getToday();

				params.put("fromDate", from);
				params.put("searchFromDate", DateFunctions.formatDate(from));
				params.put("toDate", to);
				params.put("searchToDate", DateFunctions.formatDate(to));
				System.out.println("-----from---" + from + "---DateFunctions.formatDate(from)---"
						+ DateFunctions.formatDate(from));
			}
		}
	}

	public String buildSearchCriteriaSummary(Map formSearchValuesMap) {
		HashMap searchCriteriaText = new HashMap();

		String vendorId = (String) formSearchValuesMap.get("vendorId");
		System.out.println("Cbk deligate calss" + vendorId);
		if ((vendorId != null) && (!vendorId.equals(""))) {
			searchCriteriaText.put("vendor", "Vendor " + vendorId);
		}

		// Determine the dates to use
		String dateCriteria = (String) formSearchValuesMap.get("dateCriteria");
		String fromDate = (String) formSearchValuesMap.get("fromDate");
		String toDate = (String) formSearchValuesMap.get("toDate");
		String from = "";
		String to = "";

		if ((dateCriteria != null) && (!dateCriteria.equals(""))) {
			if (dateCriteria.equals("manual")) {
				// Use the dates provided
				from = DateFunctions.formatYear(fromDate);
				to = DateFunctions.formatYear(toDate);
				searchCriteriaText.put("date", from + " - " + to);
			} else {
				// Use the value submitted to determine how many days to go back
				// (The span value submitted is either 1, 2, or 3 - the value is
				// translated based on values from the Resource Bundle
				String dateCriteriaDays = null;
				if (dateCriteria.equalsIgnoreCase("1")) {
					dateCriteriaDays = "30";
				} else if (dateCriteria.equalsIgnoreCase("2")) {
					dateCriteriaDays = "60";
				} else if (dateCriteria.equalsIgnoreCase("3")) {
					dateCriteriaDays = "90";
				}
				// String dateCriteriaDays =
				// applicationResources.getMessage("label.dateCriteria.span" + dateCriteria);
				from = DateFunctions.adjustCurrentDate(-(Integer.parseInt(dateCriteriaDays)));
				to = DateFunctions.getToday();

				searchCriteriaText.put("date", "Last " + dateCriteriaDays + " days");
			}
		}

		// Build the summary string that is used on the results page
		// to show what criteria was used in the search.
		StringBuffer searchCriteriaSummary = new StringBuffer();

		if (searchCriteriaText.containsKey("date")) {
			searchCriteriaSummary.append((String) searchCriteriaText.get("date"));
		}
		if (searchCriteriaText.containsKey("vendor")) {
			if (searchCriteriaSummary.length() > 0) {
				searchCriteriaSummary.append(", ");
			}
			searchCriteriaSummary.append((String) searchCriteriaText.get("vendor"));
		}
		if (searchCriteriaText.containsKey("location")) {
			if (searchCriteriaSummary.length() > 0) {
				searchCriteriaSummary.append(", ");
			}
			searchCriteriaSummary.append((String) searchCriteriaText.get("location"));
		}
		if (searchCriteriaText.containsKey("netamount")) {
			if (searchCriteriaSummary.length() > 0) {
				searchCriteriaSummary.append(", ");
			}
			searchCriteriaSummary.append((String) searchCriteriaText.get("netamount"));

			if (searchCriteriaText.containsKey("netamountmore")) {
				searchCriteriaSummary.append((String) searchCriteriaText.get("netamountmore"));
			}
		}

		return searchCriteriaSummary.toString();
	}

	/**
	 * @param chargeback
	 */
	/*
	 * public void fillCheckDetails(Chargeback chargeback) throws
	 * CbkServiceException { chargebackSearchDao.fillCheckDetails(chargeback); }
	 * 
	 * public List getChargebackAttachments(Chargeback chargeback) throws
	 * DataAccessException { return
	 * chargebackSearchDao.getChargebackAttachments(chargeback); }
	 */

	public void insertMenuAccessforUser(List selectedAccessRole) throws DataAccessException {
		chargebackSearchDao.insertMenuAccessforUser(selectedAccessRole);
	}

	public void InsertUser(List selectedRoleLocationList, Map formSearchValuesMap) throws DataAccessException {
		chargebackSearchDao.InsertUser(selectedRoleLocationList, formSearchValuesMap);
	}

	public void EditUser(Map formSearchValuesMap) throws DataAccessException {
		chargebackSearchDao.EditUser(formSearchValuesMap);
	}

	public void updateUser(List selectedRoleLocationList, Map formSearchValuesMap) throws DataAccessException {

		chargebackSearchDao.updateUser(selectedRoleLocationList, formSearchValuesMap);
	}

	/*
	 * public void updateUserRolesLocations(List selectedUpdateRoleLocationList)
	 * throws DataAccessException {
	 * 
	 * chargebackSearchDao.updateUserRolesLocations(selectedUpdateRoleLocationList);
	 * }
	 */

	/*
	 * public List getUserDetails(String userId) throws DataAccessException{
	 * System.out.println("--in DELEGATE---FETCHING getUserDetails TYPES------");
	 * List l =chargebackSearchDao.getUserDetails(userId); return l;
	 * 
	 * }
	 */
	public CreateNewUserBO getUserDetails(String userId) throws DataAccessException {
		System.out.println("--in DELEGATE---FETCHING getUserDetails()---userId---"+userId);
		return chargebackSearchDao.getUserDetails(userId);

	}

	/*
	 * public CreateNewUserBO getUserRolesLocations(String userId) throws
	 * DataAccessException{
	 * System.out.println("--in DELEGATE---FETCHING getUserDetails TYPES------");
	 * return chargebackSearchDao.getUserRolesLocations(userId);
	 * 
	 * }
	 */
	public ResultList getUserRolesLocations(String userId) throws DataAccessException {
		System.out.println("--in DELEGATE---FETCHING getUserDetails ------");
		return chargebackSearchDao.getUserRolesLocations(userId);

	}

	public List getLocations() throws DataAccessException {
		System.out.println("--in DELEGATE---FETCHING getLocations ------");
		List<ChargebackBO> l = chargebackSearchDao.getLocations();

		return l;
	}

	public List getLocationsForCreateUser() throws DataAccessException {
		System.out.println("--in DELEGEATE- FETCHING getLocationsForCreateUser()---");
		List<ChargebackBO> l = chargebackSearchDao.getLocationsForCreateUser();
		return l;

	}

	public List getRoles() throws DataAccessException {
		System.out.println("--in DELEGATE---FETCHING getRoles ------");
		List l = chargebackSearchDao.getRoles();

		return l;
	}

	public ResultList getUserAssignedRoles(String userId) throws DataAccessException {
		System.out.println("--in DELEGATE---FETCHING getUserAssignedRoles------");
		return chargebackSearchDao.getUserAssignedRoles(userId);

	}

	public void deleteUserDetails(String userId) throws DataAccessException {
		chargebackSearchDao.deleteUserDetails(userId);
	}

	public String getCompanyCode(String locationNumber) throws DataAccessException {
		String companyCode = chargebackSearchDao.getCompanyCode(locationNumber);
		return companyCode;
	}

	public String getStepNumberForMassApproval(String typeId, String roleId) throws DataAccessException {
		String maxStepNumber = chargebackSearchDao.getStepNumberForMassApproval(typeId,roleId);
		return maxStepNumber;
	}
	
	public String getMaxStepNumber(String typeId) throws DataAccessException {
		String maxStepNumber = chargebackSearchDao.getMaxStepNumber(typeId);
		return maxStepNumber;
	}
	
	
	public String getMinStepNumber(String typeId) throws DataAccessException {
		String minStepNumber = chargebackSearchDao.getMinStepNumber(typeId);
		return minStepNumber;
	}

	public HashMap getRolesByUserForMenu(Map params) throws DataAccessException {
		HashMap menuMap = chargebackSearchDao.getRolesByUserForMenu(params);
		return menuMap;
	}

	public ChargebackBO getNextInvoceNumberOrBarcode(String locationNumber) throws DataAccessException {
		ChargebackBO nextInvoiceNumber = chargebackSearchDao.getNextInvoceNumberOrBarcode(locationNumber);
		return nextInvoiceNumber;
	}

	public List getAllRoles() throws DataAccessException {
		// TODO Auto-generated method stub
		return chargebackSearchDao.getAllRoles();
	}

	public void insertInvoice(ChargebackBO cbkBo) throws DataAccessException {
		chargebackSearchDao.insertInvoice(cbkBo);
	}

	public void updateInvoice(ChargebackBO cbkBo) throws DataAccessException {
		chargebackSearchDao.updateInvoice(cbkBo);
	}

	public void updateChargebackApprover(ChargebackBO chargeBack) throws DataAccessException {
		System.out.println("----------ChargebackSearchDelegate.java----updateChargebackApprover()-----");
		chargebackSearchDao.updateChargebackApprover(chargeBack);
	}

	public void updateAttachment(ChargebackBO chargebackBO) throws DataAccessException {
		chargebackSearchDao.updateAttachment(chargebackBO);
	}

	public void createAttachment(ChargebackBO chargebackBO) throws DataAccessException {
		chargebackSearchDao.createAttachment(chargebackBO);
	}

	public void updateChargebackDenyReason(ChargebackBO chargeBack) throws DataAccessException {
		System.out.println("----------ChargebackSearchDelegate.java----updateChargebackDenyReason()-----");
		chargebackSearchDao.updateChargebackDenyReason(chargeBack);
	}

	public List<ChargebackBO> getAttachmentName(String invoiceNumber) throws DataAccessException {
		return chargebackSearchDao.getAttachmentName(invoiceNumber);
	}

	public ChargebackBO findByAttachmentName(ChargebackBO chargebackBO) throws DataAccessException {
		// TODO Auto-generated method stub
		return chargebackSearchDao.findByAttachmentName(chargebackBO);
	}

	public void deleteAttachment(String invoiceNumber) throws DataAccessException {
		chargebackSearchDao.deleteAttachment(invoiceNumber);
	}

	public ResultList getAccountProductCodes(Map params) throws DataAccessException {
		ResultList rL = chargebackSearchDao.getAccountProductCodes(params);
		return rL;
	}

	public List getLocationsByUser(String approverId) throws DataAccessException {
		System.out.println("--in DELEGATE---FETCHING getLocations TYPES------");
		List<ChargebackBO> l = chargebackSearchDao.getLocationsByUser(approverId);

		return l;
	}

	public ResultList getAvailableInvoiceNumber(String invoice, String location) throws DataAccessException {
		ResultList rL = chargebackSearchDao.getAvailableInvoiceNumber(invoice, location);
		return rL;
	}

	public ResultList getApprovalHistory(String invoice) throws DataAccessException {
		ResultList rL = chargebackSearchDao.getApprovalHistory(invoice);
		return rL;
	}

	public void deleteApprovals(String invoiceNumber, String locationNumber) throws DataAccessException {
		chargebackSearchDao.deleteApprovals(invoiceNumber, locationNumber);
	}

	public ResultList getChargebackApprovalStatus(String invoiceNumber, String approverId) throws DataAccessException {
		ResultList rL = chargebackSearchDao.getChargebackApprovalStatus(invoiceNumber, approverId);
		return rL;
	}

	public String getAdminUser(String userId, String roleId) throws DataAccessException {
		String maxStepNumber = chargebackSearchDao.getAdminUser(userId, roleId);
		return maxStepNumber;
	}
	
	public String getRoleIdForNextApprover(String invoiceNumber,String typeId,String locationNumber,String userId) throws DataAccessException{
		String maxStepNumber = chargebackSearchDao.getRoleIdForNextApprover(invoiceNumber,typeId,locationNumber,userId);
		return maxStepNumber;
	}

	public ResultList getMassApprovalsList(Map params) throws DataAccessException {

		System.out.println("-in Delegate----fromDate--" + params.get("fromDate"));
		// Set up the date range of the search
		this.calculateSearchDates(params);
		System.out.println("----------ChargebackSearchDelegate.java----getMassApprovalsList()-----");
		ResultList rL = chargebackSearchDao.getMassApprovalsList(params);
		return rL;
	}

	public String getValidVendorNumber(String vendorId) throws DataAccessException {
		String validVendorId = chargebackSearchDao.getValidVendorNumber(vendorId);
		return validVendorId;
	}
	
	public ResultList getRoleIdRouteIdForUser(Map params) throws DataAccessException {

		System.out.println("----------ChargebackSearchDelegate.java----getRoleIdRouteIdForUser()-----");
		ResultList rL = chargebackSearchDao.getRoleIdRouteIdForUser(params);
		return rL;
	}
	public String getApprovalLimitForUser(Map params) throws DataAccessException {
		String userAppLimit = chargebackSearchDao.getApprovalLimitForUser(params);
		return userAppLimit;
	}

	public String deleteApproverReference(String userId) throws DataAccessException {
		String approverReference = chargebackSearchDao.deleteApproverReference(userId);
		return approverReference;
	}

	public void massUpdateChargebackApprover(List massApprovalList) throws DataAccessException {
		System.out.println("----------ChargebackSearchDelegate.java----massUpdateChargebackApprover()-----");
		chargebackSearchDao.massUpdateChargebackApprover(massApprovalList);
	}

	/*
	 * public void massApproveChargebacks(List massApprovalList) throws
	 * DataAccessException { System.out.println(
	 * "----------ChargebackSearchDelegate.java----massApproveChargebacks()-----");
	 * chargebackSearchDao.massApproveChargebacks(massApprovalList); }
	 */

	public String getValidAccountNumber(String companyCode, String accNum, String acct_unit)
			throws DataAccessException {
		String validAccount = chargebackSearchDao.getValidAccountNumber(companyCode, accNum, acct_unit);
		return validAccount;
	}
	
	public String getInvoiceEditableStatus(String invoiceNumber) throws DataAccessException {
		String editableInvoice = chargebackSearchDao.getInvoiceEditableStatus(invoiceNumber);
		return editableInvoice;
	}
	
	
	
	public String getApprovalWith5KLimit(String userId, String locationNumber) throws DataAccessException {
		String editableInvoice = chargebackSearchDao.getApprovalWith5KLimit(userId,locationNumber);
		return editableInvoice;
	}
	
	public String getMaxStepNumberForInvoice(String invoiceNumber) throws DataAccessException {
		String maxStepNumber = chargebackSearchDao.getMaxStepNumberForInvoice(invoiceNumber);
		return maxStepNumber;
	}
	
	public String getInvoiceEligibleForApprove(String userId, String invoiceNumber) throws DataAccessException {
		String eligibleInvoice = chargebackSearchDao.getInvoiceEligibleForApprove(userId,invoiceNumber);
		return eligibleInvoice;
	}
	
	
	
	public String getMaxStepNumberWithInvoiceAmount(String invoiceNumber,String locationNumber,String typeId) throws DataAccessException{
		String maxStepNumber = chargebackSearchDao.getMaxStepNumberWithInvoiceAmount(invoiceNumber,locationNumber,typeId);
		return maxStepNumber;
	}
	
	public String getMinStepNumberWithInvoiceAmount(String invoiceNumber,String locationNumber,String typeId) throws DataAccessException{
		String minStepNumber = chargebackSearchDao.getMinStepNumberWithInvoiceAmount(invoiceNumber,locationNumber,typeId);
		return minStepNumber;
	}
	
	public String getApproverStepsUpWithInvoiceAmount(String invoiceNumber,String locationNumber,String typeId,String stepNumber) 	throws DataAccessException{
		String stepDown = chargebackSearchDao.getApproverStepsUpWithInvoiceAmount(invoiceNumber,locationNumber,typeId,stepNumber);
		return stepDown;
	
	}
	
		
	
	public String getApproverStepsDownWithInvoiceAmount(String invoiceNumber,String locationNumber,String typeId,String stepNumber) 	throws DataAccessException{
		String stepDown = chargebackSearchDao.getApproverStepsDownWithInvoiceAmount(invoiceNumber,locationNumber,typeId,stepNumber);
		return stepDown;
	
	}
	
	public ChargebackBO getChargebackDetailInfo(Map params) throws DataAccessException {
		return chargebackSearchDao.getChargebackDetailInfo(params);
	}
	
	public void createCbkFundsRecord(ChargebackBO cbkBO)  throws DataAccessException{
		chargebackSearchDao.createCbkFundsRecord(cbkBO);
	}

	public void createCbkItemFundsRecord(ChargebackBO cbkBO) throws DataAccessException{
		chargebackSearchDao.createCbkItemFundsRecord(cbkBO);
	}

	public void createCbkDistributionFundsRecord(ChargebackBO cbkBO) throws DataAccessException{
		chargebackSearchDao.createCbkDistributionFundsRecord(cbkBO);
	}

	public void createCbkApprFundsRecord(ChargebackBO cbkBO) throws DataAccessException{
		chargebackSearchDao.createCbkApprFundsRecord(cbkBO);
	}

	public String getStepNumberForApproverByRoleid(String approverId) throws DataAccessException {
        String minStepNumber = chargebackSearchDao.getStepNumberForApproverByRoleid(approverId);
        return minStepNumber;
 }
	public  String getValidateUserId(String userId) throws DataAccessException {
		System.out.println("--in DELEGATE---FETCHING getUserDetails()---userId---"+userId);
		return chargebackSearchDao.getValidateUserId(userId);

	}

	public void getCancelChargeback(String invoiceNumber) throws DataAccessException {
		chargebackSearchDao.getCancelChargeback(invoiceNumber);
	}
	
	public CreateNewUserBO getActiveUserDetails(String userId) throws DataAccessException {
        System.out.println("--in DELEGATE---FETCHING getUserDetails()---userId---"+userId);
        return chargebackSearchDao.getActiveUserDetails(userId);

 }
	
	public List<ChargebackBO> getChargebackTypesForCreate() throws DataAccessException {
        List<ChargebackBO> l = chargebackSearchDao.getChargebackTypesForCreate();

        return l;
	}
	
	public ChargebackBO getVendorInfoByVendorId(String vendorId) throws DataAccessException {
		return chargebackSearchDao.getVendorInfoByVendorId(vendorId);
	}
	
	public String getValidMaxAmount(String creatorId, Integer typeId) throws DataAccessException{
		String validMaxAmount=chargebackSearchDao.getValidMaxAmount(creatorId, typeId);
		return validMaxAmount;
	}
	
	public List doVendorIdSearch(String removeLeadingZeroVendorId, String spaceFillLeftVendorId, String vName) throws DataAccessException {
		List l = chargebackCommonDao.doVendorIdSearch(removeLeadingZeroVendorId, spaceFillLeftVendorId, vName);
		return l;
	}


}
