/*
 * UserDetail.java
 *
 * Created on March 16, 2001, 11:52 AM
 */
package com.unfi.cbk.b2aldap;

import com.unfi.cbk.ldaputil.CompareTo;

/**
 * Class to hold User Detail information.
 * 
 * @author: yhp6y2l
 */
public class UserDetail extends Object implements CompareTo {
	private String loginID;
	private String firstName;
	private String lastName;
	private String middleInitial;
	private String fullName;
	
	public String getLoginID() {
		return (loginID);
	}

	public String getFirstName() {
		return (firstName);
	}

	public String getLastName() {
		return (lastName);
	}

	public String getMiddleInitial() {
		return (middleInitial);
	}

	public String getFullName() {
		return (fullName);
	}

	


	
	/** Creates new UserDetail object */
	public UserDetail(String loginID, String firstName, String lastName, String middleInitial, String fullName) {
		super();
		this.loginID = loginID;
		this.firstName = firstName;
		this.lastName = lastName;
		this.middleInitial = middleInitial;
		this.fullName = fullName;
	}

	public int compareTo(java.lang.Object obj) {
		int ret = loginID.toLowerCase().compareTo(((UserDetail) obj).loginID.toLowerCase());

		return (ret);
	}

}
